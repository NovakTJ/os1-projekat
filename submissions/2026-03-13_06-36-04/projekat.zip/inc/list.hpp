//
// Created by marko on 20.4.22..
//

#ifndef OS1_VEZBE07_RISCV_CONTEXT_SWITCH_2_INTERRUPT_LIST_HPP
#define OS1_VEZBE07_RISCV_CONTEXT_SWITCH_2_INTERRUPT_LIST_HPP

#include "../h/MemoryAllocator.hpp"

template<typename T>
class List
{
private:
    struct Elem
    {
        T *data;
        Elem *next;

        Elem(T *data, Elem *next) : data(data), next(next) {}
        void* operator new(size_t size) { return MemoryAllocator::allocateBytes(size); }
        void operator delete(void* ptr) { MemoryAllocator::deallocate((char*)ptr); }
    };

    Elem *head, *tail;

public:
    List() : head(0), tail(0) {}

    bool empty() const { return head == 0; }

    List(const List<T> &) = delete;

    List<T> &operator=(const List<T> &) = delete;

    void addFirst(T *data)
    {
        Elem *elem = new Elem(data, head);
        head = elem;
        if (!tail) { tail = head; }
    }

    void addLast(T *data)
    {
        Elem *elem = new Elem(data, 0);
        if (tail)
        {
            tail->next = elem;
            tail = elem;
        } else
        {
            head = tail = elem;
        }
    }

    T *removeFirst()
    {
        if (!head) { return 0; }

        Elem *elem = head;
        head = head->next;
        if (!head) { tail = 0; }

        T *ret = elem->data;
        delete elem;
        return ret;
    }

    T *peekFirst()
    {
        if (!head) { return 0; }
        return head->data;
    }

    T *peekAt(int index)
    {
        Elem *curr = head;
        for (int i = 0; i < index && curr; i++) curr = curr->next;
        return curr ? curr->data : 0;
    }

    void insertAt(int pos, T *data)
    {
        if (pos <= 0 || !head)
        {
            addFirst(data);
            return;
        }
        Elem *curr = head;
        for (int i = 0; i < pos - 1 && curr->next; i++) curr = curr->next;
        Elem *elem = new Elem(data, curr->next);
        curr->next = elem;
        if (curr == tail) tail = elem;
    }

    T *removeLast()
    {
        if (!head) { return 0; }

        Elem *prev = 0;
        for (Elem *curr = head; curr && curr != tail; curr = curr->next)
        {
            prev = curr;
        }

        Elem *elem = tail;
        if (prev) { prev->next = 0; }
        else { head = 0; }
        tail = prev;

        T *ret = elem->data;
        delete elem;
        return ret;
    }

    T *peekLast()
    {
        if (!tail) { return 0; }
        return tail->data;
    }

    void printListOfTCBs()
    {
        for (Elem *curr = head; curr; curr = curr->next)
        {
            curr->data->printTCB();
        }
    }
};

#endif //OS1_VEZBE07_RISCV_CONTEXT_SWITCH_2_INTERRUPT_LIST_HPP
