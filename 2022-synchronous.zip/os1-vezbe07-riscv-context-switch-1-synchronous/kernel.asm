
kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
    80000000:	00004117          	auipc	sp,0x4
    80000004:	65013103          	ld	sp,1616(sp) # 80004650 <_GLOBAL_OFFSET_TABLE_+0x18>
    80000008:	00001537          	lui	a0,0x1
    8000000c:	f14025f3          	csrr	a1,mhartid
    80000010:	00158593          	addi	a1,a1,1
    80000014:	02b50533          	mul	a0,a0,a1
    80000018:	00a10133          	add	sp,sp,a0
    8000001c:	12d010ef          	jal	ra,80001948 <start>

0000000080000020 <spin>:
    80000020:	0000006f          	j	80000020 <spin>
	...

0000000080001000 <_ZN3CCB13contextSwitchEPNS_7ContextES1_>:
.global _ZN3CCB13contextSwitchEPNS_7ContextES1_
.type _ZN3CCB13contextSwitchEPNS_7ContextES1_, @function
_ZN3CCB13contextSwitchEPNS_7ContextES1_:
    sd ra, 0 * 8(a0)
    80001000:	00153023          	sd	ra,0(a0) # 1000 <_entry-0x7ffff000>
    sd sp, 1 * 8(a0)
    80001004:	00253423          	sd	sp,8(a0)

    ld ra, 0 * 8(a1)
    80001008:	0005b083          	ld	ra,0(a1)
    ld sp, 1 * 8(a1)
    8000100c:	0085b103          	ld	sp,8(a1)

    80001010:	00008067          	ret

0000000080001014 <_ZN5Riscv13pushRegistersEv>:
.global _ZN5Riscv13pushRegistersEv
.type _ZN5Riscv13pushRegistersEv, @function
_ZN5Riscv13pushRegistersEv:
    addi sp, sp, -256
    80001014:	f0010113          	addi	sp,sp,-256
    // https://sourceware.org/binutils/docs/as/Irp.html
    .irp index, 3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31
    sd x\index, \index * 8(sp)
    .endr
    80001018:	00313c23          	sd	gp,24(sp)
    8000101c:	02413023          	sd	tp,32(sp)
    80001020:	02513423          	sd	t0,40(sp)
    80001024:	02613823          	sd	t1,48(sp)
    80001028:	02713c23          	sd	t2,56(sp)
    8000102c:	04813023          	sd	s0,64(sp)
    80001030:	04913423          	sd	s1,72(sp)
    80001034:	04a13823          	sd	a0,80(sp)
    80001038:	04b13c23          	sd	a1,88(sp)
    8000103c:	06c13023          	sd	a2,96(sp)
    80001040:	06d13423          	sd	a3,104(sp)
    80001044:	06e13823          	sd	a4,112(sp)
    80001048:	06f13c23          	sd	a5,120(sp)
    8000104c:	09013023          	sd	a6,128(sp)
    80001050:	09113423          	sd	a7,136(sp)
    80001054:	09213823          	sd	s2,144(sp)
    80001058:	09313c23          	sd	s3,152(sp)
    8000105c:	0b413023          	sd	s4,160(sp)
    80001060:	0b513423          	sd	s5,168(sp)
    80001064:	0b613823          	sd	s6,176(sp)
    80001068:	0b713c23          	sd	s7,184(sp)
    8000106c:	0d813023          	sd	s8,192(sp)
    80001070:	0d913423          	sd	s9,200(sp)
    80001074:	0da13823          	sd	s10,208(sp)
    80001078:	0db13c23          	sd	s11,216(sp)
    8000107c:	0fc13023          	sd	t3,224(sp)
    80001080:	0fd13423          	sd	t4,232(sp)
    80001084:	0fe13823          	sd	t5,240(sp)
    80001088:	0ff13c23          	sd	t6,248(sp)
    ret
    8000108c:	00008067          	ret

0000000080001090 <_ZN5Riscv12popRegistersEv>:
.type _ZN5Riscv12popRegistersEv, @function
_ZN5Riscv12popRegistersEv:
    // https://sourceware.org/binutils/docs/as/Irp.html
    .irp index, 3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31
    ld x\index, \index * 8(sp)
    .endr
    80001090:	01813183          	ld	gp,24(sp)
    80001094:	02013203          	ld	tp,32(sp)
    80001098:	02813283          	ld	t0,40(sp)
    8000109c:	03013303          	ld	t1,48(sp)
    800010a0:	03813383          	ld	t2,56(sp)
    800010a4:	04013403          	ld	s0,64(sp)
    800010a8:	04813483          	ld	s1,72(sp)
    800010ac:	05013503          	ld	a0,80(sp)
    800010b0:	05813583          	ld	a1,88(sp)
    800010b4:	06013603          	ld	a2,96(sp)
    800010b8:	06813683          	ld	a3,104(sp)
    800010bc:	07013703          	ld	a4,112(sp)
    800010c0:	07813783          	ld	a5,120(sp)
    800010c4:	08013803          	ld	a6,128(sp)
    800010c8:	08813883          	ld	a7,136(sp)
    800010cc:	09013903          	ld	s2,144(sp)
    800010d0:	09813983          	ld	s3,152(sp)
    800010d4:	0a013a03          	ld	s4,160(sp)
    800010d8:	0a813a83          	ld	s5,168(sp)
    800010dc:	0b013b03          	ld	s6,176(sp)
    800010e0:	0b813b83          	ld	s7,184(sp)
    800010e4:	0c013c03          	ld	s8,192(sp)
    800010e8:	0c813c83          	ld	s9,200(sp)
    800010ec:	0d013d03          	ld	s10,208(sp)
    800010f0:	0d813d83          	ld	s11,216(sp)
    800010f4:	0e013e03          	ld	t3,224(sp)
    800010f8:	0e813e83          	ld	t4,232(sp)
    800010fc:	0f013f03          	ld	t5,240(sp)
    80001100:	0f813f83          	ld	t6,248(sp)
    addi sp, sp, 256
    80001104:	10010113          	addi	sp,sp,256
    ret
    80001108:	00008067          	ret

000000008000110c <_ZL9fibonaccim>:
#include "../lib/hw.h"
#include "../h/ccb.hpp"
#include "../h/print.hpp"

static uint64 fibonacci(uint64 n)
{
    8000110c:	fe010113          	addi	sp,sp,-32
    80001110:	00113c23          	sd	ra,24(sp)
    80001114:	00813823          	sd	s0,16(sp)
    80001118:	00913423          	sd	s1,8(sp)
    8000111c:	01213023          	sd	s2,0(sp)
    80001120:	02010413          	addi	s0,sp,32
    80001124:	00050493          	mv	s1,a0
    if (n == 0 || n == 1) { return n; }
    80001128:	00100793          	li	a5,1
    8000112c:	02a7f663          	bgeu	a5,a0,80001158 <_ZL9fibonaccim+0x4c>
    if (n % 4 == 0) CCB::yield();
    80001130:	00357793          	andi	a5,a0,3
    80001134:	02078e63          	beqz	a5,80001170 <_ZL9fibonaccim+0x64>
    return fibonacci(n - 1) + fibonacci(n - 2);
    80001138:	fff48513          	addi	a0,s1,-1
    8000113c:	00000097          	auipc	ra,0x0
    80001140:	fd0080e7          	jalr	-48(ra) # 8000110c <_ZL9fibonaccim>
    80001144:	00050913          	mv	s2,a0
    80001148:	ffe48513          	addi	a0,s1,-2
    8000114c:	00000097          	auipc	ra,0x0
    80001150:	fc0080e7          	jalr	-64(ra) # 8000110c <_ZL9fibonaccim>
    80001154:	00a90533          	add	a0,s2,a0
}
    80001158:	01813083          	ld	ra,24(sp)
    8000115c:	01013403          	ld	s0,16(sp)
    80001160:	00813483          	ld	s1,8(sp)
    80001164:	00013903          	ld	s2,0(sp)
    80001168:	02010113          	addi	sp,sp,32
    8000116c:	00008067          	ret
    if (n % 4 == 0) CCB::yield();
    80001170:	00000097          	auipc	ra,0x0
    80001174:	564080e7          	jalr	1380(ra) # 800016d4 <_ZN3CCB5yieldEv>
    80001178:	fc1ff06f          	j	80001138 <_ZL9fibonaccim+0x2c>

000000008000117c <_Z11workerBodyAv>:

void workerBodyA()
{
    8000117c:	fe010113          	addi	sp,sp,-32
    80001180:	00113c23          	sd	ra,24(sp)
    80001184:	00813823          	sd	s0,16(sp)
    80001188:	00913423          	sd	s1,8(sp)
    8000118c:	01213023          	sd	s2,0(sp)
    80001190:	02010413          	addi	s0,sp,32
    uint8 i = 0;
    80001194:	00000493          	li	s1,0
    80001198:	0380006f          	j	800011d0 <_Z11workerBodyAv+0x54>
    for (; i < 3; i++)
    {
        printString("A: i=");
    8000119c:	00003517          	auipc	a0,0x3
    800011a0:	e6450513          	addi	a0,a0,-412 # 80004000 <kvmincrease+0x2b0>
    800011a4:	00000097          	auipc	ra,0x0
    800011a8:	6d0080e7          	jalr	1744(ra) # 80001874 <_Z11printStringPKc>
        printInteger(i);
    800011ac:	00048513          	mv	a0,s1
    800011b0:	00000097          	auipc	ra,0x0
    800011b4:	708080e7          	jalr	1800(ra) # 800018b8 <_Z12printIntegerm>
        printString("\n");
    800011b8:	00003517          	auipc	a0,0x3
    800011bc:	ec850513          	addi	a0,a0,-312 # 80004080 <kvmincrease+0x330>
    800011c0:	00000097          	auipc	ra,0x0
    800011c4:	6b4080e7          	jalr	1716(ra) # 80001874 <_Z11printStringPKc>
    for (; i < 3; i++)
    800011c8:	0014849b          	addiw	s1,s1,1
    800011cc:	0ff4f493          	andi	s1,s1,255
    800011d0:	00200793          	li	a5,2
    800011d4:	fc97f4e3          	bgeu	a5,s1,8000119c <_Z11workerBodyAv+0x20>
    }

    printString("A: yield\n");
    800011d8:	00003517          	auipc	a0,0x3
    800011dc:	e3050513          	addi	a0,a0,-464 # 80004008 <kvmincrease+0x2b8>
    800011e0:	00000097          	auipc	ra,0x0
    800011e4:	694080e7          	jalr	1684(ra) # 80001874 <_Z11printStringPKc>
    __asm__ ("li t1, 7");
    800011e8:	00700313          	li	t1,7
    CCB::yield();
    800011ec:	00000097          	auipc	ra,0x0
    800011f0:	4e8080e7          	jalr	1256(ra) # 800016d4 <_ZN3CCB5yieldEv>

    uint64 t1 = 0;
    __asm__ ("mv %[t1], t1" : [t1] "=r"(t1));
    800011f4:	00030913          	mv	s2,t1

    printString("A: t1=");
    800011f8:	00003517          	auipc	a0,0x3
    800011fc:	e2050513          	addi	a0,a0,-480 # 80004018 <kvmincrease+0x2c8>
    80001200:	00000097          	auipc	ra,0x0
    80001204:	674080e7          	jalr	1652(ra) # 80001874 <_Z11printStringPKc>
    printInteger(t1);
    80001208:	00090513          	mv	a0,s2
    8000120c:	00000097          	auipc	ra,0x0
    80001210:	6ac080e7          	jalr	1708(ra) # 800018b8 <_Z12printIntegerm>
    printString("\n");
    80001214:	00003517          	auipc	a0,0x3
    80001218:	e6c50513          	addi	a0,a0,-404 # 80004080 <kvmincrease+0x330>
    8000121c:	00000097          	auipc	ra,0x0
    80001220:	658080e7          	jalr	1624(ra) # 80001874 <_Z11printStringPKc>

    uint64 result = fibonacci(20);
    80001224:	01400513          	li	a0,20
    80001228:	00000097          	auipc	ra,0x0
    8000122c:	ee4080e7          	jalr	-284(ra) # 8000110c <_ZL9fibonaccim>
    80001230:	00050913          	mv	s2,a0
    printString("A: fibonaci=");
    80001234:	00003517          	auipc	a0,0x3
    80001238:	dec50513          	addi	a0,a0,-532 # 80004020 <kvmincrease+0x2d0>
    8000123c:	00000097          	auipc	ra,0x0
    80001240:	638080e7          	jalr	1592(ra) # 80001874 <_Z11printStringPKc>
    printInteger(result);
    80001244:	00090513          	mv	a0,s2
    80001248:	00000097          	auipc	ra,0x0
    8000124c:	670080e7          	jalr	1648(ra) # 800018b8 <_Z12printIntegerm>
    printString("\n");
    80001250:	00003517          	auipc	a0,0x3
    80001254:	e3050513          	addi	a0,a0,-464 # 80004080 <kvmincrease+0x330>
    80001258:	00000097          	auipc	ra,0x0
    8000125c:	61c080e7          	jalr	1564(ra) # 80001874 <_Z11printStringPKc>
    80001260:	0380006f          	j	80001298 <_Z11workerBodyAv+0x11c>

    for (; i < 6; i++)
    {
        printString("A: i=");
    80001264:	00003517          	auipc	a0,0x3
    80001268:	d9c50513          	addi	a0,a0,-612 # 80004000 <kvmincrease+0x2b0>
    8000126c:	00000097          	auipc	ra,0x0
    80001270:	608080e7          	jalr	1544(ra) # 80001874 <_Z11printStringPKc>
        printInteger(i);
    80001274:	00048513          	mv	a0,s1
    80001278:	00000097          	auipc	ra,0x0
    8000127c:	640080e7          	jalr	1600(ra) # 800018b8 <_Z12printIntegerm>
        printString("\n");
    80001280:	00003517          	auipc	a0,0x3
    80001284:	e0050513          	addi	a0,a0,-512 # 80004080 <kvmincrease+0x330>
    80001288:	00000097          	auipc	ra,0x0
    8000128c:	5ec080e7          	jalr	1516(ra) # 80001874 <_Z11printStringPKc>
    for (; i < 6; i++)
    80001290:	0014849b          	addiw	s1,s1,1
    80001294:	0ff4f493          	andi	s1,s1,255
    80001298:	00500793          	li	a5,5
    8000129c:	fc97f4e3          	bgeu	a5,s1,80001264 <_Z11workerBodyAv+0xe8>
    }

    CCB::running->setFinished(true);
    800012a0:	00003797          	auipc	a5,0x3
    800012a4:	3b87b783          	ld	a5,952(a5) # 80004658 <_GLOBAL_OFFSET_TABLE_+0x20>
    800012a8:	0007b783          	ld	a5,0(a5)
public:
    ~CCB() { delete[] stack; }

    bool isFinished() const { return finished; }

    void setFinished(bool value) { finished = value; }
    800012ac:	00100713          	li	a4,1
    800012b0:	02e78023          	sb	a4,32(a5)
    CCB::yield();
    800012b4:	00000097          	auipc	ra,0x0
    800012b8:	420080e7          	jalr	1056(ra) # 800016d4 <_ZN3CCB5yieldEv>
}
    800012bc:	01813083          	ld	ra,24(sp)
    800012c0:	01013403          	ld	s0,16(sp)
    800012c4:	00813483          	ld	s1,8(sp)
    800012c8:	00013903          	ld	s2,0(sp)
    800012cc:	02010113          	addi	sp,sp,32
    800012d0:	00008067          	ret

00000000800012d4 <_Z11workerBodyBv>:

void workerBodyB()
{
    800012d4:	fe010113          	addi	sp,sp,-32
    800012d8:	00113c23          	sd	ra,24(sp)
    800012dc:	00813823          	sd	s0,16(sp)
    800012e0:	00913423          	sd	s1,8(sp)
    800012e4:	01213023          	sd	s2,0(sp)
    800012e8:	02010413          	addi	s0,sp,32
    uint8 i = 10;
    800012ec:	00a00493          	li	s1,10
    800012f0:	0380006f          	j	80001328 <_Z11workerBodyBv+0x54>
    for (; i < 13; i++)
    {
        printString("B: i=");
    800012f4:	00003517          	auipc	a0,0x3
    800012f8:	d3c50513          	addi	a0,a0,-708 # 80004030 <kvmincrease+0x2e0>
    800012fc:	00000097          	auipc	ra,0x0
    80001300:	578080e7          	jalr	1400(ra) # 80001874 <_Z11printStringPKc>
        printInteger(i);
    80001304:	00048513          	mv	a0,s1
    80001308:	00000097          	auipc	ra,0x0
    8000130c:	5b0080e7          	jalr	1456(ra) # 800018b8 <_Z12printIntegerm>
        printString("\n");
    80001310:	00003517          	auipc	a0,0x3
    80001314:	d7050513          	addi	a0,a0,-656 # 80004080 <kvmincrease+0x330>
    80001318:	00000097          	auipc	ra,0x0
    8000131c:	55c080e7          	jalr	1372(ra) # 80001874 <_Z11printStringPKc>
    for (; i < 13; i++)
    80001320:	0014849b          	addiw	s1,s1,1
    80001324:	0ff4f493          	andi	s1,s1,255
    80001328:	00c00793          	li	a5,12
    8000132c:	fc97f4e3          	bgeu	a5,s1,800012f4 <_Z11workerBodyBv+0x20>
    }

    printString("B: yield\n");
    80001330:	00003517          	auipc	a0,0x3
    80001334:	d0850513          	addi	a0,a0,-760 # 80004038 <kvmincrease+0x2e8>
    80001338:	00000097          	auipc	ra,0x0
    8000133c:	53c080e7          	jalr	1340(ra) # 80001874 <_Z11printStringPKc>
    __asm__ ("li t1, 5");
    80001340:	00500313          	li	t1,5
    CCB::yield();
    80001344:	00000097          	auipc	ra,0x0
    80001348:	390080e7          	jalr	912(ra) # 800016d4 <_ZN3CCB5yieldEv>

    uint64 result = fibonacci(23);
    8000134c:	01700513          	li	a0,23
    80001350:	00000097          	auipc	ra,0x0
    80001354:	dbc080e7          	jalr	-580(ra) # 8000110c <_ZL9fibonaccim>
    80001358:	00050913          	mv	s2,a0
    printString("A: fibonaci=");
    8000135c:	00003517          	auipc	a0,0x3
    80001360:	cc450513          	addi	a0,a0,-828 # 80004020 <kvmincrease+0x2d0>
    80001364:	00000097          	auipc	ra,0x0
    80001368:	510080e7          	jalr	1296(ra) # 80001874 <_Z11printStringPKc>
    printInteger(result);
    8000136c:	00090513          	mv	a0,s2
    80001370:	00000097          	auipc	ra,0x0
    80001374:	548080e7          	jalr	1352(ra) # 800018b8 <_Z12printIntegerm>
    printString("\n");
    80001378:	00003517          	auipc	a0,0x3
    8000137c:	d0850513          	addi	a0,a0,-760 # 80004080 <kvmincrease+0x330>
    80001380:	00000097          	auipc	ra,0x0
    80001384:	4f4080e7          	jalr	1268(ra) # 80001874 <_Z11printStringPKc>
    80001388:	0380006f          	j	800013c0 <_Z11workerBodyBv+0xec>

    for (; i < 16; i++)
    {
        printString("B: i=");
    8000138c:	00003517          	auipc	a0,0x3
    80001390:	ca450513          	addi	a0,a0,-860 # 80004030 <kvmincrease+0x2e0>
    80001394:	00000097          	auipc	ra,0x0
    80001398:	4e0080e7          	jalr	1248(ra) # 80001874 <_Z11printStringPKc>
        printInteger(i);
    8000139c:	00048513          	mv	a0,s1
    800013a0:	00000097          	auipc	ra,0x0
    800013a4:	518080e7          	jalr	1304(ra) # 800018b8 <_Z12printIntegerm>
        printString("\n");
    800013a8:	00003517          	auipc	a0,0x3
    800013ac:	cd850513          	addi	a0,a0,-808 # 80004080 <kvmincrease+0x330>
    800013b0:	00000097          	auipc	ra,0x0
    800013b4:	4c4080e7          	jalr	1220(ra) # 80001874 <_Z11printStringPKc>
    for (; i < 16; i++)
    800013b8:	0014849b          	addiw	s1,s1,1
    800013bc:	0ff4f493          	andi	s1,s1,255
    800013c0:	00f00793          	li	a5,15
    800013c4:	fc97f4e3          	bgeu	a5,s1,8000138c <_Z11workerBodyBv+0xb8>
    }

    CCB::running->setFinished(true);
    800013c8:	00003797          	auipc	a5,0x3
    800013cc:	2907b783          	ld	a5,656(a5) # 80004658 <_GLOBAL_OFFSET_TABLE_+0x20>
    800013d0:	0007b783          	ld	a5,0(a5)
    800013d4:	00100713          	li	a4,1
    800013d8:	02e78023          	sb	a4,32(a5)
    CCB::yield();
    800013dc:	00000097          	auipc	ra,0x0
    800013e0:	2f8080e7          	jalr	760(ra) # 800016d4 <_ZN3CCB5yieldEv>
    800013e4:	01813083          	ld	ra,24(sp)
    800013e8:	01013403          	ld	s0,16(sp)
    800013ec:	00813483          	ld	s1,8(sp)
    800013f0:	00013903          	ld	s2,0(sp)
    800013f4:	02010113          	addi	sp,sp,32
    800013f8:	00008067          	ret

00000000800013fc <_Znwm>:
#include "../lib/mem.h"

using size_t = decltype(sizeof(0));

void *operator new(size_t n)
{
    800013fc:	ff010113          	addi	sp,sp,-16
    80001400:	00113423          	sd	ra,8(sp)
    80001404:	00813023          	sd	s0,0(sp)
    80001408:	01010413          	addi	s0,sp,16
    return __mem_alloc(n);
    8000140c:	00002097          	auipc	ra,0x2
    80001410:	6cc080e7          	jalr	1740(ra) # 80003ad8 <__mem_alloc>
}
    80001414:	00813083          	ld	ra,8(sp)
    80001418:	00013403          	ld	s0,0(sp)
    8000141c:	01010113          	addi	sp,sp,16
    80001420:	00008067          	ret

0000000080001424 <_Znam>:

void *operator new[](size_t n)
{
    80001424:	ff010113          	addi	sp,sp,-16
    80001428:	00113423          	sd	ra,8(sp)
    8000142c:	00813023          	sd	s0,0(sp)
    80001430:	01010413          	addi	s0,sp,16
    return __mem_alloc(n);
    80001434:	00002097          	auipc	ra,0x2
    80001438:	6a4080e7          	jalr	1700(ra) # 80003ad8 <__mem_alloc>
}
    8000143c:	00813083          	ld	ra,8(sp)
    80001440:	00013403          	ld	s0,0(sp)
    80001444:	01010113          	addi	sp,sp,16
    80001448:	00008067          	ret

000000008000144c <_ZdlPv>:

void operator delete(void *p) noexcept
{
    8000144c:	ff010113          	addi	sp,sp,-16
    80001450:	00113423          	sd	ra,8(sp)
    80001454:	00813023          	sd	s0,0(sp)
    80001458:	01010413          	addi	s0,sp,16
    __mem_free(p);
    8000145c:	00002097          	auipc	ra,0x2
    80001460:	5b0080e7          	jalr	1456(ra) # 80003a0c <__mem_free>
}
    80001464:	00813083          	ld	ra,8(sp)
    80001468:	00013403          	ld	s0,0(sp)
    8000146c:	01010113          	addi	sp,sp,16
    80001470:	00008067          	ret

0000000080001474 <_ZdaPv>:

void operator delete[](void *p) noexcept
{
    80001474:	ff010113          	addi	sp,sp,-16
    80001478:	00113423          	sd	ra,8(sp)
    8000147c:	00813023          	sd	s0,0(sp)
    80001480:	01010413          	addi	s0,sp,16
    __mem_free(p);
    80001484:	00002097          	auipc	ra,0x2
    80001488:	588080e7          	jalr	1416(ra) # 80003a0c <__mem_free>
    8000148c:	00813083          	ld	ra,8(sp)
    80001490:	00013403          	ld	s0,0(sp)
    80001494:	01010113          	addi	sp,sp,16
    80001498:	00008067          	ret

000000008000149c <main>:
#include "../h/ccb.hpp"
#include "../h/workers.hpp"
#include "../h/print.hpp"

int main()
{
    8000149c:	fc010113          	addi	sp,sp,-64
    800014a0:	02113c23          	sd	ra,56(sp)
    800014a4:	02813823          	sd	s0,48(sp)
    800014a8:	02913423          	sd	s1,40(sp)
    800014ac:	03213023          	sd	s2,32(sp)
    800014b0:	04010413          	addi	s0,sp,64
    CCB *coroutines[3];

    coroutines[0] = CCB::createCoroutine(nullptr);
    800014b4:	00000513          	li	a0,0
    800014b8:	00000097          	auipc	ra,0x0
    800014bc:	0ec080e7          	jalr	236(ra) # 800015a4 <_ZN3CCB15createCoroutineEPFvvE>
    800014c0:	fca43423          	sd	a0,-56(s0)
    CCB::running = coroutines[0];
    800014c4:	00003797          	auipc	a5,0x3
    800014c8:	1947b783          	ld	a5,404(a5) # 80004658 <_GLOBAL_OFFSET_TABLE_+0x20>
    800014cc:	00a7b023          	sd	a0,0(a5)

    coroutines[1] = CCB::createCoroutine(workerBodyA);
    800014d0:	00003517          	auipc	a0,0x3
    800014d4:	17853503          	ld	a0,376(a0) # 80004648 <_GLOBAL_OFFSET_TABLE_+0x10>
    800014d8:	00000097          	auipc	ra,0x0
    800014dc:	0cc080e7          	jalr	204(ra) # 800015a4 <_ZN3CCB15createCoroutineEPFvvE>
    800014e0:	fca43823          	sd	a0,-48(s0)
    printString("CoroutineA created\n");
    800014e4:	00003517          	auipc	a0,0x3
    800014e8:	b6450513          	addi	a0,a0,-1180 # 80004048 <kvmincrease+0x2f8>
    800014ec:	00000097          	auipc	ra,0x0
    800014f0:	388080e7          	jalr	904(ra) # 80001874 <_Z11printStringPKc>
    coroutines[2] = CCB::createCoroutine(workerBodyB);
    800014f4:	00003517          	auipc	a0,0x3
    800014f8:	14c53503          	ld	a0,332(a0) # 80004640 <_GLOBAL_OFFSET_TABLE_+0x8>
    800014fc:	00000097          	auipc	ra,0x0
    80001500:	0a8080e7          	jalr	168(ra) # 800015a4 <_ZN3CCB15createCoroutineEPFvvE>
    80001504:	fca43c23          	sd	a0,-40(s0)
    printString("CoroutineB created\n");
    80001508:	00003517          	auipc	a0,0x3
    8000150c:	b5850513          	addi	a0,a0,-1192 # 80004060 <kvmincrease+0x310>
    80001510:	00000097          	auipc	ra,0x0
    80001514:	364080e7          	jalr	868(ra) # 80001874 <_Z11printStringPKc>
    80001518:	00c0006f          	j	80001524 <main+0x88>

    while (!(coroutines[1]->isFinished() &&
             coroutines[2]->isFinished()))
    {
        CCB::yield();
    8000151c:	00000097          	auipc	ra,0x0
    80001520:	1b8080e7          	jalr	440(ra) # 800016d4 <_ZN3CCB5yieldEv>
    while (!(coroutines[1]->isFinished() &&
    80001524:	fd043783          	ld	a5,-48(s0)
    bool isFinished() const { return finished; }
    80001528:	0207c783          	lbu	a5,32(a5)
    8000152c:	fe0788e3          	beqz	a5,8000151c <main+0x80>
             coroutines[2]->isFinished()))
    80001530:	fd843783          	ld	a5,-40(s0)
    80001534:	0207c783          	lbu	a5,32(a5)
    while (!(coroutines[1]->isFinished() &&
    80001538:	fe0782e3          	beqz	a5,8000151c <main+0x80>
    8000153c:	fc840493          	addi	s1,s0,-56
    80001540:	0140006f          	j	80001554 <main+0xb8>
    }

    for (auto &coroutine: coroutines)
    {
        delete coroutine;
    80001544:	00090513          	mv	a0,s2
    80001548:	00000097          	auipc	ra,0x0
    8000154c:	f04080e7          	jalr	-252(ra) # 8000144c <_ZdlPv>
    for (auto &coroutine: coroutines)
    80001550:	00848493          	addi	s1,s1,8
    80001554:	fe040793          	addi	a5,s0,-32
    80001558:	02f48063          	beq	s1,a5,80001578 <main+0xdc>
        delete coroutine;
    8000155c:	0004b903          	ld	s2,0(s1)
    80001560:	fe0908e3          	beqz	s2,80001550 <main+0xb4>
    ~CCB() { delete[] stack; }
    80001564:	00893503          	ld	a0,8(s2)
    80001568:	fc050ee3          	beqz	a0,80001544 <main+0xa8>
    8000156c:	00000097          	auipc	ra,0x0
    80001570:	f08080e7          	jalr	-248(ra) # 80001474 <_ZdaPv>
    80001574:	fd1ff06f          	j	80001544 <main+0xa8>
    }
    printString("Finished\n");
    80001578:	00003517          	auipc	a0,0x3
    8000157c:	b0050513          	addi	a0,a0,-1280 # 80004078 <kvmincrease+0x328>
    80001580:	00000097          	auipc	ra,0x0
    80001584:	2f4080e7          	jalr	756(ra) # 80001874 <_Z11printStringPKc>

    return 0;
}
    80001588:	00000513          	li	a0,0
    8000158c:	03813083          	ld	ra,56(sp)
    80001590:	03013403          	ld	s0,48(sp)
    80001594:	02813483          	ld	s1,40(sp)
    80001598:	02013903          	ld	s2,32(sp)
    8000159c:	04010113          	addi	sp,sp,64
    800015a0:	00008067          	ret

00000000800015a4 <_ZN3CCB15createCoroutineEPFvvE>:
#include "../h/riscv.hpp"

CCB *CCB::running = nullptr;

CCB *CCB::createCoroutine(Body body)
{
    800015a4:	fe010113          	addi	sp,sp,-32
    800015a8:	00113c23          	sd	ra,24(sp)
    800015ac:	00813823          	sd	s0,16(sp)
    800015b0:	00913423          	sd	s1,8(sp)
    800015b4:	01213023          	sd	s2,0(sp)
    800015b8:	02010413          	addi	s0,sp,32
    800015bc:	00050913          	mv	s2,a0
    return new CCB(body);
    800015c0:	02800513          	li	a0,40
    800015c4:	00000097          	auipc	ra,0x0
    800015c8:	e38080e7          	jalr	-456(ra) # 800013fc <_Znwm>
    800015cc:	00050493          	mv	s1,a0
            body(body),
            stack(body != nullptr ? new uint64[STACK_SIZE] : nullptr),
            context({body != nullptr ? (uint64) body : 0,
                     stack != nullptr ? (uint64) &stack[STACK_SIZE] : 0
                    }),
            finished(false)
    800015d0:	01253023          	sd	s2,0(a0)
            stack(body != nullptr ? new uint64[STACK_SIZE] : nullptr),
    800015d4:	00090a63          	beqz	s2,800015e8 <_ZN3CCB15createCoroutineEPFvvE+0x44>
    800015d8:	00002537          	lui	a0,0x2
    800015dc:	00000097          	auipc	ra,0x0
    800015e0:	e48080e7          	jalr	-440(ra) # 80001424 <_Znam>
    800015e4:	0080006f          	j	800015ec <_ZN3CCB15createCoroutineEPFvvE+0x48>
    800015e8:	00000513          	li	a0,0
            finished(false)
    800015ec:	00a4b423          	sd	a0,8(s1)
            context({body != nullptr ? (uint64) body : 0,
    800015f0:	02090a63          	beqz	s2,80001624 <_ZN3CCB15createCoroutineEPFvvE+0x80>
    800015f4:	00090793          	mv	a5,s2
            finished(false)
    800015f8:	00f4b823          	sd	a5,16(s1)
                     stack != nullptr ? (uint64) &stack[STACK_SIZE] : 0
    800015fc:	02050863          	beqz	a0,8000162c <_ZN3CCB15createCoroutineEPFvvE+0x88>
    80001600:	000027b7          	lui	a5,0x2
    80001604:	00f50533          	add	a0,a0,a5
            finished(false)
    80001608:	00a4bc23          	sd	a0,24(s1)
    8000160c:	02048023          	sb	zero,32(s1)
    {
        if (body != nullptr) { Scheduler::put(this); }
    80001610:	04090063          	beqz	s2,80001650 <_ZN3CCB15createCoroutineEPFvvE+0xac>
    80001614:	00048513          	mv	a0,s1
    80001618:	00000097          	auipc	ra,0x0
    8000161c:	1bc080e7          	jalr	444(ra) # 800017d4 <_ZN9Scheduler3putEP3CCB>
    80001620:	0300006f          	j	80001650 <_ZN3CCB15createCoroutineEPFvvE+0xac>
            context({body != nullptr ? (uint64) body : 0,
    80001624:	00000793          	li	a5,0
    80001628:	fd1ff06f          	j	800015f8 <_ZN3CCB15createCoroutineEPFvvE+0x54>
                     stack != nullptr ? (uint64) &stack[STACK_SIZE] : 0
    8000162c:	00000513          	li	a0,0
    80001630:	fd9ff06f          	j	80001608 <_ZN3CCB15createCoroutineEPFvvE+0x64>
    80001634:	00050913          	mv	s2,a0
    80001638:	00048513          	mv	a0,s1
    8000163c:	00000097          	auipc	ra,0x0
    80001640:	e10080e7          	jalr	-496(ra) # 8000144c <_ZdlPv>
    80001644:	00090513          	mv	a0,s2
    80001648:	00004097          	auipc	ra,0x4
    8000164c:	150080e7          	jalr	336(ra) # 80005798 <_Unwind_Resume>
}
    80001650:	00048513          	mv	a0,s1
    80001654:	01813083          	ld	ra,24(sp)
    80001658:	01013403          	ld	s0,16(sp)
    8000165c:	00813483          	ld	s1,8(sp)
    80001660:	00013903          	ld	s2,0(sp)
    80001664:	02010113          	addi	sp,sp,32
    80001668:	00008067          	ret

000000008000166c <_ZN3CCB8dispatchEv>:

    Riscv::popRegisters();
}

void CCB::dispatch()
{
    8000166c:	fe010113          	addi	sp,sp,-32
    80001670:	00113c23          	sd	ra,24(sp)
    80001674:	00813823          	sd	s0,16(sp)
    80001678:	00913423          	sd	s1,8(sp)
    8000167c:	02010413          	addi	s0,sp,32
    CCB *old = running;
    80001680:	00003497          	auipc	s1,0x3
    80001684:	0304b483          	ld	s1,48(s1) # 800046b0 <_ZN3CCB7runningE>
    bool isFinished() const { return finished; }
    80001688:	0204c783          	lbu	a5,32(s1)
    if (!old->isFinished()) { Scheduler::put(old); }
    8000168c:	02078c63          	beqz	a5,800016c4 <_ZN3CCB8dispatchEv+0x58>
    running = Scheduler::get();
    80001690:	00000097          	auipc	ra,0x0
    80001694:	0dc080e7          	jalr	220(ra) # 8000176c <_ZN9Scheduler3getEv>
    80001698:	00003797          	auipc	a5,0x3
    8000169c:	00a7bc23          	sd	a0,24(a5) # 800046b0 <_ZN3CCB7runningE>

    CCB::contextSwitch(&old->context, &running->context);
    800016a0:	01050593          	addi	a1,a0,16 # 2010 <_entry-0x7fffdff0>
    800016a4:	01048513          	addi	a0,s1,16
    800016a8:	00000097          	auipc	ra,0x0
    800016ac:	958080e7          	jalr	-1704(ra) # 80001000 <_ZN3CCB13contextSwitchEPNS_7ContextES1_>
}
    800016b0:	01813083          	ld	ra,24(sp)
    800016b4:	01013403          	ld	s0,16(sp)
    800016b8:	00813483          	ld	s1,8(sp)
    800016bc:	02010113          	addi	sp,sp,32
    800016c0:	00008067          	ret
    if (!old->isFinished()) { Scheduler::put(old); }
    800016c4:	00048513          	mv	a0,s1
    800016c8:	00000097          	auipc	ra,0x0
    800016cc:	10c080e7          	jalr	268(ra) # 800017d4 <_ZN9Scheduler3putEP3CCB>
    800016d0:	fc1ff06f          	j	80001690 <_ZN3CCB8dispatchEv+0x24>

00000000800016d4 <_ZN3CCB5yieldEv>:
{
    800016d4:	ff010113          	addi	sp,sp,-16
    800016d8:	00113423          	sd	ra,8(sp)
    800016dc:	00813023          	sd	s0,0(sp)
    800016e0:	01010413          	addi	s0,sp,16
    Riscv::pushRegisters();
    800016e4:	00000097          	auipc	ra,0x0
    800016e8:	930080e7          	jalr	-1744(ra) # 80001014 <_ZN5Riscv13pushRegistersEv>
    CCB::dispatch();
    800016ec:	00000097          	auipc	ra,0x0
    800016f0:	f80080e7          	jalr	-128(ra) # 8000166c <_ZN3CCB8dispatchEv>
    Riscv::popRegisters();
    800016f4:	00000097          	auipc	ra,0x0
    800016f8:	99c080e7          	jalr	-1636(ra) # 80001090 <_ZN5Riscv12popRegistersEv>
}
    800016fc:	00813083          	ld	ra,8(sp)
    80001700:	00013403          	ld	s0,0(sp)
    80001704:	01010113          	addi	sp,sp,16
    80001708:	00008067          	ret

000000008000170c <_ZN5Riscv10popSppSpieEv>:
//

#include "../h/riscv.hpp"

void Riscv::popSppSpie()
{
    8000170c:	ff010113          	addi	sp,sp,-16
    80001710:	00813423          	sd	s0,8(sp)
    80001714:	01010413          	addi	s0,sp,16
    __asm__ volatile ("csrw sepc, ra");
    80001718:	14109073          	csrw	sepc,ra
    __asm__ volatile ("sret");
    8000171c:	10200073          	sret
    80001720:	00813403          	ld	s0,8(sp)
    80001724:	01010113          	addi	sp,sp,16
    80001728:	00008067          	ret

000000008000172c <_Z41__static_initialization_and_destruction_0ii>:
}

void Scheduler::put(CCB *ccb)
{
    readyCoroutineQueue.addLast(ccb);
    8000172c:	ff010113          	addi	sp,sp,-16
    80001730:	00813423          	sd	s0,8(sp)
    80001734:	01010413          	addi	s0,sp,16
    80001738:	00100793          	li	a5,1
    8000173c:	00f50863          	beq	a0,a5,8000174c <_Z41__static_initialization_and_destruction_0ii+0x20>
    80001740:	00813403          	ld	s0,8(sp)
    80001744:	01010113          	addi	sp,sp,16
    80001748:	00008067          	ret
    8000174c:	000107b7          	lui	a5,0x10
    80001750:	fff78793          	addi	a5,a5,-1 # ffff <_entry-0x7fff0001>
    80001754:	fef596e3          	bne	a1,a5,80001740 <_Z41__static_initialization_and_destruction_0ii+0x14>
    };

    Elem *head, *tail;

public:
    List() : head(0), tail(0) {}
    80001758:	00003797          	auipc	a5,0x3
    8000175c:	f6078793          	addi	a5,a5,-160 # 800046b8 <_ZN9Scheduler19readyCoroutineQueueE>
    80001760:	0007b023          	sd	zero,0(a5)
    80001764:	0007b423          	sd	zero,8(a5)
    80001768:	fd9ff06f          	j	80001740 <_Z41__static_initialization_and_destruction_0ii+0x14>

000000008000176c <_ZN9Scheduler3getEv>:
{
    8000176c:	fe010113          	addi	sp,sp,-32
    80001770:	00113c23          	sd	ra,24(sp)
    80001774:	00813823          	sd	s0,16(sp)
    80001778:	00913423          	sd	s1,8(sp)
    8000177c:	02010413          	addi	s0,sp,32
        }
    }

    T *removeFirst()
    {
        if (!head) { return 0; }
    80001780:	00003517          	auipc	a0,0x3
    80001784:	f3853503          	ld	a0,-200(a0) # 800046b8 <_ZN9Scheduler19readyCoroutineQueueE>
    80001788:	04050263          	beqz	a0,800017cc <_ZN9Scheduler3getEv+0x60>

        Elem *elem = head;
        head = head->next;
    8000178c:	00853783          	ld	a5,8(a0)
    80001790:	00003717          	auipc	a4,0x3
    80001794:	f2f73423          	sd	a5,-216(a4) # 800046b8 <_ZN9Scheduler19readyCoroutineQueueE>
        if (!head) { tail = 0; }
    80001798:	02078463          	beqz	a5,800017c0 <_ZN9Scheduler3getEv+0x54>

        T *ret = elem->data;
    8000179c:	00053483          	ld	s1,0(a0)
        delete elem;
    800017a0:	00000097          	auipc	ra,0x0
    800017a4:	cac080e7          	jalr	-852(ra) # 8000144c <_ZdlPv>
}
    800017a8:	00048513          	mv	a0,s1
    800017ac:	01813083          	ld	ra,24(sp)
    800017b0:	01013403          	ld	s0,16(sp)
    800017b4:	00813483          	ld	s1,8(sp)
    800017b8:	02010113          	addi	sp,sp,32
    800017bc:	00008067          	ret
        if (!head) { tail = 0; }
    800017c0:	00003797          	auipc	a5,0x3
    800017c4:	f007b023          	sd	zero,-256(a5) # 800046c0 <_ZN9Scheduler19readyCoroutineQueueE+0x8>
    800017c8:	fd5ff06f          	j	8000179c <_ZN9Scheduler3getEv+0x30>
        if (!head) { return 0; }
    800017cc:	00050493          	mv	s1,a0
    return readyCoroutineQueue.removeFirst();
    800017d0:	fd9ff06f          	j	800017a8 <_ZN9Scheduler3getEv+0x3c>

00000000800017d4 <_ZN9Scheduler3putEP3CCB>:
{
    800017d4:	fe010113          	addi	sp,sp,-32
    800017d8:	00113c23          	sd	ra,24(sp)
    800017dc:	00813823          	sd	s0,16(sp)
    800017e0:	00913423          	sd	s1,8(sp)
    800017e4:	02010413          	addi	s0,sp,32
    800017e8:	00050493          	mv	s1,a0
        Elem *elem = new Elem(data, 0);
    800017ec:	01000513          	li	a0,16
    800017f0:	00000097          	auipc	ra,0x0
    800017f4:	c0c080e7          	jalr	-1012(ra) # 800013fc <_Znwm>
        Elem(T *data, Elem *next) : data(data), next(next) {}
    800017f8:	00953023          	sd	s1,0(a0)
    800017fc:	00053423          	sd	zero,8(a0)
        if (tail)
    80001800:	00003797          	auipc	a5,0x3
    80001804:	ec07b783          	ld	a5,-320(a5) # 800046c0 <_ZN9Scheduler19readyCoroutineQueueE+0x8>
    80001808:	02078263          	beqz	a5,8000182c <_ZN9Scheduler3putEP3CCB+0x58>
            tail->next = elem;
    8000180c:	00a7b423          	sd	a0,8(a5)
            tail = elem;
    80001810:	00003797          	auipc	a5,0x3
    80001814:	eaa7b823          	sd	a0,-336(a5) # 800046c0 <_ZN9Scheduler19readyCoroutineQueueE+0x8>
    80001818:	01813083          	ld	ra,24(sp)
    8000181c:	01013403          	ld	s0,16(sp)
    80001820:	00813483          	ld	s1,8(sp)
    80001824:	02010113          	addi	sp,sp,32
    80001828:	00008067          	ret
            head = tail = elem;
    8000182c:	00003797          	auipc	a5,0x3
    80001830:	e8c78793          	addi	a5,a5,-372 # 800046b8 <_ZN9Scheduler19readyCoroutineQueueE>
    80001834:	00a7b423          	sd	a0,8(a5)
    80001838:	00a7b023          	sd	a0,0(a5)
    8000183c:	fddff06f          	j	80001818 <_ZN9Scheduler3putEP3CCB+0x44>

0000000080001840 <_GLOBAL__sub_I__ZN9Scheduler19readyCoroutineQueueE>:
    80001840:	ff010113          	addi	sp,sp,-16
    80001844:	00113423          	sd	ra,8(sp)
    80001848:	00813023          	sd	s0,0(sp)
    8000184c:	01010413          	addi	s0,sp,16
    80001850:	000105b7          	lui	a1,0x10
    80001854:	fff58593          	addi	a1,a1,-1 # ffff <_entry-0x7fff0001>
    80001858:	00100513          	li	a0,1
    8000185c:	00000097          	auipc	ra,0x0
    80001860:	ed0080e7          	jalr	-304(ra) # 8000172c <_Z41__static_initialization_and_destruction_0ii>
    80001864:	00813083          	ld	ra,8(sp)
    80001868:	00013403          	ld	s0,0(sp)
    8000186c:	01010113          	addi	sp,sp,16
    80001870:	00008067          	ret

0000000080001874 <_Z11printStringPKc>:

#include "../h/print.hpp"
#include "../lib/console.h"

void printString(char const *string)
{
    80001874:	fe010113          	addi	sp,sp,-32
    80001878:	00113c23          	sd	ra,24(sp)
    8000187c:	00813823          	sd	s0,16(sp)
    80001880:	00913423          	sd	s1,8(sp)
    80001884:	02010413          	addi	s0,sp,32
    80001888:	00050493          	mv	s1,a0
    while (*string != '\0')
    8000188c:	0004c503          	lbu	a0,0(s1)
    80001890:	00050a63          	beqz	a0,800018a4 <_Z11printStringPKc+0x30>
    {
        __putc(*string);
    80001894:	00002097          	auipc	ra,0x2
    80001898:	39c080e7          	jalr	924(ra) # 80003c30 <__putc>
        string++;
    8000189c:	00148493          	addi	s1,s1,1
    while (*string != '\0')
    800018a0:	fedff06f          	j	8000188c <_Z11printStringPKc+0x18>
    }
}
    800018a4:	01813083          	ld	ra,24(sp)
    800018a8:	01013403          	ld	s0,16(sp)
    800018ac:	00813483          	ld	s1,8(sp)
    800018b0:	02010113          	addi	sp,sp,32
    800018b4:	00008067          	ret

00000000800018b8 <_Z12printIntegerm>:

void printInteger(uint64 integer)
{
    800018b8:	fd010113          	addi	sp,sp,-48
    800018bc:	02113423          	sd	ra,40(sp)
    800018c0:	02813023          	sd	s0,32(sp)
    800018c4:	00913c23          	sd	s1,24(sp)
    800018c8:	03010413          	addi	s0,sp,48
    {
        neg = 1;
        x = -integer;
    } else
    {
        x = integer;
    800018cc:	0005051b          	sext.w	a0,a0
    }

    i = 0;
    800018d0:	00000493          	li	s1,0
    do
    {
        buf[i++] = digits[x % 10];
    800018d4:	00a00613          	li	a2,10
    800018d8:	02c5773b          	remuw	a4,a0,a2
    800018dc:	02071693          	slli	a3,a4,0x20
    800018e0:	0206d693          	srli	a3,a3,0x20
    800018e4:	00002717          	auipc	a4,0x2
    800018e8:	7a470713          	addi	a4,a4,1956 # 80004088 <_ZZ12printIntegermE6digits>
    800018ec:	00d70733          	add	a4,a4,a3
    800018f0:	00074703          	lbu	a4,0(a4)
    800018f4:	fe040693          	addi	a3,s0,-32
    800018f8:	009687b3          	add	a5,a3,s1
    800018fc:	0014849b          	addiw	s1,s1,1
    80001900:	fee78823          	sb	a4,-16(a5)
    } while ((x /= 10) != 0);
    80001904:	0005071b          	sext.w	a4,a0
    80001908:	02c5553b          	divuw	a0,a0,a2
    8000190c:	00900793          	li	a5,9
    80001910:	fce7e2e3          	bltu	a5,a4,800018d4 <_Z12printIntegerm+0x1c>
    if (neg)
        buf[i++] = '-';

    while (--i >= 0)
    80001914:	fff4849b          	addiw	s1,s1,-1
    80001918:	0004ce63          	bltz	s1,80001934 <_Z12printIntegerm+0x7c>
        __putc(buf[i]);
    8000191c:	fe040793          	addi	a5,s0,-32
    80001920:	009787b3          	add	a5,a5,s1
    80001924:	ff07c503          	lbu	a0,-16(a5)
    80001928:	00002097          	auipc	ra,0x2
    8000192c:	308080e7          	jalr	776(ra) # 80003c30 <__putc>
    80001930:	fe5ff06f          	j	80001914 <_Z12printIntegerm+0x5c>
    80001934:	02813083          	ld	ra,40(sp)
    80001938:	02013403          	ld	s0,32(sp)
    8000193c:	01813483          	ld	s1,24(sp)
    80001940:	03010113          	addi	sp,sp,48
    80001944:	00008067          	ret

0000000080001948 <start>:
    80001948:	ff010113          	addi	sp,sp,-16
    8000194c:	00813423          	sd	s0,8(sp)
    80001950:	01010413          	addi	s0,sp,16
    80001954:	300027f3          	csrr	a5,mstatus
    80001958:	ffffe737          	lui	a4,0xffffe
    8000195c:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7fff8ebf>
    80001960:	00e7f7b3          	and	a5,a5,a4
    80001964:	00001737          	lui	a4,0x1
    80001968:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    8000196c:	00e7e7b3          	or	a5,a5,a4
    80001970:	30079073          	csrw	mstatus,a5
    80001974:	00000797          	auipc	a5,0x0
    80001978:	16078793          	addi	a5,a5,352 # 80001ad4 <system_main>
    8000197c:	34179073          	csrw	mepc,a5
    80001980:	00000793          	li	a5,0
    80001984:	18079073          	csrw	satp,a5
    80001988:	000107b7          	lui	a5,0x10
    8000198c:	fff78793          	addi	a5,a5,-1 # ffff <_entry-0x7fff0001>
    80001990:	30279073          	csrw	medeleg,a5
    80001994:	30379073          	csrw	mideleg,a5
    80001998:	104027f3          	csrr	a5,sie
    8000199c:	2227e793          	ori	a5,a5,546
    800019a0:	10479073          	csrw	sie,a5
    800019a4:	fff00793          	li	a5,-1
    800019a8:	00a7d793          	srli	a5,a5,0xa
    800019ac:	3b079073          	csrw	pmpaddr0,a5
    800019b0:	00f00793          	li	a5,15
    800019b4:	3a079073          	csrw	pmpcfg0,a5
    800019b8:	f14027f3          	csrr	a5,mhartid
    800019bc:	0200c737          	lui	a4,0x200c
    800019c0:	ff873583          	ld	a1,-8(a4) # 200bff8 <_entry-0x7dff4008>
    800019c4:	0007869b          	sext.w	a3,a5
    800019c8:	00269713          	slli	a4,a3,0x2
    800019cc:	000f4637          	lui	a2,0xf4
    800019d0:	24060613          	addi	a2,a2,576 # f4240 <_entry-0x7ff0bdc0>
    800019d4:	00d70733          	add	a4,a4,a3
    800019d8:	0037979b          	slliw	a5,a5,0x3
    800019dc:	020046b7          	lui	a3,0x2004
    800019e0:	00d787b3          	add	a5,a5,a3
    800019e4:	00c585b3          	add	a1,a1,a2
    800019e8:	00371693          	slli	a3,a4,0x3
    800019ec:	00003717          	auipc	a4,0x3
    800019f0:	ce470713          	addi	a4,a4,-796 # 800046d0 <timer_scratch>
    800019f4:	00b7b023          	sd	a1,0(a5)
    800019f8:	00d70733          	add	a4,a4,a3
    800019fc:	00f73c23          	sd	a5,24(a4)
    80001a00:	02c73023          	sd	a2,32(a4)
    80001a04:	34071073          	csrw	mscratch,a4
    80001a08:	00000797          	auipc	a5,0x0
    80001a0c:	6e878793          	addi	a5,a5,1768 # 800020f0 <timervec>
    80001a10:	30579073          	csrw	mtvec,a5
    80001a14:	300027f3          	csrr	a5,mstatus
    80001a18:	0087e793          	ori	a5,a5,8
    80001a1c:	30079073          	csrw	mstatus,a5
    80001a20:	304027f3          	csrr	a5,mie
    80001a24:	0807e793          	ori	a5,a5,128
    80001a28:	30479073          	csrw	mie,a5
    80001a2c:	f14027f3          	csrr	a5,mhartid
    80001a30:	0007879b          	sext.w	a5,a5
    80001a34:	00078213          	mv	tp,a5
    80001a38:	30200073          	mret
    80001a3c:	00813403          	ld	s0,8(sp)
    80001a40:	01010113          	addi	sp,sp,16
    80001a44:	00008067          	ret

0000000080001a48 <timerinit>:
    80001a48:	ff010113          	addi	sp,sp,-16
    80001a4c:	00813423          	sd	s0,8(sp)
    80001a50:	01010413          	addi	s0,sp,16
    80001a54:	f14027f3          	csrr	a5,mhartid
    80001a58:	0200c737          	lui	a4,0x200c
    80001a5c:	ff873583          	ld	a1,-8(a4) # 200bff8 <_entry-0x7dff4008>
    80001a60:	0007869b          	sext.w	a3,a5
    80001a64:	00269713          	slli	a4,a3,0x2
    80001a68:	000f4637          	lui	a2,0xf4
    80001a6c:	24060613          	addi	a2,a2,576 # f4240 <_entry-0x7ff0bdc0>
    80001a70:	00d70733          	add	a4,a4,a3
    80001a74:	0037979b          	slliw	a5,a5,0x3
    80001a78:	020046b7          	lui	a3,0x2004
    80001a7c:	00d787b3          	add	a5,a5,a3
    80001a80:	00c585b3          	add	a1,a1,a2
    80001a84:	00371693          	slli	a3,a4,0x3
    80001a88:	00003717          	auipc	a4,0x3
    80001a8c:	c4870713          	addi	a4,a4,-952 # 800046d0 <timer_scratch>
    80001a90:	00b7b023          	sd	a1,0(a5)
    80001a94:	00d70733          	add	a4,a4,a3
    80001a98:	00f73c23          	sd	a5,24(a4)
    80001a9c:	02c73023          	sd	a2,32(a4)
    80001aa0:	34071073          	csrw	mscratch,a4
    80001aa4:	00000797          	auipc	a5,0x0
    80001aa8:	64c78793          	addi	a5,a5,1612 # 800020f0 <timervec>
    80001aac:	30579073          	csrw	mtvec,a5
    80001ab0:	300027f3          	csrr	a5,mstatus
    80001ab4:	0087e793          	ori	a5,a5,8
    80001ab8:	30079073          	csrw	mstatus,a5
    80001abc:	304027f3          	csrr	a5,mie
    80001ac0:	0807e793          	ori	a5,a5,128
    80001ac4:	30479073          	csrw	mie,a5
    80001ac8:	00813403          	ld	s0,8(sp)
    80001acc:	01010113          	addi	sp,sp,16
    80001ad0:	00008067          	ret

0000000080001ad4 <system_main>:
    80001ad4:	fe010113          	addi	sp,sp,-32
    80001ad8:	00813823          	sd	s0,16(sp)
    80001adc:	00913423          	sd	s1,8(sp)
    80001ae0:	00113c23          	sd	ra,24(sp)
    80001ae4:	02010413          	addi	s0,sp,32
    80001ae8:	00000097          	auipc	ra,0x0
    80001aec:	0c4080e7          	jalr	196(ra) # 80001bac <cpuid>
    80001af0:	00003497          	auipc	s1,0x3
    80001af4:	b9048493          	addi	s1,s1,-1136 # 80004680 <started>
    80001af8:	02050263          	beqz	a0,80001b1c <system_main+0x48>
    80001afc:	0004a783          	lw	a5,0(s1)
    80001b00:	0007879b          	sext.w	a5,a5
    80001b04:	fe078ce3          	beqz	a5,80001afc <system_main+0x28>
    80001b08:	0ff0000f          	fence
    80001b0c:	00002517          	auipc	a0,0x2
    80001b10:	5bc50513          	addi	a0,a0,1468 # 800040c8 <_ZZ12printIntegermE6digits+0x40>
    80001b14:	00001097          	auipc	ra,0x1
    80001b18:	a78080e7          	jalr	-1416(ra) # 8000258c <panic>
    80001b1c:	00001097          	auipc	ra,0x1
    80001b20:	9cc080e7          	jalr	-1588(ra) # 800024e8 <consoleinit>
    80001b24:	00001097          	auipc	ra,0x1
    80001b28:	158080e7          	jalr	344(ra) # 80002c7c <printfinit>
    80001b2c:	00002517          	auipc	a0,0x2
    80001b30:	55450513          	addi	a0,a0,1364 # 80004080 <kvmincrease+0x330>
    80001b34:	00001097          	auipc	ra,0x1
    80001b38:	ab4080e7          	jalr	-1356(ra) # 800025e8 <__printf>
    80001b3c:	00002517          	auipc	a0,0x2
    80001b40:	55c50513          	addi	a0,a0,1372 # 80004098 <_ZZ12printIntegermE6digits+0x10>
    80001b44:	00001097          	auipc	ra,0x1
    80001b48:	aa4080e7          	jalr	-1372(ra) # 800025e8 <__printf>
    80001b4c:	00002517          	auipc	a0,0x2
    80001b50:	53450513          	addi	a0,a0,1332 # 80004080 <kvmincrease+0x330>
    80001b54:	00001097          	auipc	ra,0x1
    80001b58:	a94080e7          	jalr	-1388(ra) # 800025e8 <__printf>
    80001b5c:	00001097          	auipc	ra,0x1
    80001b60:	4ac080e7          	jalr	1196(ra) # 80003008 <kinit>
    80001b64:	00000097          	auipc	ra,0x0
    80001b68:	148080e7          	jalr	328(ra) # 80001cac <trapinit>
    80001b6c:	00000097          	auipc	ra,0x0
    80001b70:	16c080e7          	jalr	364(ra) # 80001cd8 <trapinithart>
    80001b74:	00000097          	auipc	ra,0x0
    80001b78:	5bc080e7          	jalr	1468(ra) # 80002130 <plicinit>
    80001b7c:	00000097          	auipc	ra,0x0
    80001b80:	5dc080e7          	jalr	1500(ra) # 80002158 <plicinithart>
    80001b84:	00000097          	auipc	ra,0x0
    80001b88:	078080e7          	jalr	120(ra) # 80001bfc <userinit>
    80001b8c:	0ff0000f          	fence
    80001b90:	00100793          	li	a5,1
    80001b94:	00002517          	auipc	a0,0x2
    80001b98:	51c50513          	addi	a0,a0,1308 # 800040b0 <_ZZ12printIntegermE6digits+0x28>
    80001b9c:	00f4a023          	sw	a5,0(s1)
    80001ba0:	00001097          	auipc	ra,0x1
    80001ba4:	a48080e7          	jalr	-1464(ra) # 800025e8 <__printf>
    80001ba8:	0000006f          	j	80001ba8 <system_main+0xd4>

0000000080001bac <cpuid>:
    80001bac:	ff010113          	addi	sp,sp,-16
    80001bb0:	00813423          	sd	s0,8(sp)
    80001bb4:	01010413          	addi	s0,sp,16
    80001bb8:	00020513          	mv	a0,tp
    80001bbc:	00813403          	ld	s0,8(sp)
    80001bc0:	0005051b          	sext.w	a0,a0
    80001bc4:	01010113          	addi	sp,sp,16
    80001bc8:	00008067          	ret

0000000080001bcc <mycpu>:
    80001bcc:	ff010113          	addi	sp,sp,-16
    80001bd0:	00813423          	sd	s0,8(sp)
    80001bd4:	01010413          	addi	s0,sp,16
    80001bd8:	00020793          	mv	a5,tp
    80001bdc:	00813403          	ld	s0,8(sp)
    80001be0:	0007879b          	sext.w	a5,a5
    80001be4:	00779793          	slli	a5,a5,0x7
    80001be8:	00004517          	auipc	a0,0x4
    80001bec:	b1850513          	addi	a0,a0,-1256 # 80005700 <cpus>
    80001bf0:	00f50533          	add	a0,a0,a5
    80001bf4:	01010113          	addi	sp,sp,16
    80001bf8:	00008067          	ret

0000000080001bfc <userinit>:
    80001bfc:	ff010113          	addi	sp,sp,-16
    80001c00:	00813423          	sd	s0,8(sp)
    80001c04:	01010413          	addi	s0,sp,16
    80001c08:	00813403          	ld	s0,8(sp)
    80001c0c:	01010113          	addi	sp,sp,16
    80001c10:	00000317          	auipc	t1,0x0
    80001c14:	88c30067          	jr	-1908(t1) # 8000149c <main>

0000000080001c18 <either_copyout>:
    80001c18:	ff010113          	addi	sp,sp,-16
    80001c1c:	00813023          	sd	s0,0(sp)
    80001c20:	00113423          	sd	ra,8(sp)
    80001c24:	01010413          	addi	s0,sp,16
    80001c28:	02051663          	bnez	a0,80001c54 <either_copyout+0x3c>
    80001c2c:	00058513          	mv	a0,a1
    80001c30:	00060593          	mv	a1,a2
    80001c34:	0006861b          	sext.w	a2,a3
    80001c38:	00002097          	auipc	ra,0x2
    80001c3c:	c5c080e7          	jalr	-932(ra) # 80003894 <__memmove>
    80001c40:	00813083          	ld	ra,8(sp)
    80001c44:	00013403          	ld	s0,0(sp)
    80001c48:	00000513          	li	a0,0
    80001c4c:	01010113          	addi	sp,sp,16
    80001c50:	00008067          	ret
    80001c54:	00002517          	auipc	a0,0x2
    80001c58:	49c50513          	addi	a0,a0,1180 # 800040f0 <_ZZ12printIntegermE6digits+0x68>
    80001c5c:	00001097          	auipc	ra,0x1
    80001c60:	930080e7          	jalr	-1744(ra) # 8000258c <panic>

0000000080001c64 <either_copyin>:
    80001c64:	ff010113          	addi	sp,sp,-16
    80001c68:	00813023          	sd	s0,0(sp)
    80001c6c:	00113423          	sd	ra,8(sp)
    80001c70:	01010413          	addi	s0,sp,16
    80001c74:	02059463          	bnez	a1,80001c9c <either_copyin+0x38>
    80001c78:	00060593          	mv	a1,a2
    80001c7c:	0006861b          	sext.w	a2,a3
    80001c80:	00002097          	auipc	ra,0x2
    80001c84:	c14080e7          	jalr	-1004(ra) # 80003894 <__memmove>
    80001c88:	00813083          	ld	ra,8(sp)
    80001c8c:	00013403          	ld	s0,0(sp)
    80001c90:	00000513          	li	a0,0
    80001c94:	01010113          	addi	sp,sp,16
    80001c98:	00008067          	ret
    80001c9c:	00002517          	auipc	a0,0x2
    80001ca0:	47c50513          	addi	a0,a0,1148 # 80004118 <_ZZ12printIntegermE6digits+0x90>
    80001ca4:	00001097          	auipc	ra,0x1
    80001ca8:	8e8080e7          	jalr	-1816(ra) # 8000258c <panic>

0000000080001cac <trapinit>:
    80001cac:	ff010113          	addi	sp,sp,-16
    80001cb0:	00813423          	sd	s0,8(sp)
    80001cb4:	01010413          	addi	s0,sp,16
    80001cb8:	00813403          	ld	s0,8(sp)
    80001cbc:	00002597          	auipc	a1,0x2
    80001cc0:	48458593          	addi	a1,a1,1156 # 80004140 <_ZZ12printIntegermE6digits+0xb8>
    80001cc4:	00004517          	auipc	a0,0x4
    80001cc8:	abc50513          	addi	a0,a0,-1348 # 80005780 <tickslock>
    80001ccc:	01010113          	addi	sp,sp,16
    80001cd0:	00001317          	auipc	t1,0x1
    80001cd4:	5c830067          	jr	1480(t1) # 80003298 <initlock>

0000000080001cd8 <trapinithart>:
    80001cd8:	ff010113          	addi	sp,sp,-16
    80001cdc:	00813423          	sd	s0,8(sp)
    80001ce0:	01010413          	addi	s0,sp,16
    80001ce4:	00000797          	auipc	a5,0x0
    80001ce8:	2fc78793          	addi	a5,a5,764 # 80001fe0 <kernelvec>
    80001cec:	10579073          	csrw	stvec,a5
    80001cf0:	00813403          	ld	s0,8(sp)
    80001cf4:	01010113          	addi	sp,sp,16
    80001cf8:	00008067          	ret

0000000080001cfc <usertrap>:
    80001cfc:	ff010113          	addi	sp,sp,-16
    80001d00:	00813423          	sd	s0,8(sp)
    80001d04:	01010413          	addi	s0,sp,16
    80001d08:	00813403          	ld	s0,8(sp)
    80001d0c:	01010113          	addi	sp,sp,16
    80001d10:	00008067          	ret

0000000080001d14 <usertrapret>:
    80001d14:	ff010113          	addi	sp,sp,-16
    80001d18:	00813423          	sd	s0,8(sp)
    80001d1c:	01010413          	addi	s0,sp,16
    80001d20:	00813403          	ld	s0,8(sp)
    80001d24:	01010113          	addi	sp,sp,16
    80001d28:	00008067          	ret

0000000080001d2c <kerneltrap>:
    80001d2c:	fe010113          	addi	sp,sp,-32
    80001d30:	00813823          	sd	s0,16(sp)
    80001d34:	00113c23          	sd	ra,24(sp)
    80001d38:	00913423          	sd	s1,8(sp)
    80001d3c:	02010413          	addi	s0,sp,32
    80001d40:	142025f3          	csrr	a1,scause
    80001d44:	100027f3          	csrr	a5,sstatus
    80001d48:	0027f793          	andi	a5,a5,2
    80001d4c:	10079c63          	bnez	a5,80001e64 <kerneltrap+0x138>
    80001d50:	142027f3          	csrr	a5,scause
    80001d54:	0207ce63          	bltz	a5,80001d90 <kerneltrap+0x64>
    80001d58:	00002517          	auipc	a0,0x2
    80001d5c:	43050513          	addi	a0,a0,1072 # 80004188 <_ZZ12printIntegermE6digits+0x100>
    80001d60:	00001097          	auipc	ra,0x1
    80001d64:	888080e7          	jalr	-1912(ra) # 800025e8 <__printf>
    80001d68:	141025f3          	csrr	a1,sepc
    80001d6c:	14302673          	csrr	a2,stval
    80001d70:	00002517          	auipc	a0,0x2
    80001d74:	42850513          	addi	a0,a0,1064 # 80004198 <_ZZ12printIntegermE6digits+0x110>
    80001d78:	00001097          	auipc	ra,0x1
    80001d7c:	870080e7          	jalr	-1936(ra) # 800025e8 <__printf>
    80001d80:	00002517          	auipc	a0,0x2
    80001d84:	43050513          	addi	a0,a0,1072 # 800041b0 <_ZZ12printIntegermE6digits+0x128>
    80001d88:	00001097          	auipc	ra,0x1
    80001d8c:	804080e7          	jalr	-2044(ra) # 8000258c <panic>
    80001d90:	0ff7f713          	andi	a4,a5,255
    80001d94:	00900693          	li	a3,9
    80001d98:	04d70063          	beq	a4,a3,80001dd8 <kerneltrap+0xac>
    80001d9c:	fff00713          	li	a4,-1
    80001da0:	03f71713          	slli	a4,a4,0x3f
    80001da4:	00170713          	addi	a4,a4,1
    80001da8:	fae798e3          	bne	a5,a4,80001d58 <kerneltrap+0x2c>
    80001dac:	00000097          	auipc	ra,0x0
    80001db0:	e00080e7          	jalr	-512(ra) # 80001bac <cpuid>
    80001db4:	06050663          	beqz	a0,80001e20 <kerneltrap+0xf4>
    80001db8:	144027f3          	csrr	a5,sip
    80001dbc:	ffd7f793          	andi	a5,a5,-3
    80001dc0:	14479073          	csrw	sip,a5
    80001dc4:	01813083          	ld	ra,24(sp)
    80001dc8:	01013403          	ld	s0,16(sp)
    80001dcc:	00813483          	ld	s1,8(sp)
    80001dd0:	02010113          	addi	sp,sp,32
    80001dd4:	00008067          	ret
    80001dd8:	00000097          	auipc	ra,0x0
    80001ddc:	3cc080e7          	jalr	972(ra) # 800021a4 <plic_claim>
    80001de0:	00a00793          	li	a5,10
    80001de4:	00050493          	mv	s1,a0
    80001de8:	06f50863          	beq	a0,a5,80001e58 <kerneltrap+0x12c>
    80001dec:	fc050ce3          	beqz	a0,80001dc4 <kerneltrap+0x98>
    80001df0:	00050593          	mv	a1,a0
    80001df4:	00002517          	auipc	a0,0x2
    80001df8:	37450513          	addi	a0,a0,884 # 80004168 <_ZZ12printIntegermE6digits+0xe0>
    80001dfc:	00000097          	auipc	ra,0x0
    80001e00:	7ec080e7          	jalr	2028(ra) # 800025e8 <__printf>
    80001e04:	01013403          	ld	s0,16(sp)
    80001e08:	01813083          	ld	ra,24(sp)
    80001e0c:	00048513          	mv	a0,s1
    80001e10:	00813483          	ld	s1,8(sp)
    80001e14:	02010113          	addi	sp,sp,32
    80001e18:	00000317          	auipc	t1,0x0
    80001e1c:	3c430067          	jr	964(t1) # 800021dc <plic_complete>
    80001e20:	00004517          	auipc	a0,0x4
    80001e24:	96050513          	addi	a0,a0,-1696 # 80005780 <tickslock>
    80001e28:	00001097          	auipc	ra,0x1
    80001e2c:	494080e7          	jalr	1172(ra) # 800032bc <acquire>
    80001e30:	00003717          	auipc	a4,0x3
    80001e34:	85470713          	addi	a4,a4,-1964 # 80004684 <ticks>
    80001e38:	00072783          	lw	a5,0(a4)
    80001e3c:	00004517          	auipc	a0,0x4
    80001e40:	94450513          	addi	a0,a0,-1724 # 80005780 <tickslock>
    80001e44:	0017879b          	addiw	a5,a5,1
    80001e48:	00f72023          	sw	a5,0(a4)
    80001e4c:	00001097          	auipc	ra,0x1
    80001e50:	53c080e7          	jalr	1340(ra) # 80003388 <release>
    80001e54:	f65ff06f          	j	80001db8 <kerneltrap+0x8c>
    80001e58:	00001097          	auipc	ra,0x1
    80001e5c:	098080e7          	jalr	152(ra) # 80002ef0 <uartintr>
    80001e60:	fa5ff06f          	j	80001e04 <kerneltrap+0xd8>
    80001e64:	00002517          	auipc	a0,0x2
    80001e68:	2e450513          	addi	a0,a0,740 # 80004148 <_ZZ12printIntegermE6digits+0xc0>
    80001e6c:	00000097          	auipc	ra,0x0
    80001e70:	720080e7          	jalr	1824(ra) # 8000258c <panic>

0000000080001e74 <clockintr>:
    80001e74:	fe010113          	addi	sp,sp,-32
    80001e78:	00813823          	sd	s0,16(sp)
    80001e7c:	00913423          	sd	s1,8(sp)
    80001e80:	00113c23          	sd	ra,24(sp)
    80001e84:	02010413          	addi	s0,sp,32
    80001e88:	00004497          	auipc	s1,0x4
    80001e8c:	8f848493          	addi	s1,s1,-1800 # 80005780 <tickslock>
    80001e90:	00048513          	mv	a0,s1
    80001e94:	00001097          	auipc	ra,0x1
    80001e98:	428080e7          	jalr	1064(ra) # 800032bc <acquire>
    80001e9c:	00002717          	auipc	a4,0x2
    80001ea0:	7e870713          	addi	a4,a4,2024 # 80004684 <ticks>
    80001ea4:	00072783          	lw	a5,0(a4)
    80001ea8:	01013403          	ld	s0,16(sp)
    80001eac:	01813083          	ld	ra,24(sp)
    80001eb0:	00048513          	mv	a0,s1
    80001eb4:	0017879b          	addiw	a5,a5,1
    80001eb8:	00813483          	ld	s1,8(sp)
    80001ebc:	00f72023          	sw	a5,0(a4)
    80001ec0:	02010113          	addi	sp,sp,32
    80001ec4:	00001317          	auipc	t1,0x1
    80001ec8:	4c430067          	jr	1220(t1) # 80003388 <release>

0000000080001ecc <devintr>:
    80001ecc:	142027f3          	csrr	a5,scause
    80001ed0:	00000513          	li	a0,0
    80001ed4:	0007c463          	bltz	a5,80001edc <devintr+0x10>
    80001ed8:	00008067          	ret
    80001edc:	fe010113          	addi	sp,sp,-32
    80001ee0:	00813823          	sd	s0,16(sp)
    80001ee4:	00113c23          	sd	ra,24(sp)
    80001ee8:	00913423          	sd	s1,8(sp)
    80001eec:	02010413          	addi	s0,sp,32
    80001ef0:	0ff7f713          	andi	a4,a5,255
    80001ef4:	00900693          	li	a3,9
    80001ef8:	04d70c63          	beq	a4,a3,80001f50 <devintr+0x84>
    80001efc:	fff00713          	li	a4,-1
    80001f00:	03f71713          	slli	a4,a4,0x3f
    80001f04:	00170713          	addi	a4,a4,1
    80001f08:	00e78c63          	beq	a5,a4,80001f20 <devintr+0x54>
    80001f0c:	01813083          	ld	ra,24(sp)
    80001f10:	01013403          	ld	s0,16(sp)
    80001f14:	00813483          	ld	s1,8(sp)
    80001f18:	02010113          	addi	sp,sp,32
    80001f1c:	00008067          	ret
    80001f20:	00000097          	auipc	ra,0x0
    80001f24:	c8c080e7          	jalr	-884(ra) # 80001bac <cpuid>
    80001f28:	06050663          	beqz	a0,80001f94 <devintr+0xc8>
    80001f2c:	144027f3          	csrr	a5,sip
    80001f30:	ffd7f793          	andi	a5,a5,-3
    80001f34:	14479073          	csrw	sip,a5
    80001f38:	01813083          	ld	ra,24(sp)
    80001f3c:	01013403          	ld	s0,16(sp)
    80001f40:	00813483          	ld	s1,8(sp)
    80001f44:	00200513          	li	a0,2
    80001f48:	02010113          	addi	sp,sp,32
    80001f4c:	00008067          	ret
    80001f50:	00000097          	auipc	ra,0x0
    80001f54:	254080e7          	jalr	596(ra) # 800021a4 <plic_claim>
    80001f58:	00a00793          	li	a5,10
    80001f5c:	00050493          	mv	s1,a0
    80001f60:	06f50663          	beq	a0,a5,80001fcc <devintr+0x100>
    80001f64:	00100513          	li	a0,1
    80001f68:	fa0482e3          	beqz	s1,80001f0c <devintr+0x40>
    80001f6c:	00048593          	mv	a1,s1
    80001f70:	00002517          	auipc	a0,0x2
    80001f74:	1f850513          	addi	a0,a0,504 # 80004168 <_ZZ12printIntegermE6digits+0xe0>
    80001f78:	00000097          	auipc	ra,0x0
    80001f7c:	670080e7          	jalr	1648(ra) # 800025e8 <__printf>
    80001f80:	00048513          	mv	a0,s1
    80001f84:	00000097          	auipc	ra,0x0
    80001f88:	258080e7          	jalr	600(ra) # 800021dc <plic_complete>
    80001f8c:	00100513          	li	a0,1
    80001f90:	f7dff06f          	j	80001f0c <devintr+0x40>
    80001f94:	00003517          	auipc	a0,0x3
    80001f98:	7ec50513          	addi	a0,a0,2028 # 80005780 <tickslock>
    80001f9c:	00001097          	auipc	ra,0x1
    80001fa0:	320080e7          	jalr	800(ra) # 800032bc <acquire>
    80001fa4:	00002717          	auipc	a4,0x2
    80001fa8:	6e070713          	addi	a4,a4,1760 # 80004684 <ticks>
    80001fac:	00072783          	lw	a5,0(a4)
    80001fb0:	00003517          	auipc	a0,0x3
    80001fb4:	7d050513          	addi	a0,a0,2000 # 80005780 <tickslock>
    80001fb8:	0017879b          	addiw	a5,a5,1
    80001fbc:	00f72023          	sw	a5,0(a4)
    80001fc0:	00001097          	auipc	ra,0x1
    80001fc4:	3c8080e7          	jalr	968(ra) # 80003388 <release>
    80001fc8:	f65ff06f          	j	80001f2c <devintr+0x60>
    80001fcc:	00001097          	auipc	ra,0x1
    80001fd0:	f24080e7          	jalr	-220(ra) # 80002ef0 <uartintr>
    80001fd4:	fadff06f          	j	80001f80 <devintr+0xb4>
	...

0000000080001fe0 <kernelvec>:
    80001fe0:	f0010113          	addi	sp,sp,-256
    80001fe4:	00113023          	sd	ra,0(sp)
    80001fe8:	00213423          	sd	sp,8(sp)
    80001fec:	00313823          	sd	gp,16(sp)
    80001ff0:	00413c23          	sd	tp,24(sp)
    80001ff4:	02513023          	sd	t0,32(sp)
    80001ff8:	02613423          	sd	t1,40(sp)
    80001ffc:	02713823          	sd	t2,48(sp)
    80002000:	02813c23          	sd	s0,56(sp)
    80002004:	04913023          	sd	s1,64(sp)
    80002008:	04a13423          	sd	a0,72(sp)
    8000200c:	04b13823          	sd	a1,80(sp)
    80002010:	04c13c23          	sd	a2,88(sp)
    80002014:	06d13023          	sd	a3,96(sp)
    80002018:	06e13423          	sd	a4,104(sp)
    8000201c:	06f13823          	sd	a5,112(sp)
    80002020:	07013c23          	sd	a6,120(sp)
    80002024:	09113023          	sd	a7,128(sp)
    80002028:	09213423          	sd	s2,136(sp)
    8000202c:	09313823          	sd	s3,144(sp)
    80002030:	09413c23          	sd	s4,152(sp)
    80002034:	0b513023          	sd	s5,160(sp)
    80002038:	0b613423          	sd	s6,168(sp)
    8000203c:	0b713823          	sd	s7,176(sp)
    80002040:	0b813c23          	sd	s8,184(sp)
    80002044:	0d913023          	sd	s9,192(sp)
    80002048:	0da13423          	sd	s10,200(sp)
    8000204c:	0db13823          	sd	s11,208(sp)
    80002050:	0dc13c23          	sd	t3,216(sp)
    80002054:	0fd13023          	sd	t4,224(sp)
    80002058:	0fe13423          	sd	t5,232(sp)
    8000205c:	0ff13823          	sd	t6,240(sp)
    80002060:	ccdff0ef          	jal	ra,80001d2c <kerneltrap>
    80002064:	00013083          	ld	ra,0(sp)
    80002068:	00813103          	ld	sp,8(sp)
    8000206c:	01013183          	ld	gp,16(sp)
    80002070:	02013283          	ld	t0,32(sp)
    80002074:	02813303          	ld	t1,40(sp)
    80002078:	03013383          	ld	t2,48(sp)
    8000207c:	03813403          	ld	s0,56(sp)
    80002080:	04013483          	ld	s1,64(sp)
    80002084:	04813503          	ld	a0,72(sp)
    80002088:	05013583          	ld	a1,80(sp)
    8000208c:	05813603          	ld	a2,88(sp)
    80002090:	06013683          	ld	a3,96(sp)
    80002094:	06813703          	ld	a4,104(sp)
    80002098:	07013783          	ld	a5,112(sp)
    8000209c:	07813803          	ld	a6,120(sp)
    800020a0:	08013883          	ld	a7,128(sp)
    800020a4:	08813903          	ld	s2,136(sp)
    800020a8:	09013983          	ld	s3,144(sp)
    800020ac:	09813a03          	ld	s4,152(sp)
    800020b0:	0a013a83          	ld	s5,160(sp)
    800020b4:	0a813b03          	ld	s6,168(sp)
    800020b8:	0b013b83          	ld	s7,176(sp)
    800020bc:	0b813c03          	ld	s8,184(sp)
    800020c0:	0c013c83          	ld	s9,192(sp)
    800020c4:	0c813d03          	ld	s10,200(sp)
    800020c8:	0d013d83          	ld	s11,208(sp)
    800020cc:	0d813e03          	ld	t3,216(sp)
    800020d0:	0e013e83          	ld	t4,224(sp)
    800020d4:	0e813f03          	ld	t5,232(sp)
    800020d8:	0f013f83          	ld	t6,240(sp)
    800020dc:	10010113          	addi	sp,sp,256
    800020e0:	10200073          	sret
    800020e4:	00000013          	nop
    800020e8:	00000013          	nop
    800020ec:	00000013          	nop

00000000800020f0 <timervec>:
    800020f0:	34051573          	csrrw	a0,mscratch,a0
    800020f4:	00b53023          	sd	a1,0(a0)
    800020f8:	00c53423          	sd	a2,8(a0)
    800020fc:	00d53823          	sd	a3,16(a0)
    80002100:	01853583          	ld	a1,24(a0)
    80002104:	02053603          	ld	a2,32(a0)
    80002108:	0005b683          	ld	a3,0(a1)
    8000210c:	00c686b3          	add	a3,a3,a2
    80002110:	00d5b023          	sd	a3,0(a1)
    80002114:	00200593          	li	a1,2
    80002118:	14459073          	csrw	sip,a1
    8000211c:	01053683          	ld	a3,16(a0)
    80002120:	00853603          	ld	a2,8(a0)
    80002124:	00053583          	ld	a1,0(a0)
    80002128:	34051573          	csrrw	a0,mscratch,a0
    8000212c:	30200073          	mret

0000000080002130 <plicinit>:
    80002130:	ff010113          	addi	sp,sp,-16
    80002134:	00813423          	sd	s0,8(sp)
    80002138:	01010413          	addi	s0,sp,16
    8000213c:	00813403          	ld	s0,8(sp)
    80002140:	0c0007b7          	lui	a5,0xc000
    80002144:	00100713          	li	a4,1
    80002148:	02e7a423          	sw	a4,40(a5) # c000028 <_entry-0x73ffffd8>
    8000214c:	00e7a223          	sw	a4,4(a5)
    80002150:	01010113          	addi	sp,sp,16
    80002154:	00008067          	ret

0000000080002158 <plicinithart>:
    80002158:	ff010113          	addi	sp,sp,-16
    8000215c:	00813023          	sd	s0,0(sp)
    80002160:	00113423          	sd	ra,8(sp)
    80002164:	01010413          	addi	s0,sp,16
    80002168:	00000097          	auipc	ra,0x0
    8000216c:	a44080e7          	jalr	-1468(ra) # 80001bac <cpuid>
    80002170:	0085171b          	slliw	a4,a0,0x8
    80002174:	0c0027b7          	lui	a5,0xc002
    80002178:	00e787b3          	add	a5,a5,a4
    8000217c:	40200713          	li	a4,1026
    80002180:	08e7a023          	sw	a4,128(a5) # c002080 <_entry-0x73ffdf80>
    80002184:	00813083          	ld	ra,8(sp)
    80002188:	00013403          	ld	s0,0(sp)
    8000218c:	00d5151b          	slliw	a0,a0,0xd
    80002190:	0c2017b7          	lui	a5,0xc201
    80002194:	00a78533          	add	a0,a5,a0
    80002198:	00052023          	sw	zero,0(a0)
    8000219c:	01010113          	addi	sp,sp,16
    800021a0:	00008067          	ret

00000000800021a4 <plic_claim>:
    800021a4:	ff010113          	addi	sp,sp,-16
    800021a8:	00813023          	sd	s0,0(sp)
    800021ac:	00113423          	sd	ra,8(sp)
    800021b0:	01010413          	addi	s0,sp,16
    800021b4:	00000097          	auipc	ra,0x0
    800021b8:	9f8080e7          	jalr	-1544(ra) # 80001bac <cpuid>
    800021bc:	00813083          	ld	ra,8(sp)
    800021c0:	00013403          	ld	s0,0(sp)
    800021c4:	00d5151b          	slliw	a0,a0,0xd
    800021c8:	0c2017b7          	lui	a5,0xc201
    800021cc:	00a78533          	add	a0,a5,a0
    800021d0:	00452503          	lw	a0,4(a0)
    800021d4:	01010113          	addi	sp,sp,16
    800021d8:	00008067          	ret

00000000800021dc <plic_complete>:
    800021dc:	fe010113          	addi	sp,sp,-32
    800021e0:	00813823          	sd	s0,16(sp)
    800021e4:	00913423          	sd	s1,8(sp)
    800021e8:	00113c23          	sd	ra,24(sp)
    800021ec:	02010413          	addi	s0,sp,32
    800021f0:	00050493          	mv	s1,a0
    800021f4:	00000097          	auipc	ra,0x0
    800021f8:	9b8080e7          	jalr	-1608(ra) # 80001bac <cpuid>
    800021fc:	01813083          	ld	ra,24(sp)
    80002200:	01013403          	ld	s0,16(sp)
    80002204:	00d5179b          	slliw	a5,a0,0xd
    80002208:	0c201737          	lui	a4,0xc201
    8000220c:	00f707b3          	add	a5,a4,a5
    80002210:	0097a223          	sw	s1,4(a5) # c201004 <_entry-0x73dfeffc>
    80002214:	00813483          	ld	s1,8(sp)
    80002218:	02010113          	addi	sp,sp,32
    8000221c:	00008067          	ret

0000000080002220 <consolewrite>:
    80002220:	fb010113          	addi	sp,sp,-80
    80002224:	04813023          	sd	s0,64(sp)
    80002228:	04113423          	sd	ra,72(sp)
    8000222c:	02913c23          	sd	s1,56(sp)
    80002230:	03213823          	sd	s2,48(sp)
    80002234:	03313423          	sd	s3,40(sp)
    80002238:	03413023          	sd	s4,32(sp)
    8000223c:	01513c23          	sd	s5,24(sp)
    80002240:	05010413          	addi	s0,sp,80
    80002244:	06c05c63          	blez	a2,800022bc <consolewrite+0x9c>
    80002248:	00060993          	mv	s3,a2
    8000224c:	00050a13          	mv	s4,a0
    80002250:	00058493          	mv	s1,a1
    80002254:	00000913          	li	s2,0
    80002258:	fff00a93          	li	s5,-1
    8000225c:	01c0006f          	j	80002278 <consolewrite+0x58>
    80002260:	fbf44503          	lbu	a0,-65(s0)
    80002264:	0019091b          	addiw	s2,s2,1
    80002268:	00148493          	addi	s1,s1,1
    8000226c:	00001097          	auipc	ra,0x1
    80002270:	a9c080e7          	jalr	-1380(ra) # 80002d08 <uartputc>
    80002274:	03298063          	beq	s3,s2,80002294 <consolewrite+0x74>
    80002278:	00048613          	mv	a2,s1
    8000227c:	00100693          	li	a3,1
    80002280:	000a0593          	mv	a1,s4
    80002284:	fbf40513          	addi	a0,s0,-65
    80002288:	00000097          	auipc	ra,0x0
    8000228c:	9dc080e7          	jalr	-1572(ra) # 80001c64 <either_copyin>
    80002290:	fd5518e3          	bne	a0,s5,80002260 <consolewrite+0x40>
    80002294:	04813083          	ld	ra,72(sp)
    80002298:	04013403          	ld	s0,64(sp)
    8000229c:	03813483          	ld	s1,56(sp)
    800022a0:	02813983          	ld	s3,40(sp)
    800022a4:	02013a03          	ld	s4,32(sp)
    800022a8:	01813a83          	ld	s5,24(sp)
    800022ac:	00090513          	mv	a0,s2
    800022b0:	03013903          	ld	s2,48(sp)
    800022b4:	05010113          	addi	sp,sp,80
    800022b8:	00008067          	ret
    800022bc:	00000913          	li	s2,0
    800022c0:	fd5ff06f          	j	80002294 <consolewrite+0x74>

00000000800022c4 <consoleread>:
    800022c4:	f9010113          	addi	sp,sp,-112
    800022c8:	06813023          	sd	s0,96(sp)
    800022cc:	04913c23          	sd	s1,88(sp)
    800022d0:	05213823          	sd	s2,80(sp)
    800022d4:	05313423          	sd	s3,72(sp)
    800022d8:	05413023          	sd	s4,64(sp)
    800022dc:	03513c23          	sd	s5,56(sp)
    800022e0:	03613823          	sd	s6,48(sp)
    800022e4:	03713423          	sd	s7,40(sp)
    800022e8:	03813023          	sd	s8,32(sp)
    800022ec:	06113423          	sd	ra,104(sp)
    800022f0:	01913c23          	sd	s9,24(sp)
    800022f4:	07010413          	addi	s0,sp,112
    800022f8:	00060b93          	mv	s7,a2
    800022fc:	00050913          	mv	s2,a0
    80002300:	00058c13          	mv	s8,a1
    80002304:	00060b1b          	sext.w	s6,a2
    80002308:	00003497          	auipc	s1,0x3
    8000230c:	4a048493          	addi	s1,s1,1184 # 800057a8 <cons>
    80002310:	00400993          	li	s3,4
    80002314:	fff00a13          	li	s4,-1
    80002318:	00a00a93          	li	s5,10
    8000231c:	05705e63          	blez	s7,80002378 <consoleread+0xb4>
    80002320:	09c4a703          	lw	a4,156(s1)
    80002324:	0984a783          	lw	a5,152(s1)
    80002328:	0007071b          	sext.w	a4,a4
    8000232c:	08e78463          	beq	a5,a4,800023b4 <consoleread+0xf0>
    80002330:	07f7f713          	andi	a4,a5,127
    80002334:	00e48733          	add	a4,s1,a4
    80002338:	01874703          	lbu	a4,24(a4) # c201018 <_entry-0x73dfefe8>
    8000233c:	0017869b          	addiw	a3,a5,1
    80002340:	08d4ac23          	sw	a3,152(s1)
    80002344:	00070c9b          	sext.w	s9,a4
    80002348:	0b370663          	beq	a4,s3,800023f4 <consoleread+0x130>
    8000234c:	00100693          	li	a3,1
    80002350:	f9f40613          	addi	a2,s0,-97
    80002354:	000c0593          	mv	a1,s8
    80002358:	00090513          	mv	a0,s2
    8000235c:	f8e40fa3          	sb	a4,-97(s0)
    80002360:	00000097          	auipc	ra,0x0
    80002364:	8b8080e7          	jalr	-1864(ra) # 80001c18 <either_copyout>
    80002368:	01450863          	beq	a0,s4,80002378 <consoleread+0xb4>
    8000236c:	001c0c13          	addi	s8,s8,1
    80002370:	fffb8b9b          	addiw	s7,s7,-1
    80002374:	fb5c94e3          	bne	s9,s5,8000231c <consoleread+0x58>
    80002378:	000b851b          	sext.w	a0,s7
    8000237c:	06813083          	ld	ra,104(sp)
    80002380:	06013403          	ld	s0,96(sp)
    80002384:	05813483          	ld	s1,88(sp)
    80002388:	05013903          	ld	s2,80(sp)
    8000238c:	04813983          	ld	s3,72(sp)
    80002390:	04013a03          	ld	s4,64(sp)
    80002394:	03813a83          	ld	s5,56(sp)
    80002398:	02813b83          	ld	s7,40(sp)
    8000239c:	02013c03          	ld	s8,32(sp)
    800023a0:	01813c83          	ld	s9,24(sp)
    800023a4:	40ab053b          	subw	a0,s6,a0
    800023a8:	03013b03          	ld	s6,48(sp)
    800023ac:	07010113          	addi	sp,sp,112
    800023b0:	00008067          	ret
    800023b4:	00001097          	auipc	ra,0x1
    800023b8:	1d8080e7          	jalr	472(ra) # 8000358c <push_on>
    800023bc:	0984a703          	lw	a4,152(s1)
    800023c0:	09c4a783          	lw	a5,156(s1)
    800023c4:	0007879b          	sext.w	a5,a5
    800023c8:	fef70ce3          	beq	a4,a5,800023c0 <consoleread+0xfc>
    800023cc:	00001097          	auipc	ra,0x1
    800023d0:	234080e7          	jalr	564(ra) # 80003600 <pop_on>
    800023d4:	0984a783          	lw	a5,152(s1)
    800023d8:	07f7f713          	andi	a4,a5,127
    800023dc:	00e48733          	add	a4,s1,a4
    800023e0:	01874703          	lbu	a4,24(a4)
    800023e4:	0017869b          	addiw	a3,a5,1
    800023e8:	08d4ac23          	sw	a3,152(s1)
    800023ec:	00070c9b          	sext.w	s9,a4
    800023f0:	f5371ee3          	bne	a4,s3,8000234c <consoleread+0x88>
    800023f4:	000b851b          	sext.w	a0,s7
    800023f8:	f96bf2e3          	bgeu	s7,s6,8000237c <consoleread+0xb8>
    800023fc:	08f4ac23          	sw	a5,152(s1)
    80002400:	f7dff06f          	j	8000237c <consoleread+0xb8>

0000000080002404 <consputc>:
    80002404:	10000793          	li	a5,256
    80002408:	00f50663          	beq	a0,a5,80002414 <consputc+0x10>
    8000240c:	00001317          	auipc	t1,0x1
    80002410:	9f430067          	jr	-1548(t1) # 80002e00 <uartputc_sync>
    80002414:	ff010113          	addi	sp,sp,-16
    80002418:	00113423          	sd	ra,8(sp)
    8000241c:	00813023          	sd	s0,0(sp)
    80002420:	01010413          	addi	s0,sp,16
    80002424:	00800513          	li	a0,8
    80002428:	00001097          	auipc	ra,0x1
    8000242c:	9d8080e7          	jalr	-1576(ra) # 80002e00 <uartputc_sync>
    80002430:	02000513          	li	a0,32
    80002434:	00001097          	auipc	ra,0x1
    80002438:	9cc080e7          	jalr	-1588(ra) # 80002e00 <uartputc_sync>
    8000243c:	00013403          	ld	s0,0(sp)
    80002440:	00813083          	ld	ra,8(sp)
    80002444:	00800513          	li	a0,8
    80002448:	01010113          	addi	sp,sp,16
    8000244c:	00001317          	auipc	t1,0x1
    80002450:	9b430067          	jr	-1612(t1) # 80002e00 <uartputc_sync>

0000000080002454 <consoleintr>:
    80002454:	fe010113          	addi	sp,sp,-32
    80002458:	00813823          	sd	s0,16(sp)
    8000245c:	00913423          	sd	s1,8(sp)
    80002460:	01213023          	sd	s2,0(sp)
    80002464:	00113c23          	sd	ra,24(sp)
    80002468:	02010413          	addi	s0,sp,32
    8000246c:	00003917          	auipc	s2,0x3
    80002470:	33c90913          	addi	s2,s2,828 # 800057a8 <cons>
    80002474:	00050493          	mv	s1,a0
    80002478:	00090513          	mv	a0,s2
    8000247c:	00001097          	auipc	ra,0x1
    80002480:	e40080e7          	jalr	-448(ra) # 800032bc <acquire>
    80002484:	02048c63          	beqz	s1,800024bc <consoleintr+0x68>
    80002488:	0a092783          	lw	a5,160(s2)
    8000248c:	09892703          	lw	a4,152(s2)
    80002490:	07f00693          	li	a3,127
    80002494:	40e7873b          	subw	a4,a5,a4
    80002498:	02e6e263          	bltu	a3,a4,800024bc <consoleintr+0x68>
    8000249c:	00d00713          	li	a4,13
    800024a0:	04e48063          	beq	s1,a4,800024e0 <consoleintr+0x8c>
    800024a4:	07f7f713          	andi	a4,a5,127
    800024a8:	00e90733          	add	a4,s2,a4
    800024ac:	0017879b          	addiw	a5,a5,1
    800024b0:	0af92023          	sw	a5,160(s2)
    800024b4:	00970c23          	sb	s1,24(a4)
    800024b8:	08f92e23          	sw	a5,156(s2)
    800024bc:	01013403          	ld	s0,16(sp)
    800024c0:	01813083          	ld	ra,24(sp)
    800024c4:	00813483          	ld	s1,8(sp)
    800024c8:	00013903          	ld	s2,0(sp)
    800024cc:	00003517          	auipc	a0,0x3
    800024d0:	2dc50513          	addi	a0,a0,732 # 800057a8 <cons>
    800024d4:	02010113          	addi	sp,sp,32
    800024d8:	00001317          	auipc	t1,0x1
    800024dc:	eb030067          	jr	-336(t1) # 80003388 <release>
    800024e0:	00a00493          	li	s1,10
    800024e4:	fc1ff06f          	j	800024a4 <consoleintr+0x50>

00000000800024e8 <consoleinit>:
    800024e8:	fe010113          	addi	sp,sp,-32
    800024ec:	00113c23          	sd	ra,24(sp)
    800024f0:	00813823          	sd	s0,16(sp)
    800024f4:	00913423          	sd	s1,8(sp)
    800024f8:	02010413          	addi	s0,sp,32
    800024fc:	00003497          	auipc	s1,0x3
    80002500:	2ac48493          	addi	s1,s1,684 # 800057a8 <cons>
    80002504:	00048513          	mv	a0,s1
    80002508:	00002597          	auipc	a1,0x2
    8000250c:	cb858593          	addi	a1,a1,-840 # 800041c0 <_ZZ12printIntegermE6digits+0x138>
    80002510:	00001097          	auipc	ra,0x1
    80002514:	d88080e7          	jalr	-632(ra) # 80003298 <initlock>
    80002518:	00000097          	auipc	ra,0x0
    8000251c:	7ac080e7          	jalr	1964(ra) # 80002cc4 <uartinit>
    80002520:	01813083          	ld	ra,24(sp)
    80002524:	01013403          	ld	s0,16(sp)
    80002528:	00000797          	auipc	a5,0x0
    8000252c:	d9c78793          	addi	a5,a5,-612 # 800022c4 <consoleread>
    80002530:	0af4bc23          	sd	a5,184(s1)
    80002534:	00000797          	auipc	a5,0x0
    80002538:	cec78793          	addi	a5,a5,-788 # 80002220 <consolewrite>
    8000253c:	0cf4b023          	sd	a5,192(s1)
    80002540:	00813483          	ld	s1,8(sp)
    80002544:	02010113          	addi	sp,sp,32
    80002548:	00008067          	ret

000000008000254c <console_read>:
    8000254c:	ff010113          	addi	sp,sp,-16
    80002550:	00813423          	sd	s0,8(sp)
    80002554:	01010413          	addi	s0,sp,16
    80002558:	00813403          	ld	s0,8(sp)
    8000255c:	00003317          	auipc	t1,0x3
    80002560:	30433303          	ld	t1,772(t1) # 80005860 <devsw+0x10>
    80002564:	01010113          	addi	sp,sp,16
    80002568:	00030067          	jr	t1

000000008000256c <console_write>:
    8000256c:	ff010113          	addi	sp,sp,-16
    80002570:	00813423          	sd	s0,8(sp)
    80002574:	01010413          	addi	s0,sp,16
    80002578:	00813403          	ld	s0,8(sp)
    8000257c:	00003317          	auipc	t1,0x3
    80002580:	2ec33303          	ld	t1,748(t1) # 80005868 <devsw+0x18>
    80002584:	01010113          	addi	sp,sp,16
    80002588:	00030067          	jr	t1

000000008000258c <panic>:
    8000258c:	fe010113          	addi	sp,sp,-32
    80002590:	00113c23          	sd	ra,24(sp)
    80002594:	00813823          	sd	s0,16(sp)
    80002598:	00913423          	sd	s1,8(sp)
    8000259c:	02010413          	addi	s0,sp,32
    800025a0:	00050493          	mv	s1,a0
    800025a4:	00002517          	auipc	a0,0x2
    800025a8:	c2450513          	addi	a0,a0,-988 # 800041c8 <_ZZ12printIntegermE6digits+0x140>
    800025ac:	00003797          	auipc	a5,0x3
    800025b0:	3407ae23          	sw	zero,860(a5) # 80005908 <pr+0x18>
    800025b4:	00000097          	auipc	ra,0x0
    800025b8:	034080e7          	jalr	52(ra) # 800025e8 <__printf>
    800025bc:	00048513          	mv	a0,s1
    800025c0:	00000097          	auipc	ra,0x0
    800025c4:	028080e7          	jalr	40(ra) # 800025e8 <__printf>
    800025c8:	00002517          	auipc	a0,0x2
    800025cc:	ab850513          	addi	a0,a0,-1352 # 80004080 <kvmincrease+0x330>
    800025d0:	00000097          	auipc	ra,0x0
    800025d4:	018080e7          	jalr	24(ra) # 800025e8 <__printf>
    800025d8:	00100793          	li	a5,1
    800025dc:	00002717          	auipc	a4,0x2
    800025e0:	0af72623          	sw	a5,172(a4) # 80004688 <panicked>
    800025e4:	0000006f          	j	800025e4 <panic+0x58>

00000000800025e8 <__printf>:
    800025e8:	f3010113          	addi	sp,sp,-208
    800025ec:	08813023          	sd	s0,128(sp)
    800025f0:	07313423          	sd	s3,104(sp)
    800025f4:	09010413          	addi	s0,sp,144
    800025f8:	05813023          	sd	s8,64(sp)
    800025fc:	08113423          	sd	ra,136(sp)
    80002600:	06913c23          	sd	s1,120(sp)
    80002604:	07213823          	sd	s2,112(sp)
    80002608:	07413023          	sd	s4,96(sp)
    8000260c:	05513c23          	sd	s5,88(sp)
    80002610:	05613823          	sd	s6,80(sp)
    80002614:	05713423          	sd	s7,72(sp)
    80002618:	03913c23          	sd	s9,56(sp)
    8000261c:	03a13823          	sd	s10,48(sp)
    80002620:	03b13423          	sd	s11,40(sp)
    80002624:	00003317          	auipc	t1,0x3
    80002628:	2cc30313          	addi	t1,t1,716 # 800058f0 <pr>
    8000262c:	01832c03          	lw	s8,24(t1)
    80002630:	00b43423          	sd	a1,8(s0)
    80002634:	00c43823          	sd	a2,16(s0)
    80002638:	00d43c23          	sd	a3,24(s0)
    8000263c:	02e43023          	sd	a4,32(s0)
    80002640:	02f43423          	sd	a5,40(s0)
    80002644:	03043823          	sd	a6,48(s0)
    80002648:	03143c23          	sd	a7,56(s0)
    8000264c:	00050993          	mv	s3,a0
    80002650:	4a0c1663          	bnez	s8,80002afc <__printf+0x514>
    80002654:	60098c63          	beqz	s3,80002c6c <__printf+0x684>
    80002658:	0009c503          	lbu	a0,0(s3)
    8000265c:	00840793          	addi	a5,s0,8
    80002660:	f6f43c23          	sd	a5,-136(s0)
    80002664:	00000493          	li	s1,0
    80002668:	22050063          	beqz	a0,80002888 <__printf+0x2a0>
    8000266c:	00002a37          	lui	s4,0x2
    80002670:	00018ab7          	lui	s5,0x18
    80002674:	000f4b37          	lui	s6,0xf4
    80002678:	00989bb7          	lui	s7,0x989
    8000267c:	70fa0a13          	addi	s4,s4,1807 # 270f <_entry-0x7fffd8f1>
    80002680:	69fa8a93          	addi	s5,s5,1695 # 1869f <_entry-0x7ffe7961>
    80002684:	23fb0b13          	addi	s6,s6,575 # f423f <_entry-0x7ff0bdc1>
    80002688:	67fb8b93          	addi	s7,s7,1663 # 98967f <_entry-0x7f676981>
    8000268c:	00148c9b          	addiw	s9,s1,1
    80002690:	02500793          	li	a5,37
    80002694:	01998933          	add	s2,s3,s9
    80002698:	38f51263          	bne	a0,a5,80002a1c <__printf+0x434>
    8000269c:	00094783          	lbu	a5,0(s2)
    800026a0:	00078c9b          	sext.w	s9,a5
    800026a4:	1e078263          	beqz	a5,80002888 <__printf+0x2a0>
    800026a8:	0024849b          	addiw	s1,s1,2
    800026ac:	07000713          	li	a4,112
    800026b0:	00998933          	add	s2,s3,s1
    800026b4:	38e78a63          	beq	a5,a4,80002a48 <__printf+0x460>
    800026b8:	20f76863          	bltu	a4,a5,800028c8 <__printf+0x2e0>
    800026bc:	42a78863          	beq	a5,a0,80002aec <__printf+0x504>
    800026c0:	06400713          	li	a4,100
    800026c4:	40e79663          	bne	a5,a4,80002ad0 <__printf+0x4e8>
    800026c8:	f7843783          	ld	a5,-136(s0)
    800026cc:	0007a603          	lw	a2,0(a5)
    800026d0:	00878793          	addi	a5,a5,8
    800026d4:	f6f43c23          	sd	a5,-136(s0)
    800026d8:	42064a63          	bltz	a2,80002b0c <__printf+0x524>
    800026dc:	00a00713          	li	a4,10
    800026e0:	02e677bb          	remuw	a5,a2,a4
    800026e4:	00002d97          	auipc	s11,0x2
    800026e8:	b0cd8d93          	addi	s11,s11,-1268 # 800041f0 <digits>
    800026ec:	00900593          	li	a1,9
    800026f0:	0006051b          	sext.w	a0,a2
    800026f4:	00000c93          	li	s9,0
    800026f8:	02079793          	slli	a5,a5,0x20
    800026fc:	0207d793          	srli	a5,a5,0x20
    80002700:	00fd87b3          	add	a5,s11,a5
    80002704:	0007c783          	lbu	a5,0(a5)
    80002708:	02e656bb          	divuw	a3,a2,a4
    8000270c:	f8f40023          	sb	a5,-128(s0)
    80002710:	14c5d863          	bge	a1,a2,80002860 <__printf+0x278>
    80002714:	06300593          	li	a1,99
    80002718:	00100c93          	li	s9,1
    8000271c:	02e6f7bb          	remuw	a5,a3,a4
    80002720:	02079793          	slli	a5,a5,0x20
    80002724:	0207d793          	srli	a5,a5,0x20
    80002728:	00fd87b3          	add	a5,s11,a5
    8000272c:	0007c783          	lbu	a5,0(a5)
    80002730:	02e6d73b          	divuw	a4,a3,a4
    80002734:	f8f400a3          	sb	a5,-127(s0)
    80002738:	12a5f463          	bgeu	a1,a0,80002860 <__printf+0x278>
    8000273c:	00a00693          	li	a3,10
    80002740:	00900593          	li	a1,9
    80002744:	02d777bb          	remuw	a5,a4,a3
    80002748:	02079793          	slli	a5,a5,0x20
    8000274c:	0207d793          	srli	a5,a5,0x20
    80002750:	00fd87b3          	add	a5,s11,a5
    80002754:	0007c503          	lbu	a0,0(a5)
    80002758:	02d757bb          	divuw	a5,a4,a3
    8000275c:	f8a40123          	sb	a0,-126(s0)
    80002760:	48e5f263          	bgeu	a1,a4,80002be4 <__printf+0x5fc>
    80002764:	06300513          	li	a0,99
    80002768:	02d7f5bb          	remuw	a1,a5,a3
    8000276c:	02059593          	slli	a1,a1,0x20
    80002770:	0205d593          	srli	a1,a1,0x20
    80002774:	00bd85b3          	add	a1,s11,a1
    80002778:	0005c583          	lbu	a1,0(a1)
    8000277c:	02d7d7bb          	divuw	a5,a5,a3
    80002780:	f8b401a3          	sb	a1,-125(s0)
    80002784:	48e57263          	bgeu	a0,a4,80002c08 <__printf+0x620>
    80002788:	3e700513          	li	a0,999
    8000278c:	02d7f5bb          	remuw	a1,a5,a3
    80002790:	02059593          	slli	a1,a1,0x20
    80002794:	0205d593          	srli	a1,a1,0x20
    80002798:	00bd85b3          	add	a1,s11,a1
    8000279c:	0005c583          	lbu	a1,0(a1)
    800027a0:	02d7d7bb          	divuw	a5,a5,a3
    800027a4:	f8b40223          	sb	a1,-124(s0)
    800027a8:	46e57663          	bgeu	a0,a4,80002c14 <__printf+0x62c>
    800027ac:	02d7f5bb          	remuw	a1,a5,a3
    800027b0:	02059593          	slli	a1,a1,0x20
    800027b4:	0205d593          	srli	a1,a1,0x20
    800027b8:	00bd85b3          	add	a1,s11,a1
    800027bc:	0005c583          	lbu	a1,0(a1)
    800027c0:	02d7d7bb          	divuw	a5,a5,a3
    800027c4:	f8b402a3          	sb	a1,-123(s0)
    800027c8:	46ea7863          	bgeu	s4,a4,80002c38 <__printf+0x650>
    800027cc:	02d7f5bb          	remuw	a1,a5,a3
    800027d0:	02059593          	slli	a1,a1,0x20
    800027d4:	0205d593          	srli	a1,a1,0x20
    800027d8:	00bd85b3          	add	a1,s11,a1
    800027dc:	0005c583          	lbu	a1,0(a1)
    800027e0:	02d7d7bb          	divuw	a5,a5,a3
    800027e4:	f8b40323          	sb	a1,-122(s0)
    800027e8:	3eeaf863          	bgeu	s5,a4,80002bd8 <__printf+0x5f0>
    800027ec:	02d7f5bb          	remuw	a1,a5,a3
    800027f0:	02059593          	slli	a1,a1,0x20
    800027f4:	0205d593          	srli	a1,a1,0x20
    800027f8:	00bd85b3          	add	a1,s11,a1
    800027fc:	0005c583          	lbu	a1,0(a1)
    80002800:	02d7d7bb          	divuw	a5,a5,a3
    80002804:	f8b403a3          	sb	a1,-121(s0)
    80002808:	42eb7e63          	bgeu	s6,a4,80002c44 <__printf+0x65c>
    8000280c:	02d7f5bb          	remuw	a1,a5,a3
    80002810:	02059593          	slli	a1,a1,0x20
    80002814:	0205d593          	srli	a1,a1,0x20
    80002818:	00bd85b3          	add	a1,s11,a1
    8000281c:	0005c583          	lbu	a1,0(a1)
    80002820:	02d7d7bb          	divuw	a5,a5,a3
    80002824:	f8b40423          	sb	a1,-120(s0)
    80002828:	42ebfc63          	bgeu	s7,a4,80002c60 <__printf+0x678>
    8000282c:	02079793          	slli	a5,a5,0x20
    80002830:	0207d793          	srli	a5,a5,0x20
    80002834:	00fd8db3          	add	s11,s11,a5
    80002838:	000dc703          	lbu	a4,0(s11)
    8000283c:	00a00793          	li	a5,10
    80002840:	00900c93          	li	s9,9
    80002844:	f8e404a3          	sb	a4,-119(s0)
    80002848:	00065c63          	bgez	a2,80002860 <__printf+0x278>
    8000284c:	f9040713          	addi	a4,s0,-112
    80002850:	00f70733          	add	a4,a4,a5
    80002854:	02d00693          	li	a3,45
    80002858:	fed70823          	sb	a3,-16(a4)
    8000285c:	00078c93          	mv	s9,a5
    80002860:	f8040793          	addi	a5,s0,-128
    80002864:	01978cb3          	add	s9,a5,s9
    80002868:	f7f40d13          	addi	s10,s0,-129
    8000286c:	000cc503          	lbu	a0,0(s9)
    80002870:	fffc8c93          	addi	s9,s9,-1
    80002874:	00000097          	auipc	ra,0x0
    80002878:	b90080e7          	jalr	-1136(ra) # 80002404 <consputc>
    8000287c:	ffac98e3          	bne	s9,s10,8000286c <__printf+0x284>
    80002880:	00094503          	lbu	a0,0(s2)
    80002884:	e00514e3          	bnez	a0,8000268c <__printf+0xa4>
    80002888:	1a0c1663          	bnez	s8,80002a34 <__printf+0x44c>
    8000288c:	08813083          	ld	ra,136(sp)
    80002890:	08013403          	ld	s0,128(sp)
    80002894:	07813483          	ld	s1,120(sp)
    80002898:	07013903          	ld	s2,112(sp)
    8000289c:	06813983          	ld	s3,104(sp)
    800028a0:	06013a03          	ld	s4,96(sp)
    800028a4:	05813a83          	ld	s5,88(sp)
    800028a8:	05013b03          	ld	s6,80(sp)
    800028ac:	04813b83          	ld	s7,72(sp)
    800028b0:	04013c03          	ld	s8,64(sp)
    800028b4:	03813c83          	ld	s9,56(sp)
    800028b8:	03013d03          	ld	s10,48(sp)
    800028bc:	02813d83          	ld	s11,40(sp)
    800028c0:	0d010113          	addi	sp,sp,208
    800028c4:	00008067          	ret
    800028c8:	07300713          	li	a4,115
    800028cc:	1ce78a63          	beq	a5,a4,80002aa0 <__printf+0x4b8>
    800028d0:	07800713          	li	a4,120
    800028d4:	1ee79e63          	bne	a5,a4,80002ad0 <__printf+0x4e8>
    800028d8:	f7843783          	ld	a5,-136(s0)
    800028dc:	0007a703          	lw	a4,0(a5)
    800028e0:	00878793          	addi	a5,a5,8
    800028e4:	f6f43c23          	sd	a5,-136(s0)
    800028e8:	28074263          	bltz	a4,80002b6c <__printf+0x584>
    800028ec:	00002d97          	auipc	s11,0x2
    800028f0:	904d8d93          	addi	s11,s11,-1788 # 800041f0 <digits>
    800028f4:	00f77793          	andi	a5,a4,15
    800028f8:	00fd87b3          	add	a5,s11,a5
    800028fc:	0007c683          	lbu	a3,0(a5)
    80002900:	00f00613          	li	a2,15
    80002904:	0007079b          	sext.w	a5,a4
    80002908:	f8d40023          	sb	a3,-128(s0)
    8000290c:	0047559b          	srliw	a1,a4,0x4
    80002910:	0047569b          	srliw	a3,a4,0x4
    80002914:	00000c93          	li	s9,0
    80002918:	0ee65063          	bge	a2,a4,800029f8 <__printf+0x410>
    8000291c:	00f6f693          	andi	a3,a3,15
    80002920:	00dd86b3          	add	a3,s11,a3
    80002924:	0006c683          	lbu	a3,0(a3) # 2004000 <_entry-0x7dffc000>
    80002928:	0087d79b          	srliw	a5,a5,0x8
    8000292c:	00100c93          	li	s9,1
    80002930:	f8d400a3          	sb	a3,-127(s0)
    80002934:	0cb67263          	bgeu	a2,a1,800029f8 <__printf+0x410>
    80002938:	00f7f693          	andi	a3,a5,15
    8000293c:	00dd86b3          	add	a3,s11,a3
    80002940:	0006c583          	lbu	a1,0(a3)
    80002944:	00f00613          	li	a2,15
    80002948:	0047d69b          	srliw	a3,a5,0x4
    8000294c:	f8b40123          	sb	a1,-126(s0)
    80002950:	0047d593          	srli	a1,a5,0x4
    80002954:	28f67e63          	bgeu	a2,a5,80002bf0 <__printf+0x608>
    80002958:	00f6f693          	andi	a3,a3,15
    8000295c:	00dd86b3          	add	a3,s11,a3
    80002960:	0006c503          	lbu	a0,0(a3)
    80002964:	0087d813          	srli	a6,a5,0x8
    80002968:	0087d69b          	srliw	a3,a5,0x8
    8000296c:	f8a401a3          	sb	a0,-125(s0)
    80002970:	28b67663          	bgeu	a2,a1,80002bfc <__printf+0x614>
    80002974:	00f6f693          	andi	a3,a3,15
    80002978:	00dd86b3          	add	a3,s11,a3
    8000297c:	0006c583          	lbu	a1,0(a3)
    80002980:	00c7d513          	srli	a0,a5,0xc
    80002984:	00c7d69b          	srliw	a3,a5,0xc
    80002988:	f8b40223          	sb	a1,-124(s0)
    8000298c:	29067a63          	bgeu	a2,a6,80002c20 <__printf+0x638>
    80002990:	00f6f693          	andi	a3,a3,15
    80002994:	00dd86b3          	add	a3,s11,a3
    80002998:	0006c583          	lbu	a1,0(a3)
    8000299c:	0107d813          	srli	a6,a5,0x10
    800029a0:	0107d69b          	srliw	a3,a5,0x10
    800029a4:	f8b402a3          	sb	a1,-123(s0)
    800029a8:	28a67263          	bgeu	a2,a0,80002c2c <__printf+0x644>
    800029ac:	00f6f693          	andi	a3,a3,15
    800029b0:	00dd86b3          	add	a3,s11,a3
    800029b4:	0006c683          	lbu	a3,0(a3)
    800029b8:	0147d79b          	srliw	a5,a5,0x14
    800029bc:	f8d40323          	sb	a3,-122(s0)
    800029c0:	21067663          	bgeu	a2,a6,80002bcc <__printf+0x5e4>
    800029c4:	02079793          	slli	a5,a5,0x20
    800029c8:	0207d793          	srli	a5,a5,0x20
    800029cc:	00fd8db3          	add	s11,s11,a5
    800029d0:	000dc683          	lbu	a3,0(s11)
    800029d4:	00800793          	li	a5,8
    800029d8:	00700c93          	li	s9,7
    800029dc:	f8d403a3          	sb	a3,-121(s0)
    800029e0:	00075c63          	bgez	a4,800029f8 <__printf+0x410>
    800029e4:	f9040713          	addi	a4,s0,-112
    800029e8:	00f70733          	add	a4,a4,a5
    800029ec:	02d00693          	li	a3,45
    800029f0:	fed70823          	sb	a3,-16(a4)
    800029f4:	00078c93          	mv	s9,a5
    800029f8:	f8040793          	addi	a5,s0,-128
    800029fc:	01978cb3          	add	s9,a5,s9
    80002a00:	f7f40d13          	addi	s10,s0,-129
    80002a04:	000cc503          	lbu	a0,0(s9)
    80002a08:	fffc8c93          	addi	s9,s9,-1
    80002a0c:	00000097          	auipc	ra,0x0
    80002a10:	9f8080e7          	jalr	-1544(ra) # 80002404 <consputc>
    80002a14:	ff9d18e3          	bne	s10,s9,80002a04 <__printf+0x41c>
    80002a18:	0100006f          	j	80002a28 <__printf+0x440>
    80002a1c:	00000097          	auipc	ra,0x0
    80002a20:	9e8080e7          	jalr	-1560(ra) # 80002404 <consputc>
    80002a24:	000c8493          	mv	s1,s9
    80002a28:	00094503          	lbu	a0,0(s2)
    80002a2c:	c60510e3          	bnez	a0,8000268c <__printf+0xa4>
    80002a30:	e40c0ee3          	beqz	s8,8000288c <__printf+0x2a4>
    80002a34:	00003517          	auipc	a0,0x3
    80002a38:	ebc50513          	addi	a0,a0,-324 # 800058f0 <pr>
    80002a3c:	00001097          	auipc	ra,0x1
    80002a40:	94c080e7          	jalr	-1716(ra) # 80003388 <release>
    80002a44:	e49ff06f          	j	8000288c <__printf+0x2a4>
    80002a48:	f7843783          	ld	a5,-136(s0)
    80002a4c:	03000513          	li	a0,48
    80002a50:	01000d13          	li	s10,16
    80002a54:	00878713          	addi	a4,a5,8
    80002a58:	0007bc83          	ld	s9,0(a5)
    80002a5c:	f6e43c23          	sd	a4,-136(s0)
    80002a60:	00000097          	auipc	ra,0x0
    80002a64:	9a4080e7          	jalr	-1628(ra) # 80002404 <consputc>
    80002a68:	07800513          	li	a0,120
    80002a6c:	00000097          	auipc	ra,0x0
    80002a70:	998080e7          	jalr	-1640(ra) # 80002404 <consputc>
    80002a74:	00001d97          	auipc	s11,0x1
    80002a78:	77cd8d93          	addi	s11,s11,1916 # 800041f0 <digits>
    80002a7c:	03ccd793          	srli	a5,s9,0x3c
    80002a80:	00fd87b3          	add	a5,s11,a5
    80002a84:	0007c503          	lbu	a0,0(a5)
    80002a88:	fffd0d1b          	addiw	s10,s10,-1
    80002a8c:	004c9c93          	slli	s9,s9,0x4
    80002a90:	00000097          	auipc	ra,0x0
    80002a94:	974080e7          	jalr	-1676(ra) # 80002404 <consputc>
    80002a98:	fe0d12e3          	bnez	s10,80002a7c <__printf+0x494>
    80002a9c:	f8dff06f          	j	80002a28 <__printf+0x440>
    80002aa0:	f7843783          	ld	a5,-136(s0)
    80002aa4:	0007bc83          	ld	s9,0(a5)
    80002aa8:	00878793          	addi	a5,a5,8
    80002aac:	f6f43c23          	sd	a5,-136(s0)
    80002ab0:	000c9a63          	bnez	s9,80002ac4 <__printf+0x4dc>
    80002ab4:	1080006f          	j	80002bbc <__printf+0x5d4>
    80002ab8:	001c8c93          	addi	s9,s9,1
    80002abc:	00000097          	auipc	ra,0x0
    80002ac0:	948080e7          	jalr	-1720(ra) # 80002404 <consputc>
    80002ac4:	000cc503          	lbu	a0,0(s9)
    80002ac8:	fe0518e3          	bnez	a0,80002ab8 <__printf+0x4d0>
    80002acc:	f5dff06f          	j	80002a28 <__printf+0x440>
    80002ad0:	02500513          	li	a0,37
    80002ad4:	00000097          	auipc	ra,0x0
    80002ad8:	930080e7          	jalr	-1744(ra) # 80002404 <consputc>
    80002adc:	000c8513          	mv	a0,s9
    80002ae0:	00000097          	auipc	ra,0x0
    80002ae4:	924080e7          	jalr	-1756(ra) # 80002404 <consputc>
    80002ae8:	f41ff06f          	j	80002a28 <__printf+0x440>
    80002aec:	02500513          	li	a0,37
    80002af0:	00000097          	auipc	ra,0x0
    80002af4:	914080e7          	jalr	-1772(ra) # 80002404 <consputc>
    80002af8:	f31ff06f          	j	80002a28 <__printf+0x440>
    80002afc:	00030513          	mv	a0,t1
    80002b00:	00000097          	auipc	ra,0x0
    80002b04:	7bc080e7          	jalr	1980(ra) # 800032bc <acquire>
    80002b08:	b4dff06f          	j	80002654 <__printf+0x6c>
    80002b0c:	40c0053b          	negw	a0,a2
    80002b10:	00a00713          	li	a4,10
    80002b14:	02e576bb          	remuw	a3,a0,a4
    80002b18:	00001d97          	auipc	s11,0x1
    80002b1c:	6d8d8d93          	addi	s11,s11,1752 # 800041f0 <digits>
    80002b20:	ff700593          	li	a1,-9
    80002b24:	02069693          	slli	a3,a3,0x20
    80002b28:	0206d693          	srli	a3,a3,0x20
    80002b2c:	00dd86b3          	add	a3,s11,a3
    80002b30:	0006c683          	lbu	a3,0(a3)
    80002b34:	02e557bb          	divuw	a5,a0,a4
    80002b38:	f8d40023          	sb	a3,-128(s0)
    80002b3c:	10b65e63          	bge	a2,a1,80002c58 <__printf+0x670>
    80002b40:	06300593          	li	a1,99
    80002b44:	02e7f6bb          	remuw	a3,a5,a4
    80002b48:	02069693          	slli	a3,a3,0x20
    80002b4c:	0206d693          	srli	a3,a3,0x20
    80002b50:	00dd86b3          	add	a3,s11,a3
    80002b54:	0006c683          	lbu	a3,0(a3)
    80002b58:	02e7d73b          	divuw	a4,a5,a4
    80002b5c:	00200793          	li	a5,2
    80002b60:	f8d400a3          	sb	a3,-127(s0)
    80002b64:	bca5ece3          	bltu	a1,a0,8000273c <__printf+0x154>
    80002b68:	ce5ff06f          	j	8000284c <__printf+0x264>
    80002b6c:	40e007bb          	negw	a5,a4
    80002b70:	00001d97          	auipc	s11,0x1
    80002b74:	680d8d93          	addi	s11,s11,1664 # 800041f0 <digits>
    80002b78:	00f7f693          	andi	a3,a5,15
    80002b7c:	00dd86b3          	add	a3,s11,a3
    80002b80:	0006c583          	lbu	a1,0(a3)
    80002b84:	ff100613          	li	a2,-15
    80002b88:	0047d69b          	srliw	a3,a5,0x4
    80002b8c:	f8b40023          	sb	a1,-128(s0)
    80002b90:	0047d59b          	srliw	a1,a5,0x4
    80002b94:	0ac75e63          	bge	a4,a2,80002c50 <__printf+0x668>
    80002b98:	00f6f693          	andi	a3,a3,15
    80002b9c:	00dd86b3          	add	a3,s11,a3
    80002ba0:	0006c603          	lbu	a2,0(a3)
    80002ba4:	00f00693          	li	a3,15
    80002ba8:	0087d79b          	srliw	a5,a5,0x8
    80002bac:	f8c400a3          	sb	a2,-127(s0)
    80002bb0:	d8b6e4e3          	bltu	a3,a1,80002938 <__printf+0x350>
    80002bb4:	00200793          	li	a5,2
    80002bb8:	e2dff06f          	j	800029e4 <__printf+0x3fc>
    80002bbc:	00001c97          	auipc	s9,0x1
    80002bc0:	614c8c93          	addi	s9,s9,1556 # 800041d0 <_ZZ12printIntegermE6digits+0x148>
    80002bc4:	02800513          	li	a0,40
    80002bc8:	ef1ff06f          	j	80002ab8 <__printf+0x4d0>
    80002bcc:	00700793          	li	a5,7
    80002bd0:	00600c93          	li	s9,6
    80002bd4:	e0dff06f          	j	800029e0 <__printf+0x3f8>
    80002bd8:	00700793          	li	a5,7
    80002bdc:	00600c93          	li	s9,6
    80002be0:	c69ff06f          	j	80002848 <__printf+0x260>
    80002be4:	00300793          	li	a5,3
    80002be8:	00200c93          	li	s9,2
    80002bec:	c5dff06f          	j	80002848 <__printf+0x260>
    80002bf0:	00300793          	li	a5,3
    80002bf4:	00200c93          	li	s9,2
    80002bf8:	de9ff06f          	j	800029e0 <__printf+0x3f8>
    80002bfc:	00400793          	li	a5,4
    80002c00:	00300c93          	li	s9,3
    80002c04:	dddff06f          	j	800029e0 <__printf+0x3f8>
    80002c08:	00400793          	li	a5,4
    80002c0c:	00300c93          	li	s9,3
    80002c10:	c39ff06f          	j	80002848 <__printf+0x260>
    80002c14:	00500793          	li	a5,5
    80002c18:	00400c93          	li	s9,4
    80002c1c:	c2dff06f          	j	80002848 <__printf+0x260>
    80002c20:	00500793          	li	a5,5
    80002c24:	00400c93          	li	s9,4
    80002c28:	db9ff06f          	j	800029e0 <__printf+0x3f8>
    80002c2c:	00600793          	li	a5,6
    80002c30:	00500c93          	li	s9,5
    80002c34:	dadff06f          	j	800029e0 <__printf+0x3f8>
    80002c38:	00600793          	li	a5,6
    80002c3c:	00500c93          	li	s9,5
    80002c40:	c09ff06f          	j	80002848 <__printf+0x260>
    80002c44:	00800793          	li	a5,8
    80002c48:	00700c93          	li	s9,7
    80002c4c:	bfdff06f          	j	80002848 <__printf+0x260>
    80002c50:	00100793          	li	a5,1
    80002c54:	d91ff06f          	j	800029e4 <__printf+0x3fc>
    80002c58:	00100793          	li	a5,1
    80002c5c:	bf1ff06f          	j	8000284c <__printf+0x264>
    80002c60:	00900793          	li	a5,9
    80002c64:	00800c93          	li	s9,8
    80002c68:	be1ff06f          	j	80002848 <__printf+0x260>
    80002c6c:	00001517          	auipc	a0,0x1
    80002c70:	56c50513          	addi	a0,a0,1388 # 800041d8 <_ZZ12printIntegermE6digits+0x150>
    80002c74:	00000097          	auipc	ra,0x0
    80002c78:	918080e7          	jalr	-1768(ra) # 8000258c <panic>

0000000080002c7c <printfinit>:
    80002c7c:	fe010113          	addi	sp,sp,-32
    80002c80:	00813823          	sd	s0,16(sp)
    80002c84:	00913423          	sd	s1,8(sp)
    80002c88:	00113c23          	sd	ra,24(sp)
    80002c8c:	02010413          	addi	s0,sp,32
    80002c90:	00003497          	auipc	s1,0x3
    80002c94:	c6048493          	addi	s1,s1,-928 # 800058f0 <pr>
    80002c98:	00048513          	mv	a0,s1
    80002c9c:	00001597          	auipc	a1,0x1
    80002ca0:	54c58593          	addi	a1,a1,1356 # 800041e8 <_ZZ12printIntegermE6digits+0x160>
    80002ca4:	00000097          	auipc	ra,0x0
    80002ca8:	5f4080e7          	jalr	1524(ra) # 80003298 <initlock>
    80002cac:	01813083          	ld	ra,24(sp)
    80002cb0:	01013403          	ld	s0,16(sp)
    80002cb4:	0004ac23          	sw	zero,24(s1)
    80002cb8:	00813483          	ld	s1,8(sp)
    80002cbc:	02010113          	addi	sp,sp,32
    80002cc0:	00008067          	ret

0000000080002cc4 <uartinit>:
    80002cc4:	ff010113          	addi	sp,sp,-16
    80002cc8:	00813423          	sd	s0,8(sp)
    80002ccc:	01010413          	addi	s0,sp,16
    80002cd0:	100007b7          	lui	a5,0x10000
    80002cd4:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>
    80002cd8:	f8000713          	li	a4,-128
    80002cdc:	00e781a3          	sb	a4,3(a5)
    80002ce0:	00300713          	li	a4,3
    80002ce4:	00e78023          	sb	a4,0(a5)
    80002ce8:	000780a3          	sb	zero,1(a5)
    80002cec:	00e781a3          	sb	a4,3(a5)
    80002cf0:	00700693          	li	a3,7
    80002cf4:	00d78123          	sb	a3,2(a5)
    80002cf8:	00e780a3          	sb	a4,1(a5)
    80002cfc:	00813403          	ld	s0,8(sp)
    80002d00:	01010113          	addi	sp,sp,16
    80002d04:	00008067          	ret

0000000080002d08 <uartputc>:
    80002d08:	00002797          	auipc	a5,0x2
    80002d0c:	9807a783          	lw	a5,-1664(a5) # 80004688 <panicked>
    80002d10:	00078463          	beqz	a5,80002d18 <uartputc+0x10>
    80002d14:	0000006f          	j	80002d14 <uartputc+0xc>
    80002d18:	fd010113          	addi	sp,sp,-48
    80002d1c:	02813023          	sd	s0,32(sp)
    80002d20:	00913c23          	sd	s1,24(sp)
    80002d24:	01213823          	sd	s2,16(sp)
    80002d28:	01313423          	sd	s3,8(sp)
    80002d2c:	02113423          	sd	ra,40(sp)
    80002d30:	03010413          	addi	s0,sp,48
    80002d34:	00002917          	auipc	s2,0x2
    80002d38:	95c90913          	addi	s2,s2,-1700 # 80004690 <uart_tx_r>
    80002d3c:	00093783          	ld	a5,0(s2)
    80002d40:	00002497          	auipc	s1,0x2
    80002d44:	95848493          	addi	s1,s1,-1704 # 80004698 <uart_tx_w>
    80002d48:	0004b703          	ld	a4,0(s1)
    80002d4c:	02078693          	addi	a3,a5,32
    80002d50:	00050993          	mv	s3,a0
    80002d54:	02e69c63          	bne	a3,a4,80002d8c <uartputc+0x84>
    80002d58:	00001097          	auipc	ra,0x1
    80002d5c:	834080e7          	jalr	-1996(ra) # 8000358c <push_on>
    80002d60:	00093783          	ld	a5,0(s2)
    80002d64:	0004b703          	ld	a4,0(s1)
    80002d68:	02078793          	addi	a5,a5,32
    80002d6c:	00e79463          	bne	a5,a4,80002d74 <uartputc+0x6c>
    80002d70:	0000006f          	j	80002d70 <uartputc+0x68>
    80002d74:	00001097          	auipc	ra,0x1
    80002d78:	88c080e7          	jalr	-1908(ra) # 80003600 <pop_on>
    80002d7c:	00093783          	ld	a5,0(s2)
    80002d80:	0004b703          	ld	a4,0(s1)
    80002d84:	02078693          	addi	a3,a5,32
    80002d88:	fce688e3          	beq	a3,a4,80002d58 <uartputc+0x50>
    80002d8c:	01f77693          	andi	a3,a4,31
    80002d90:	00003597          	auipc	a1,0x3
    80002d94:	b8058593          	addi	a1,a1,-1152 # 80005910 <uart_tx_buf>
    80002d98:	00d586b3          	add	a3,a1,a3
    80002d9c:	00170713          	addi	a4,a4,1
    80002da0:	01368023          	sb	s3,0(a3)
    80002da4:	00e4b023          	sd	a4,0(s1)
    80002da8:	10000637          	lui	a2,0x10000
    80002dac:	02f71063          	bne	a4,a5,80002dcc <uartputc+0xc4>
    80002db0:	0340006f          	j	80002de4 <uartputc+0xdc>
    80002db4:	00074703          	lbu	a4,0(a4)
    80002db8:	00f93023          	sd	a5,0(s2)
    80002dbc:	00e60023          	sb	a4,0(a2) # 10000000 <_entry-0x70000000>
    80002dc0:	00093783          	ld	a5,0(s2)
    80002dc4:	0004b703          	ld	a4,0(s1)
    80002dc8:	00f70e63          	beq	a4,a5,80002de4 <uartputc+0xdc>
    80002dcc:	00564683          	lbu	a3,5(a2)
    80002dd0:	01f7f713          	andi	a4,a5,31
    80002dd4:	00e58733          	add	a4,a1,a4
    80002dd8:	0206f693          	andi	a3,a3,32
    80002ddc:	00178793          	addi	a5,a5,1
    80002de0:	fc069ae3          	bnez	a3,80002db4 <uartputc+0xac>
    80002de4:	02813083          	ld	ra,40(sp)
    80002de8:	02013403          	ld	s0,32(sp)
    80002dec:	01813483          	ld	s1,24(sp)
    80002df0:	01013903          	ld	s2,16(sp)
    80002df4:	00813983          	ld	s3,8(sp)
    80002df8:	03010113          	addi	sp,sp,48
    80002dfc:	00008067          	ret

0000000080002e00 <uartputc_sync>:
    80002e00:	ff010113          	addi	sp,sp,-16
    80002e04:	00813423          	sd	s0,8(sp)
    80002e08:	01010413          	addi	s0,sp,16
    80002e0c:	00002717          	auipc	a4,0x2
    80002e10:	87c72703          	lw	a4,-1924(a4) # 80004688 <panicked>
    80002e14:	02071663          	bnez	a4,80002e40 <uartputc_sync+0x40>
    80002e18:	00050793          	mv	a5,a0
    80002e1c:	100006b7          	lui	a3,0x10000
    80002e20:	0056c703          	lbu	a4,5(a3) # 10000005 <_entry-0x6ffffffb>
    80002e24:	02077713          	andi	a4,a4,32
    80002e28:	fe070ce3          	beqz	a4,80002e20 <uartputc_sync+0x20>
    80002e2c:	0ff7f793          	andi	a5,a5,255
    80002e30:	00f68023          	sb	a5,0(a3)
    80002e34:	00813403          	ld	s0,8(sp)
    80002e38:	01010113          	addi	sp,sp,16
    80002e3c:	00008067          	ret
    80002e40:	0000006f          	j	80002e40 <uartputc_sync+0x40>

0000000080002e44 <uartstart>:
    80002e44:	ff010113          	addi	sp,sp,-16
    80002e48:	00813423          	sd	s0,8(sp)
    80002e4c:	01010413          	addi	s0,sp,16
    80002e50:	00002617          	auipc	a2,0x2
    80002e54:	84060613          	addi	a2,a2,-1984 # 80004690 <uart_tx_r>
    80002e58:	00002517          	auipc	a0,0x2
    80002e5c:	84050513          	addi	a0,a0,-1984 # 80004698 <uart_tx_w>
    80002e60:	00063783          	ld	a5,0(a2)
    80002e64:	00053703          	ld	a4,0(a0)
    80002e68:	04f70263          	beq	a4,a5,80002eac <uartstart+0x68>
    80002e6c:	100005b7          	lui	a1,0x10000
    80002e70:	00003817          	auipc	a6,0x3
    80002e74:	aa080813          	addi	a6,a6,-1376 # 80005910 <uart_tx_buf>
    80002e78:	01c0006f          	j	80002e94 <uartstart+0x50>
    80002e7c:	0006c703          	lbu	a4,0(a3)
    80002e80:	00f63023          	sd	a5,0(a2)
    80002e84:	00e58023          	sb	a4,0(a1) # 10000000 <_entry-0x70000000>
    80002e88:	00063783          	ld	a5,0(a2)
    80002e8c:	00053703          	ld	a4,0(a0)
    80002e90:	00f70e63          	beq	a4,a5,80002eac <uartstart+0x68>
    80002e94:	01f7f713          	andi	a4,a5,31
    80002e98:	00e806b3          	add	a3,a6,a4
    80002e9c:	0055c703          	lbu	a4,5(a1)
    80002ea0:	00178793          	addi	a5,a5,1
    80002ea4:	02077713          	andi	a4,a4,32
    80002ea8:	fc071ae3          	bnez	a4,80002e7c <uartstart+0x38>
    80002eac:	00813403          	ld	s0,8(sp)
    80002eb0:	01010113          	addi	sp,sp,16
    80002eb4:	00008067          	ret

0000000080002eb8 <uartgetc>:
    80002eb8:	ff010113          	addi	sp,sp,-16
    80002ebc:	00813423          	sd	s0,8(sp)
    80002ec0:	01010413          	addi	s0,sp,16
    80002ec4:	10000737          	lui	a4,0x10000
    80002ec8:	00574783          	lbu	a5,5(a4) # 10000005 <_entry-0x6ffffffb>
    80002ecc:	0017f793          	andi	a5,a5,1
    80002ed0:	00078c63          	beqz	a5,80002ee8 <uartgetc+0x30>
    80002ed4:	00074503          	lbu	a0,0(a4)
    80002ed8:	0ff57513          	andi	a0,a0,255
    80002edc:	00813403          	ld	s0,8(sp)
    80002ee0:	01010113          	addi	sp,sp,16
    80002ee4:	00008067          	ret
    80002ee8:	fff00513          	li	a0,-1
    80002eec:	ff1ff06f          	j	80002edc <uartgetc+0x24>

0000000080002ef0 <uartintr>:
    80002ef0:	100007b7          	lui	a5,0x10000
    80002ef4:	0057c783          	lbu	a5,5(a5) # 10000005 <_entry-0x6ffffffb>
    80002ef8:	0017f793          	andi	a5,a5,1
    80002efc:	0a078463          	beqz	a5,80002fa4 <uartintr+0xb4>
    80002f00:	fe010113          	addi	sp,sp,-32
    80002f04:	00813823          	sd	s0,16(sp)
    80002f08:	00913423          	sd	s1,8(sp)
    80002f0c:	00113c23          	sd	ra,24(sp)
    80002f10:	02010413          	addi	s0,sp,32
    80002f14:	100004b7          	lui	s1,0x10000
    80002f18:	0004c503          	lbu	a0,0(s1) # 10000000 <_entry-0x70000000>
    80002f1c:	0ff57513          	andi	a0,a0,255
    80002f20:	fffff097          	auipc	ra,0xfffff
    80002f24:	534080e7          	jalr	1332(ra) # 80002454 <consoleintr>
    80002f28:	0054c783          	lbu	a5,5(s1)
    80002f2c:	0017f793          	andi	a5,a5,1
    80002f30:	fe0794e3          	bnez	a5,80002f18 <uartintr+0x28>
    80002f34:	00001617          	auipc	a2,0x1
    80002f38:	75c60613          	addi	a2,a2,1884 # 80004690 <uart_tx_r>
    80002f3c:	00001517          	auipc	a0,0x1
    80002f40:	75c50513          	addi	a0,a0,1884 # 80004698 <uart_tx_w>
    80002f44:	00063783          	ld	a5,0(a2)
    80002f48:	00053703          	ld	a4,0(a0)
    80002f4c:	04f70263          	beq	a4,a5,80002f90 <uartintr+0xa0>
    80002f50:	100005b7          	lui	a1,0x10000
    80002f54:	00003817          	auipc	a6,0x3
    80002f58:	9bc80813          	addi	a6,a6,-1604 # 80005910 <uart_tx_buf>
    80002f5c:	01c0006f          	j	80002f78 <uartintr+0x88>
    80002f60:	0006c703          	lbu	a4,0(a3)
    80002f64:	00f63023          	sd	a5,0(a2)
    80002f68:	00e58023          	sb	a4,0(a1) # 10000000 <_entry-0x70000000>
    80002f6c:	00063783          	ld	a5,0(a2)
    80002f70:	00053703          	ld	a4,0(a0)
    80002f74:	00f70e63          	beq	a4,a5,80002f90 <uartintr+0xa0>
    80002f78:	01f7f713          	andi	a4,a5,31
    80002f7c:	00e806b3          	add	a3,a6,a4
    80002f80:	0055c703          	lbu	a4,5(a1)
    80002f84:	00178793          	addi	a5,a5,1
    80002f88:	02077713          	andi	a4,a4,32
    80002f8c:	fc071ae3          	bnez	a4,80002f60 <uartintr+0x70>
    80002f90:	01813083          	ld	ra,24(sp)
    80002f94:	01013403          	ld	s0,16(sp)
    80002f98:	00813483          	ld	s1,8(sp)
    80002f9c:	02010113          	addi	sp,sp,32
    80002fa0:	00008067          	ret
    80002fa4:	00001617          	auipc	a2,0x1
    80002fa8:	6ec60613          	addi	a2,a2,1772 # 80004690 <uart_tx_r>
    80002fac:	00001517          	auipc	a0,0x1
    80002fb0:	6ec50513          	addi	a0,a0,1772 # 80004698 <uart_tx_w>
    80002fb4:	00063783          	ld	a5,0(a2)
    80002fb8:	00053703          	ld	a4,0(a0)
    80002fbc:	04f70263          	beq	a4,a5,80003000 <uartintr+0x110>
    80002fc0:	100005b7          	lui	a1,0x10000
    80002fc4:	00003817          	auipc	a6,0x3
    80002fc8:	94c80813          	addi	a6,a6,-1716 # 80005910 <uart_tx_buf>
    80002fcc:	01c0006f          	j	80002fe8 <uartintr+0xf8>
    80002fd0:	0006c703          	lbu	a4,0(a3)
    80002fd4:	00f63023          	sd	a5,0(a2)
    80002fd8:	00e58023          	sb	a4,0(a1) # 10000000 <_entry-0x70000000>
    80002fdc:	00063783          	ld	a5,0(a2)
    80002fe0:	00053703          	ld	a4,0(a0)
    80002fe4:	02f70063          	beq	a4,a5,80003004 <uartintr+0x114>
    80002fe8:	01f7f713          	andi	a4,a5,31
    80002fec:	00e806b3          	add	a3,a6,a4
    80002ff0:	0055c703          	lbu	a4,5(a1)
    80002ff4:	00178793          	addi	a5,a5,1
    80002ff8:	02077713          	andi	a4,a4,32
    80002ffc:	fc071ae3          	bnez	a4,80002fd0 <uartintr+0xe0>
    80003000:	00008067          	ret
    80003004:	00008067          	ret

0000000080003008 <kinit>:
    80003008:	fc010113          	addi	sp,sp,-64
    8000300c:	02913423          	sd	s1,40(sp)
    80003010:	fffff7b7          	lui	a5,0xfffff
    80003014:	00004497          	auipc	s1,0x4
    80003018:	92b48493          	addi	s1,s1,-1749 # 8000693f <end+0xfff>
    8000301c:	02813823          	sd	s0,48(sp)
    80003020:	01313c23          	sd	s3,24(sp)
    80003024:	00f4f4b3          	and	s1,s1,a5
    80003028:	02113c23          	sd	ra,56(sp)
    8000302c:	03213023          	sd	s2,32(sp)
    80003030:	01413823          	sd	s4,16(sp)
    80003034:	01513423          	sd	s5,8(sp)
    80003038:	04010413          	addi	s0,sp,64
    8000303c:	000017b7          	lui	a5,0x1
    80003040:	01100993          	li	s3,17
    80003044:	00f487b3          	add	a5,s1,a5
    80003048:	01b99993          	slli	s3,s3,0x1b
    8000304c:	06f9e063          	bltu	s3,a5,800030ac <kinit+0xa4>
    80003050:	00003a97          	auipc	s5,0x3
    80003054:	8f0a8a93          	addi	s5,s5,-1808 # 80005940 <end>
    80003058:	0754ec63          	bltu	s1,s5,800030d0 <kinit+0xc8>
    8000305c:	0734fa63          	bgeu	s1,s3,800030d0 <kinit+0xc8>
    80003060:	00088a37          	lui	s4,0x88
    80003064:	fffa0a13          	addi	s4,s4,-1 # 87fff <_entry-0x7ff78001>
    80003068:	00001917          	auipc	s2,0x1
    8000306c:	63890913          	addi	s2,s2,1592 # 800046a0 <kmem>
    80003070:	00ca1a13          	slli	s4,s4,0xc
    80003074:	0140006f          	j	80003088 <kinit+0x80>
    80003078:	000017b7          	lui	a5,0x1
    8000307c:	00f484b3          	add	s1,s1,a5
    80003080:	0554e863          	bltu	s1,s5,800030d0 <kinit+0xc8>
    80003084:	0534f663          	bgeu	s1,s3,800030d0 <kinit+0xc8>
    80003088:	00001637          	lui	a2,0x1
    8000308c:	00100593          	li	a1,1
    80003090:	00048513          	mv	a0,s1
    80003094:	00000097          	auipc	ra,0x0
    80003098:	5e4080e7          	jalr	1508(ra) # 80003678 <__memset>
    8000309c:	00093783          	ld	a5,0(s2)
    800030a0:	00f4b023          	sd	a5,0(s1)
    800030a4:	00993023          	sd	s1,0(s2)
    800030a8:	fd4498e3          	bne	s1,s4,80003078 <kinit+0x70>
    800030ac:	03813083          	ld	ra,56(sp)
    800030b0:	03013403          	ld	s0,48(sp)
    800030b4:	02813483          	ld	s1,40(sp)
    800030b8:	02013903          	ld	s2,32(sp)
    800030bc:	01813983          	ld	s3,24(sp)
    800030c0:	01013a03          	ld	s4,16(sp)
    800030c4:	00813a83          	ld	s5,8(sp)
    800030c8:	04010113          	addi	sp,sp,64
    800030cc:	00008067          	ret
    800030d0:	00001517          	auipc	a0,0x1
    800030d4:	13850513          	addi	a0,a0,312 # 80004208 <digits+0x18>
    800030d8:	fffff097          	auipc	ra,0xfffff
    800030dc:	4b4080e7          	jalr	1204(ra) # 8000258c <panic>

00000000800030e0 <freerange>:
    800030e0:	fc010113          	addi	sp,sp,-64
    800030e4:	000017b7          	lui	a5,0x1
    800030e8:	02913423          	sd	s1,40(sp)
    800030ec:	fff78493          	addi	s1,a5,-1 # fff <_entry-0x7ffff001>
    800030f0:	009504b3          	add	s1,a0,s1
    800030f4:	fffff537          	lui	a0,0xfffff
    800030f8:	02813823          	sd	s0,48(sp)
    800030fc:	02113c23          	sd	ra,56(sp)
    80003100:	03213023          	sd	s2,32(sp)
    80003104:	01313c23          	sd	s3,24(sp)
    80003108:	01413823          	sd	s4,16(sp)
    8000310c:	01513423          	sd	s5,8(sp)
    80003110:	01613023          	sd	s6,0(sp)
    80003114:	04010413          	addi	s0,sp,64
    80003118:	00a4f4b3          	and	s1,s1,a0
    8000311c:	00f487b3          	add	a5,s1,a5
    80003120:	06f5e463          	bltu	a1,a5,80003188 <freerange+0xa8>
    80003124:	00003a97          	auipc	s5,0x3
    80003128:	81ca8a93          	addi	s5,s5,-2020 # 80005940 <end>
    8000312c:	0954e263          	bltu	s1,s5,800031b0 <freerange+0xd0>
    80003130:	01100993          	li	s3,17
    80003134:	01b99993          	slli	s3,s3,0x1b
    80003138:	0734fc63          	bgeu	s1,s3,800031b0 <freerange+0xd0>
    8000313c:	00058a13          	mv	s4,a1
    80003140:	00001917          	auipc	s2,0x1
    80003144:	56090913          	addi	s2,s2,1376 # 800046a0 <kmem>
    80003148:	00002b37          	lui	s6,0x2
    8000314c:	0140006f          	j	80003160 <freerange+0x80>
    80003150:	000017b7          	lui	a5,0x1
    80003154:	00f484b3          	add	s1,s1,a5
    80003158:	0554ec63          	bltu	s1,s5,800031b0 <freerange+0xd0>
    8000315c:	0534fa63          	bgeu	s1,s3,800031b0 <freerange+0xd0>
    80003160:	00001637          	lui	a2,0x1
    80003164:	00100593          	li	a1,1
    80003168:	00048513          	mv	a0,s1
    8000316c:	00000097          	auipc	ra,0x0
    80003170:	50c080e7          	jalr	1292(ra) # 80003678 <__memset>
    80003174:	00093703          	ld	a4,0(s2)
    80003178:	016487b3          	add	a5,s1,s6
    8000317c:	00e4b023          	sd	a4,0(s1)
    80003180:	00993023          	sd	s1,0(s2)
    80003184:	fcfa76e3          	bgeu	s4,a5,80003150 <freerange+0x70>
    80003188:	03813083          	ld	ra,56(sp)
    8000318c:	03013403          	ld	s0,48(sp)
    80003190:	02813483          	ld	s1,40(sp)
    80003194:	02013903          	ld	s2,32(sp)
    80003198:	01813983          	ld	s3,24(sp)
    8000319c:	01013a03          	ld	s4,16(sp)
    800031a0:	00813a83          	ld	s5,8(sp)
    800031a4:	00013b03          	ld	s6,0(sp)
    800031a8:	04010113          	addi	sp,sp,64
    800031ac:	00008067          	ret
    800031b0:	00001517          	auipc	a0,0x1
    800031b4:	05850513          	addi	a0,a0,88 # 80004208 <digits+0x18>
    800031b8:	fffff097          	auipc	ra,0xfffff
    800031bc:	3d4080e7          	jalr	980(ra) # 8000258c <panic>

00000000800031c0 <kfree>:
    800031c0:	fe010113          	addi	sp,sp,-32
    800031c4:	00813823          	sd	s0,16(sp)
    800031c8:	00113c23          	sd	ra,24(sp)
    800031cc:	00913423          	sd	s1,8(sp)
    800031d0:	02010413          	addi	s0,sp,32
    800031d4:	03451793          	slli	a5,a0,0x34
    800031d8:	04079c63          	bnez	a5,80003230 <kfree+0x70>
    800031dc:	00002797          	auipc	a5,0x2
    800031e0:	76478793          	addi	a5,a5,1892 # 80005940 <end>
    800031e4:	00050493          	mv	s1,a0
    800031e8:	04f56463          	bltu	a0,a5,80003230 <kfree+0x70>
    800031ec:	01100793          	li	a5,17
    800031f0:	01b79793          	slli	a5,a5,0x1b
    800031f4:	02f57e63          	bgeu	a0,a5,80003230 <kfree+0x70>
    800031f8:	00001637          	lui	a2,0x1
    800031fc:	00100593          	li	a1,1
    80003200:	00000097          	auipc	ra,0x0
    80003204:	478080e7          	jalr	1144(ra) # 80003678 <__memset>
    80003208:	00001797          	auipc	a5,0x1
    8000320c:	49878793          	addi	a5,a5,1176 # 800046a0 <kmem>
    80003210:	0007b703          	ld	a4,0(a5)
    80003214:	01813083          	ld	ra,24(sp)
    80003218:	01013403          	ld	s0,16(sp)
    8000321c:	00e4b023          	sd	a4,0(s1)
    80003220:	0097b023          	sd	s1,0(a5)
    80003224:	00813483          	ld	s1,8(sp)
    80003228:	02010113          	addi	sp,sp,32
    8000322c:	00008067          	ret
    80003230:	00001517          	auipc	a0,0x1
    80003234:	fd850513          	addi	a0,a0,-40 # 80004208 <digits+0x18>
    80003238:	fffff097          	auipc	ra,0xfffff
    8000323c:	354080e7          	jalr	852(ra) # 8000258c <panic>

0000000080003240 <kalloc>:
    80003240:	fe010113          	addi	sp,sp,-32
    80003244:	00813823          	sd	s0,16(sp)
    80003248:	00913423          	sd	s1,8(sp)
    8000324c:	00113c23          	sd	ra,24(sp)
    80003250:	02010413          	addi	s0,sp,32
    80003254:	00001797          	auipc	a5,0x1
    80003258:	44c78793          	addi	a5,a5,1100 # 800046a0 <kmem>
    8000325c:	0007b483          	ld	s1,0(a5)
    80003260:	02048063          	beqz	s1,80003280 <kalloc+0x40>
    80003264:	0004b703          	ld	a4,0(s1)
    80003268:	00001637          	lui	a2,0x1
    8000326c:	00500593          	li	a1,5
    80003270:	00048513          	mv	a0,s1
    80003274:	00e7b023          	sd	a4,0(a5)
    80003278:	00000097          	auipc	ra,0x0
    8000327c:	400080e7          	jalr	1024(ra) # 80003678 <__memset>
    80003280:	01813083          	ld	ra,24(sp)
    80003284:	01013403          	ld	s0,16(sp)
    80003288:	00048513          	mv	a0,s1
    8000328c:	00813483          	ld	s1,8(sp)
    80003290:	02010113          	addi	sp,sp,32
    80003294:	00008067          	ret

0000000080003298 <initlock>:
    80003298:	ff010113          	addi	sp,sp,-16
    8000329c:	00813423          	sd	s0,8(sp)
    800032a0:	01010413          	addi	s0,sp,16
    800032a4:	00813403          	ld	s0,8(sp)
    800032a8:	00b53423          	sd	a1,8(a0)
    800032ac:	00052023          	sw	zero,0(a0)
    800032b0:	00053823          	sd	zero,16(a0)
    800032b4:	01010113          	addi	sp,sp,16
    800032b8:	00008067          	ret

00000000800032bc <acquire>:
    800032bc:	fe010113          	addi	sp,sp,-32
    800032c0:	00813823          	sd	s0,16(sp)
    800032c4:	00913423          	sd	s1,8(sp)
    800032c8:	00113c23          	sd	ra,24(sp)
    800032cc:	01213023          	sd	s2,0(sp)
    800032d0:	02010413          	addi	s0,sp,32
    800032d4:	00050493          	mv	s1,a0
    800032d8:	10002973          	csrr	s2,sstatus
    800032dc:	100027f3          	csrr	a5,sstatus
    800032e0:	ffd7f793          	andi	a5,a5,-3
    800032e4:	10079073          	csrw	sstatus,a5
    800032e8:	fffff097          	auipc	ra,0xfffff
    800032ec:	8e4080e7          	jalr	-1820(ra) # 80001bcc <mycpu>
    800032f0:	07852783          	lw	a5,120(a0)
    800032f4:	06078e63          	beqz	a5,80003370 <acquire+0xb4>
    800032f8:	fffff097          	auipc	ra,0xfffff
    800032fc:	8d4080e7          	jalr	-1836(ra) # 80001bcc <mycpu>
    80003300:	07852783          	lw	a5,120(a0)
    80003304:	0004a703          	lw	a4,0(s1)
    80003308:	0017879b          	addiw	a5,a5,1
    8000330c:	06f52c23          	sw	a5,120(a0)
    80003310:	04071063          	bnez	a4,80003350 <acquire+0x94>
    80003314:	00100713          	li	a4,1
    80003318:	00070793          	mv	a5,a4
    8000331c:	0cf4a7af          	amoswap.w.aq	a5,a5,(s1)
    80003320:	0007879b          	sext.w	a5,a5
    80003324:	fe079ae3          	bnez	a5,80003318 <acquire+0x5c>
    80003328:	0ff0000f          	fence
    8000332c:	fffff097          	auipc	ra,0xfffff
    80003330:	8a0080e7          	jalr	-1888(ra) # 80001bcc <mycpu>
    80003334:	01813083          	ld	ra,24(sp)
    80003338:	01013403          	ld	s0,16(sp)
    8000333c:	00a4b823          	sd	a0,16(s1)
    80003340:	00013903          	ld	s2,0(sp)
    80003344:	00813483          	ld	s1,8(sp)
    80003348:	02010113          	addi	sp,sp,32
    8000334c:	00008067          	ret
    80003350:	0104b903          	ld	s2,16(s1)
    80003354:	fffff097          	auipc	ra,0xfffff
    80003358:	878080e7          	jalr	-1928(ra) # 80001bcc <mycpu>
    8000335c:	faa91ce3          	bne	s2,a0,80003314 <acquire+0x58>
    80003360:	00001517          	auipc	a0,0x1
    80003364:	eb050513          	addi	a0,a0,-336 # 80004210 <digits+0x20>
    80003368:	fffff097          	auipc	ra,0xfffff
    8000336c:	224080e7          	jalr	548(ra) # 8000258c <panic>
    80003370:	00195913          	srli	s2,s2,0x1
    80003374:	fffff097          	auipc	ra,0xfffff
    80003378:	858080e7          	jalr	-1960(ra) # 80001bcc <mycpu>
    8000337c:	00197913          	andi	s2,s2,1
    80003380:	07252e23          	sw	s2,124(a0)
    80003384:	f75ff06f          	j	800032f8 <acquire+0x3c>

0000000080003388 <release>:
    80003388:	fe010113          	addi	sp,sp,-32
    8000338c:	00813823          	sd	s0,16(sp)
    80003390:	00113c23          	sd	ra,24(sp)
    80003394:	00913423          	sd	s1,8(sp)
    80003398:	01213023          	sd	s2,0(sp)
    8000339c:	02010413          	addi	s0,sp,32
    800033a0:	00052783          	lw	a5,0(a0)
    800033a4:	00079a63          	bnez	a5,800033b8 <release+0x30>
    800033a8:	00001517          	auipc	a0,0x1
    800033ac:	e7050513          	addi	a0,a0,-400 # 80004218 <digits+0x28>
    800033b0:	fffff097          	auipc	ra,0xfffff
    800033b4:	1dc080e7          	jalr	476(ra) # 8000258c <panic>
    800033b8:	01053903          	ld	s2,16(a0)
    800033bc:	00050493          	mv	s1,a0
    800033c0:	fffff097          	auipc	ra,0xfffff
    800033c4:	80c080e7          	jalr	-2036(ra) # 80001bcc <mycpu>
    800033c8:	fea910e3          	bne	s2,a0,800033a8 <release+0x20>
    800033cc:	0004b823          	sd	zero,16(s1)
    800033d0:	0ff0000f          	fence
    800033d4:	0f50000f          	fence	iorw,ow
    800033d8:	0804a02f          	amoswap.w	zero,zero,(s1)
    800033dc:	ffffe097          	auipc	ra,0xffffe
    800033e0:	7f0080e7          	jalr	2032(ra) # 80001bcc <mycpu>
    800033e4:	100027f3          	csrr	a5,sstatus
    800033e8:	0027f793          	andi	a5,a5,2
    800033ec:	04079a63          	bnez	a5,80003440 <release+0xb8>
    800033f0:	07852783          	lw	a5,120(a0)
    800033f4:	02f05e63          	blez	a5,80003430 <release+0xa8>
    800033f8:	fff7871b          	addiw	a4,a5,-1
    800033fc:	06e52c23          	sw	a4,120(a0)
    80003400:	00071c63          	bnez	a4,80003418 <release+0x90>
    80003404:	07c52783          	lw	a5,124(a0)
    80003408:	00078863          	beqz	a5,80003418 <release+0x90>
    8000340c:	100027f3          	csrr	a5,sstatus
    80003410:	0027e793          	ori	a5,a5,2
    80003414:	10079073          	csrw	sstatus,a5
    80003418:	01813083          	ld	ra,24(sp)
    8000341c:	01013403          	ld	s0,16(sp)
    80003420:	00813483          	ld	s1,8(sp)
    80003424:	00013903          	ld	s2,0(sp)
    80003428:	02010113          	addi	sp,sp,32
    8000342c:	00008067          	ret
    80003430:	00001517          	auipc	a0,0x1
    80003434:	e0850513          	addi	a0,a0,-504 # 80004238 <digits+0x48>
    80003438:	fffff097          	auipc	ra,0xfffff
    8000343c:	154080e7          	jalr	340(ra) # 8000258c <panic>
    80003440:	00001517          	auipc	a0,0x1
    80003444:	de050513          	addi	a0,a0,-544 # 80004220 <digits+0x30>
    80003448:	fffff097          	auipc	ra,0xfffff
    8000344c:	144080e7          	jalr	324(ra) # 8000258c <panic>

0000000080003450 <holding>:
    80003450:	00052783          	lw	a5,0(a0)
    80003454:	00079663          	bnez	a5,80003460 <holding+0x10>
    80003458:	00000513          	li	a0,0
    8000345c:	00008067          	ret
    80003460:	fe010113          	addi	sp,sp,-32
    80003464:	00813823          	sd	s0,16(sp)
    80003468:	00913423          	sd	s1,8(sp)
    8000346c:	00113c23          	sd	ra,24(sp)
    80003470:	02010413          	addi	s0,sp,32
    80003474:	01053483          	ld	s1,16(a0)
    80003478:	ffffe097          	auipc	ra,0xffffe
    8000347c:	754080e7          	jalr	1876(ra) # 80001bcc <mycpu>
    80003480:	01813083          	ld	ra,24(sp)
    80003484:	01013403          	ld	s0,16(sp)
    80003488:	40a48533          	sub	a0,s1,a0
    8000348c:	00153513          	seqz	a0,a0
    80003490:	00813483          	ld	s1,8(sp)
    80003494:	02010113          	addi	sp,sp,32
    80003498:	00008067          	ret

000000008000349c <push_off>:
    8000349c:	fe010113          	addi	sp,sp,-32
    800034a0:	00813823          	sd	s0,16(sp)
    800034a4:	00113c23          	sd	ra,24(sp)
    800034a8:	00913423          	sd	s1,8(sp)
    800034ac:	02010413          	addi	s0,sp,32
    800034b0:	100024f3          	csrr	s1,sstatus
    800034b4:	100027f3          	csrr	a5,sstatus
    800034b8:	ffd7f793          	andi	a5,a5,-3
    800034bc:	10079073          	csrw	sstatus,a5
    800034c0:	ffffe097          	auipc	ra,0xffffe
    800034c4:	70c080e7          	jalr	1804(ra) # 80001bcc <mycpu>
    800034c8:	07852783          	lw	a5,120(a0)
    800034cc:	02078663          	beqz	a5,800034f8 <push_off+0x5c>
    800034d0:	ffffe097          	auipc	ra,0xffffe
    800034d4:	6fc080e7          	jalr	1788(ra) # 80001bcc <mycpu>
    800034d8:	07852783          	lw	a5,120(a0)
    800034dc:	01813083          	ld	ra,24(sp)
    800034e0:	01013403          	ld	s0,16(sp)
    800034e4:	0017879b          	addiw	a5,a5,1
    800034e8:	06f52c23          	sw	a5,120(a0)
    800034ec:	00813483          	ld	s1,8(sp)
    800034f0:	02010113          	addi	sp,sp,32
    800034f4:	00008067          	ret
    800034f8:	0014d493          	srli	s1,s1,0x1
    800034fc:	ffffe097          	auipc	ra,0xffffe
    80003500:	6d0080e7          	jalr	1744(ra) # 80001bcc <mycpu>
    80003504:	0014f493          	andi	s1,s1,1
    80003508:	06952e23          	sw	s1,124(a0)
    8000350c:	fc5ff06f          	j	800034d0 <push_off+0x34>

0000000080003510 <pop_off>:
    80003510:	ff010113          	addi	sp,sp,-16
    80003514:	00813023          	sd	s0,0(sp)
    80003518:	00113423          	sd	ra,8(sp)
    8000351c:	01010413          	addi	s0,sp,16
    80003520:	ffffe097          	auipc	ra,0xffffe
    80003524:	6ac080e7          	jalr	1708(ra) # 80001bcc <mycpu>
    80003528:	100027f3          	csrr	a5,sstatus
    8000352c:	0027f793          	andi	a5,a5,2
    80003530:	04079663          	bnez	a5,8000357c <pop_off+0x6c>
    80003534:	07852783          	lw	a5,120(a0)
    80003538:	02f05a63          	blez	a5,8000356c <pop_off+0x5c>
    8000353c:	fff7871b          	addiw	a4,a5,-1
    80003540:	06e52c23          	sw	a4,120(a0)
    80003544:	00071c63          	bnez	a4,8000355c <pop_off+0x4c>
    80003548:	07c52783          	lw	a5,124(a0)
    8000354c:	00078863          	beqz	a5,8000355c <pop_off+0x4c>
    80003550:	100027f3          	csrr	a5,sstatus
    80003554:	0027e793          	ori	a5,a5,2
    80003558:	10079073          	csrw	sstatus,a5
    8000355c:	00813083          	ld	ra,8(sp)
    80003560:	00013403          	ld	s0,0(sp)
    80003564:	01010113          	addi	sp,sp,16
    80003568:	00008067          	ret
    8000356c:	00001517          	auipc	a0,0x1
    80003570:	ccc50513          	addi	a0,a0,-820 # 80004238 <digits+0x48>
    80003574:	fffff097          	auipc	ra,0xfffff
    80003578:	018080e7          	jalr	24(ra) # 8000258c <panic>
    8000357c:	00001517          	auipc	a0,0x1
    80003580:	ca450513          	addi	a0,a0,-860 # 80004220 <digits+0x30>
    80003584:	fffff097          	auipc	ra,0xfffff
    80003588:	008080e7          	jalr	8(ra) # 8000258c <panic>

000000008000358c <push_on>:
    8000358c:	fe010113          	addi	sp,sp,-32
    80003590:	00813823          	sd	s0,16(sp)
    80003594:	00113c23          	sd	ra,24(sp)
    80003598:	00913423          	sd	s1,8(sp)
    8000359c:	02010413          	addi	s0,sp,32
    800035a0:	100024f3          	csrr	s1,sstatus
    800035a4:	100027f3          	csrr	a5,sstatus
    800035a8:	0027e793          	ori	a5,a5,2
    800035ac:	10079073          	csrw	sstatus,a5
    800035b0:	ffffe097          	auipc	ra,0xffffe
    800035b4:	61c080e7          	jalr	1564(ra) # 80001bcc <mycpu>
    800035b8:	07852783          	lw	a5,120(a0)
    800035bc:	02078663          	beqz	a5,800035e8 <push_on+0x5c>
    800035c0:	ffffe097          	auipc	ra,0xffffe
    800035c4:	60c080e7          	jalr	1548(ra) # 80001bcc <mycpu>
    800035c8:	07852783          	lw	a5,120(a0)
    800035cc:	01813083          	ld	ra,24(sp)
    800035d0:	01013403          	ld	s0,16(sp)
    800035d4:	0017879b          	addiw	a5,a5,1
    800035d8:	06f52c23          	sw	a5,120(a0)
    800035dc:	00813483          	ld	s1,8(sp)
    800035e0:	02010113          	addi	sp,sp,32
    800035e4:	00008067          	ret
    800035e8:	0014d493          	srli	s1,s1,0x1
    800035ec:	ffffe097          	auipc	ra,0xffffe
    800035f0:	5e0080e7          	jalr	1504(ra) # 80001bcc <mycpu>
    800035f4:	0014f493          	andi	s1,s1,1
    800035f8:	06952e23          	sw	s1,124(a0)
    800035fc:	fc5ff06f          	j	800035c0 <push_on+0x34>

0000000080003600 <pop_on>:
    80003600:	ff010113          	addi	sp,sp,-16
    80003604:	00813023          	sd	s0,0(sp)
    80003608:	00113423          	sd	ra,8(sp)
    8000360c:	01010413          	addi	s0,sp,16
    80003610:	ffffe097          	auipc	ra,0xffffe
    80003614:	5bc080e7          	jalr	1468(ra) # 80001bcc <mycpu>
    80003618:	100027f3          	csrr	a5,sstatus
    8000361c:	0027f793          	andi	a5,a5,2
    80003620:	04078463          	beqz	a5,80003668 <pop_on+0x68>
    80003624:	07852783          	lw	a5,120(a0)
    80003628:	02f05863          	blez	a5,80003658 <pop_on+0x58>
    8000362c:	fff7879b          	addiw	a5,a5,-1
    80003630:	06f52c23          	sw	a5,120(a0)
    80003634:	07853783          	ld	a5,120(a0)
    80003638:	00079863          	bnez	a5,80003648 <pop_on+0x48>
    8000363c:	100027f3          	csrr	a5,sstatus
    80003640:	ffd7f793          	andi	a5,a5,-3
    80003644:	10079073          	csrw	sstatus,a5
    80003648:	00813083          	ld	ra,8(sp)
    8000364c:	00013403          	ld	s0,0(sp)
    80003650:	01010113          	addi	sp,sp,16
    80003654:	00008067          	ret
    80003658:	00001517          	auipc	a0,0x1
    8000365c:	c0850513          	addi	a0,a0,-1016 # 80004260 <digits+0x70>
    80003660:	fffff097          	auipc	ra,0xfffff
    80003664:	f2c080e7          	jalr	-212(ra) # 8000258c <panic>
    80003668:	00001517          	auipc	a0,0x1
    8000366c:	bd850513          	addi	a0,a0,-1064 # 80004240 <digits+0x50>
    80003670:	fffff097          	auipc	ra,0xfffff
    80003674:	f1c080e7          	jalr	-228(ra) # 8000258c <panic>

0000000080003678 <__memset>:
    80003678:	ff010113          	addi	sp,sp,-16
    8000367c:	00813423          	sd	s0,8(sp)
    80003680:	01010413          	addi	s0,sp,16
    80003684:	1a060e63          	beqz	a2,80003840 <__memset+0x1c8>
    80003688:	40a007b3          	neg	a5,a0
    8000368c:	0077f793          	andi	a5,a5,7
    80003690:	00778693          	addi	a3,a5,7
    80003694:	00b00813          	li	a6,11
    80003698:	0ff5f593          	andi	a1,a1,255
    8000369c:	fff6071b          	addiw	a4,a2,-1
    800036a0:	1b06e663          	bltu	a3,a6,8000384c <__memset+0x1d4>
    800036a4:	1cd76463          	bltu	a4,a3,8000386c <__memset+0x1f4>
    800036a8:	1a078e63          	beqz	a5,80003864 <__memset+0x1ec>
    800036ac:	00b50023          	sb	a1,0(a0)
    800036b0:	00100713          	li	a4,1
    800036b4:	1ae78463          	beq	a5,a4,8000385c <__memset+0x1e4>
    800036b8:	00b500a3          	sb	a1,1(a0)
    800036bc:	00200713          	li	a4,2
    800036c0:	1ae78a63          	beq	a5,a4,80003874 <__memset+0x1fc>
    800036c4:	00b50123          	sb	a1,2(a0)
    800036c8:	00300713          	li	a4,3
    800036cc:	18e78463          	beq	a5,a4,80003854 <__memset+0x1dc>
    800036d0:	00b501a3          	sb	a1,3(a0)
    800036d4:	00400713          	li	a4,4
    800036d8:	1ae78263          	beq	a5,a4,8000387c <__memset+0x204>
    800036dc:	00b50223          	sb	a1,4(a0)
    800036e0:	00500713          	li	a4,5
    800036e4:	1ae78063          	beq	a5,a4,80003884 <__memset+0x20c>
    800036e8:	00b502a3          	sb	a1,5(a0)
    800036ec:	00700713          	li	a4,7
    800036f0:	18e79e63          	bne	a5,a4,8000388c <__memset+0x214>
    800036f4:	00b50323          	sb	a1,6(a0)
    800036f8:	00700e93          	li	t4,7
    800036fc:	00859713          	slli	a4,a1,0x8
    80003700:	00e5e733          	or	a4,a1,a4
    80003704:	01059e13          	slli	t3,a1,0x10
    80003708:	01c76e33          	or	t3,a4,t3
    8000370c:	01859313          	slli	t1,a1,0x18
    80003710:	006e6333          	or	t1,t3,t1
    80003714:	02059893          	slli	a7,a1,0x20
    80003718:	40f60e3b          	subw	t3,a2,a5
    8000371c:	011368b3          	or	a7,t1,a7
    80003720:	02859813          	slli	a6,a1,0x28
    80003724:	0108e833          	or	a6,a7,a6
    80003728:	03059693          	slli	a3,a1,0x30
    8000372c:	003e589b          	srliw	a7,t3,0x3
    80003730:	00d866b3          	or	a3,a6,a3
    80003734:	03859713          	slli	a4,a1,0x38
    80003738:	00389813          	slli	a6,a7,0x3
    8000373c:	00f507b3          	add	a5,a0,a5
    80003740:	00e6e733          	or	a4,a3,a4
    80003744:	000e089b          	sext.w	a7,t3
    80003748:	00f806b3          	add	a3,a6,a5
    8000374c:	00e7b023          	sd	a4,0(a5)
    80003750:	00878793          	addi	a5,a5,8
    80003754:	fed79ce3          	bne	a5,a3,8000374c <__memset+0xd4>
    80003758:	ff8e7793          	andi	a5,t3,-8
    8000375c:	0007871b          	sext.w	a4,a5
    80003760:	01d787bb          	addw	a5,a5,t4
    80003764:	0ce88e63          	beq	a7,a4,80003840 <__memset+0x1c8>
    80003768:	00f50733          	add	a4,a0,a5
    8000376c:	00b70023          	sb	a1,0(a4)
    80003770:	0017871b          	addiw	a4,a5,1
    80003774:	0cc77663          	bgeu	a4,a2,80003840 <__memset+0x1c8>
    80003778:	00e50733          	add	a4,a0,a4
    8000377c:	00b70023          	sb	a1,0(a4)
    80003780:	0027871b          	addiw	a4,a5,2
    80003784:	0ac77e63          	bgeu	a4,a2,80003840 <__memset+0x1c8>
    80003788:	00e50733          	add	a4,a0,a4
    8000378c:	00b70023          	sb	a1,0(a4)
    80003790:	0037871b          	addiw	a4,a5,3
    80003794:	0ac77663          	bgeu	a4,a2,80003840 <__memset+0x1c8>
    80003798:	00e50733          	add	a4,a0,a4
    8000379c:	00b70023          	sb	a1,0(a4)
    800037a0:	0047871b          	addiw	a4,a5,4
    800037a4:	08c77e63          	bgeu	a4,a2,80003840 <__memset+0x1c8>
    800037a8:	00e50733          	add	a4,a0,a4
    800037ac:	00b70023          	sb	a1,0(a4)
    800037b0:	0057871b          	addiw	a4,a5,5
    800037b4:	08c77663          	bgeu	a4,a2,80003840 <__memset+0x1c8>
    800037b8:	00e50733          	add	a4,a0,a4
    800037bc:	00b70023          	sb	a1,0(a4)
    800037c0:	0067871b          	addiw	a4,a5,6
    800037c4:	06c77e63          	bgeu	a4,a2,80003840 <__memset+0x1c8>
    800037c8:	00e50733          	add	a4,a0,a4
    800037cc:	00b70023          	sb	a1,0(a4)
    800037d0:	0077871b          	addiw	a4,a5,7
    800037d4:	06c77663          	bgeu	a4,a2,80003840 <__memset+0x1c8>
    800037d8:	00e50733          	add	a4,a0,a4
    800037dc:	00b70023          	sb	a1,0(a4)
    800037e0:	0087871b          	addiw	a4,a5,8
    800037e4:	04c77e63          	bgeu	a4,a2,80003840 <__memset+0x1c8>
    800037e8:	00e50733          	add	a4,a0,a4
    800037ec:	00b70023          	sb	a1,0(a4)
    800037f0:	0097871b          	addiw	a4,a5,9
    800037f4:	04c77663          	bgeu	a4,a2,80003840 <__memset+0x1c8>
    800037f8:	00e50733          	add	a4,a0,a4
    800037fc:	00b70023          	sb	a1,0(a4)
    80003800:	00a7871b          	addiw	a4,a5,10
    80003804:	02c77e63          	bgeu	a4,a2,80003840 <__memset+0x1c8>
    80003808:	00e50733          	add	a4,a0,a4
    8000380c:	00b70023          	sb	a1,0(a4)
    80003810:	00b7871b          	addiw	a4,a5,11
    80003814:	02c77663          	bgeu	a4,a2,80003840 <__memset+0x1c8>
    80003818:	00e50733          	add	a4,a0,a4
    8000381c:	00b70023          	sb	a1,0(a4)
    80003820:	00c7871b          	addiw	a4,a5,12
    80003824:	00c77e63          	bgeu	a4,a2,80003840 <__memset+0x1c8>
    80003828:	00e50733          	add	a4,a0,a4
    8000382c:	00b70023          	sb	a1,0(a4)
    80003830:	00d7879b          	addiw	a5,a5,13
    80003834:	00c7f663          	bgeu	a5,a2,80003840 <__memset+0x1c8>
    80003838:	00f507b3          	add	a5,a0,a5
    8000383c:	00b78023          	sb	a1,0(a5)
    80003840:	00813403          	ld	s0,8(sp)
    80003844:	01010113          	addi	sp,sp,16
    80003848:	00008067          	ret
    8000384c:	00b00693          	li	a3,11
    80003850:	e55ff06f          	j	800036a4 <__memset+0x2c>
    80003854:	00300e93          	li	t4,3
    80003858:	ea5ff06f          	j	800036fc <__memset+0x84>
    8000385c:	00100e93          	li	t4,1
    80003860:	e9dff06f          	j	800036fc <__memset+0x84>
    80003864:	00000e93          	li	t4,0
    80003868:	e95ff06f          	j	800036fc <__memset+0x84>
    8000386c:	00000793          	li	a5,0
    80003870:	ef9ff06f          	j	80003768 <__memset+0xf0>
    80003874:	00200e93          	li	t4,2
    80003878:	e85ff06f          	j	800036fc <__memset+0x84>
    8000387c:	00400e93          	li	t4,4
    80003880:	e7dff06f          	j	800036fc <__memset+0x84>
    80003884:	00500e93          	li	t4,5
    80003888:	e75ff06f          	j	800036fc <__memset+0x84>
    8000388c:	00600e93          	li	t4,6
    80003890:	e6dff06f          	j	800036fc <__memset+0x84>

0000000080003894 <__memmove>:
    80003894:	ff010113          	addi	sp,sp,-16
    80003898:	00813423          	sd	s0,8(sp)
    8000389c:	01010413          	addi	s0,sp,16
    800038a0:	0e060863          	beqz	a2,80003990 <__memmove+0xfc>
    800038a4:	fff6069b          	addiw	a3,a2,-1
    800038a8:	0006881b          	sext.w	a6,a3
    800038ac:	0ea5e863          	bltu	a1,a0,8000399c <__memmove+0x108>
    800038b0:	00758713          	addi	a4,a1,7
    800038b4:	00a5e7b3          	or	a5,a1,a0
    800038b8:	40a70733          	sub	a4,a4,a0
    800038bc:	0077f793          	andi	a5,a5,7
    800038c0:	00f73713          	sltiu	a4,a4,15
    800038c4:	00174713          	xori	a4,a4,1
    800038c8:	0017b793          	seqz	a5,a5
    800038cc:	00e7f7b3          	and	a5,a5,a4
    800038d0:	10078863          	beqz	a5,800039e0 <__memmove+0x14c>
    800038d4:	00900793          	li	a5,9
    800038d8:	1107f463          	bgeu	a5,a6,800039e0 <__memmove+0x14c>
    800038dc:	0036581b          	srliw	a6,a2,0x3
    800038e0:	fff8081b          	addiw	a6,a6,-1
    800038e4:	02081813          	slli	a6,a6,0x20
    800038e8:	01d85893          	srli	a7,a6,0x1d
    800038ec:	00858813          	addi	a6,a1,8
    800038f0:	00058793          	mv	a5,a1
    800038f4:	00050713          	mv	a4,a0
    800038f8:	01088833          	add	a6,a7,a6
    800038fc:	0007b883          	ld	a7,0(a5)
    80003900:	00878793          	addi	a5,a5,8
    80003904:	00870713          	addi	a4,a4,8
    80003908:	ff173c23          	sd	a7,-8(a4)
    8000390c:	ff0798e3          	bne	a5,a6,800038fc <__memmove+0x68>
    80003910:	ff867713          	andi	a4,a2,-8
    80003914:	02071793          	slli	a5,a4,0x20
    80003918:	0207d793          	srli	a5,a5,0x20
    8000391c:	00f585b3          	add	a1,a1,a5
    80003920:	40e686bb          	subw	a3,a3,a4
    80003924:	00f507b3          	add	a5,a0,a5
    80003928:	06e60463          	beq	a2,a4,80003990 <__memmove+0xfc>
    8000392c:	0005c703          	lbu	a4,0(a1)
    80003930:	00e78023          	sb	a4,0(a5)
    80003934:	04068e63          	beqz	a3,80003990 <__memmove+0xfc>
    80003938:	0015c603          	lbu	a2,1(a1)
    8000393c:	00100713          	li	a4,1
    80003940:	00c780a3          	sb	a2,1(a5)
    80003944:	04e68663          	beq	a3,a4,80003990 <__memmove+0xfc>
    80003948:	0025c603          	lbu	a2,2(a1)
    8000394c:	00200713          	li	a4,2
    80003950:	00c78123          	sb	a2,2(a5)
    80003954:	02e68e63          	beq	a3,a4,80003990 <__memmove+0xfc>
    80003958:	0035c603          	lbu	a2,3(a1)
    8000395c:	00300713          	li	a4,3
    80003960:	00c781a3          	sb	a2,3(a5)
    80003964:	02e68663          	beq	a3,a4,80003990 <__memmove+0xfc>
    80003968:	0045c603          	lbu	a2,4(a1)
    8000396c:	00400713          	li	a4,4
    80003970:	00c78223          	sb	a2,4(a5)
    80003974:	00e68e63          	beq	a3,a4,80003990 <__memmove+0xfc>
    80003978:	0055c603          	lbu	a2,5(a1)
    8000397c:	00500713          	li	a4,5
    80003980:	00c782a3          	sb	a2,5(a5)
    80003984:	00e68663          	beq	a3,a4,80003990 <__memmove+0xfc>
    80003988:	0065c703          	lbu	a4,6(a1)
    8000398c:	00e78323          	sb	a4,6(a5)
    80003990:	00813403          	ld	s0,8(sp)
    80003994:	01010113          	addi	sp,sp,16
    80003998:	00008067          	ret
    8000399c:	02061713          	slli	a4,a2,0x20
    800039a0:	02075713          	srli	a4,a4,0x20
    800039a4:	00e587b3          	add	a5,a1,a4
    800039a8:	f0f574e3          	bgeu	a0,a5,800038b0 <__memmove+0x1c>
    800039ac:	02069613          	slli	a2,a3,0x20
    800039b0:	02065613          	srli	a2,a2,0x20
    800039b4:	fff64613          	not	a2,a2
    800039b8:	00e50733          	add	a4,a0,a4
    800039bc:	00c78633          	add	a2,a5,a2
    800039c0:	fff7c683          	lbu	a3,-1(a5)
    800039c4:	fff78793          	addi	a5,a5,-1
    800039c8:	fff70713          	addi	a4,a4,-1
    800039cc:	00d70023          	sb	a3,0(a4)
    800039d0:	fec798e3          	bne	a5,a2,800039c0 <__memmove+0x12c>
    800039d4:	00813403          	ld	s0,8(sp)
    800039d8:	01010113          	addi	sp,sp,16
    800039dc:	00008067          	ret
    800039e0:	02069713          	slli	a4,a3,0x20
    800039e4:	02075713          	srli	a4,a4,0x20
    800039e8:	00170713          	addi	a4,a4,1
    800039ec:	00e50733          	add	a4,a0,a4
    800039f0:	00050793          	mv	a5,a0
    800039f4:	0005c683          	lbu	a3,0(a1)
    800039f8:	00178793          	addi	a5,a5,1
    800039fc:	00158593          	addi	a1,a1,1
    80003a00:	fed78fa3          	sb	a3,-1(a5)
    80003a04:	fee798e3          	bne	a5,a4,800039f4 <__memmove+0x160>
    80003a08:	f89ff06f          	j	80003990 <__memmove+0xfc>

0000000080003a0c <__mem_free>:
    80003a0c:	ff010113          	addi	sp,sp,-16
    80003a10:	00813423          	sd	s0,8(sp)
    80003a14:	01010413          	addi	s0,sp,16
    80003a18:	00001597          	auipc	a1,0x1
    80003a1c:	c9058593          	addi	a1,a1,-880 # 800046a8 <freep>
    80003a20:	0005b783          	ld	a5,0(a1)
    80003a24:	ff050693          	addi	a3,a0,-16
    80003a28:	0007b703          	ld	a4,0(a5)
    80003a2c:	00d7fc63          	bgeu	a5,a3,80003a44 <__mem_free+0x38>
    80003a30:	00e6ee63          	bltu	a3,a4,80003a4c <__mem_free+0x40>
    80003a34:	00e7fc63          	bgeu	a5,a4,80003a4c <__mem_free+0x40>
    80003a38:	00070793          	mv	a5,a4
    80003a3c:	0007b703          	ld	a4,0(a5)
    80003a40:	fed7e8e3          	bltu	a5,a3,80003a30 <__mem_free+0x24>
    80003a44:	fee7eae3          	bltu	a5,a4,80003a38 <__mem_free+0x2c>
    80003a48:	fee6f8e3          	bgeu	a3,a4,80003a38 <__mem_free+0x2c>
    80003a4c:	ff852803          	lw	a6,-8(a0)
    80003a50:	02081613          	slli	a2,a6,0x20
    80003a54:	01c65613          	srli	a2,a2,0x1c
    80003a58:	00c68633          	add	a2,a3,a2
    80003a5c:	02c70a63          	beq	a4,a2,80003a90 <__mem_free+0x84>
    80003a60:	fee53823          	sd	a4,-16(a0)
    80003a64:	0087a503          	lw	a0,8(a5)
    80003a68:	02051613          	slli	a2,a0,0x20
    80003a6c:	01c65613          	srli	a2,a2,0x1c
    80003a70:	00c78633          	add	a2,a5,a2
    80003a74:	04c68263          	beq	a3,a2,80003ab8 <__mem_free+0xac>
    80003a78:	00813403          	ld	s0,8(sp)
    80003a7c:	00d7b023          	sd	a3,0(a5)
    80003a80:	00f5b023          	sd	a5,0(a1)
    80003a84:	00000513          	li	a0,0
    80003a88:	01010113          	addi	sp,sp,16
    80003a8c:	00008067          	ret
    80003a90:	00872603          	lw	a2,8(a4)
    80003a94:	00073703          	ld	a4,0(a4)
    80003a98:	0106083b          	addw	a6,a2,a6
    80003a9c:	ff052c23          	sw	a6,-8(a0)
    80003aa0:	fee53823          	sd	a4,-16(a0)
    80003aa4:	0087a503          	lw	a0,8(a5)
    80003aa8:	02051613          	slli	a2,a0,0x20
    80003aac:	01c65613          	srli	a2,a2,0x1c
    80003ab0:	00c78633          	add	a2,a5,a2
    80003ab4:	fcc692e3          	bne	a3,a2,80003a78 <__mem_free+0x6c>
    80003ab8:	00813403          	ld	s0,8(sp)
    80003abc:	0105053b          	addw	a0,a0,a6
    80003ac0:	00a7a423          	sw	a0,8(a5)
    80003ac4:	00e7b023          	sd	a4,0(a5)
    80003ac8:	00f5b023          	sd	a5,0(a1)
    80003acc:	00000513          	li	a0,0
    80003ad0:	01010113          	addi	sp,sp,16
    80003ad4:	00008067          	ret

0000000080003ad8 <__mem_alloc>:
    80003ad8:	fc010113          	addi	sp,sp,-64
    80003adc:	02813823          	sd	s0,48(sp)
    80003ae0:	02913423          	sd	s1,40(sp)
    80003ae4:	03213023          	sd	s2,32(sp)
    80003ae8:	01513423          	sd	s5,8(sp)
    80003aec:	02113c23          	sd	ra,56(sp)
    80003af0:	01313c23          	sd	s3,24(sp)
    80003af4:	01413823          	sd	s4,16(sp)
    80003af8:	01613023          	sd	s6,0(sp)
    80003afc:	04010413          	addi	s0,sp,64
    80003b00:	00001a97          	auipc	s5,0x1
    80003b04:	ba8a8a93          	addi	s5,s5,-1112 # 800046a8 <freep>
    80003b08:	00f50913          	addi	s2,a0,15
    80003b0c:	000ab683          	ld	a3,0(s5)
    80003b10:	00495913          	srli	s2,s2,0x4
    80003b14:	0019049b          	addiw	s1,s2,1
    80003b18:	00048913          	mv	s2,s1
    80003b1c:	0c068c63          	beqz	a3,80003bf4 <__mem_alloc+0x11c>
    80003b20:	0006b503          	ld	a0,0(a3)
    80003b24:	00852703          	lw	a4,8(a0)
    80003b28:	10977063          	bgeu	a4,s1,80003c28 <__mem_alloc+0x150>
    80003b2c:	000017b7          	lui	a5,0x1
    80003b30:	0009099b          	sext.w	s3,s2
    80003b34:	0af4e863          	bltu	s1,a5,80003be4 <__mem_alloc+0x10c>
    80003b38:	02099a13          	slli	s4,s3,0x20
    80003b3c:	01ca5a13          	srli	s4,s4,0x1c
    80003b40:	fff00b13          	li	s6,-1
    80003b44:	0100006f          	j	80003b54 <__mem_alloc+0x7c>
    80003b48:	0007b503          	ld	a0,0(a5) # 1000 <_entry-0x7ffff000>
    80003b4c:	00852703          	lw	a4,8(a0)
    80003b50:	04977463          	bgeu	a4,s1,80003b98 <__mem_alloc+0xc0>
    80003b54:	00050793          	mv	a5,a0
    80003b58:	fea698e3          	bne	a3,a0,80003b48 <__mem_alloc+0x70>
    80003b5c:	000a0513          	mv	a0,s4
    80003b60:	00000097          	auipc	ra,0x0
    80003b64:	1f0080e7          	jalr	496(ra) # 80003d50 <kvmincrease>
    80003b68:	00050793          	mv	a5,a0
    80003b6c:	01050513          	addi	a0,a0,16
    80003b70:	07678e63          	beq	a5,s6,80003bec <__mem_alloc+0x114>
    80003b74:	0137a423          	sw	s3,8(a5)
    80003b78:	00000097          	auipc	ra,0x0
    80003b7c:	e94080e7          	jalr	-364(ra) # 80003a0c <__mem_free>
    80003b80:	000ab783          	ld	a5,0(s5)
    80003b84:	06078463          	beqz	a5,80003bec <__mem_alloc+0x114>
    80003b88:	0007b503          	ld	a0,0(a5)
    80003b8c:	00078693          	mv	a3,a5
    80003b90:	00852703          	lw	a4,8(a0)
    80003b94:	fc9760e3          	bltu	a4,s1,80003b54 <__mem_alloc+0x7c>
    80003b98:	08e48263          	beq	s1,a4,80003c1c <__mem_alloc+0x144>
    80003b9c:	4127073b          	subw	a4,a4,s2
    80003ba0:	02071693          	slli	a3,a4,0x20
    80003ba4:	01c6d693          	srli	a3,a3,0x1c
    80003ba8:	00e52423          	sw	a4,8(a0)
    80003bac:	00d50533          	add	a0,a0,a3
    80003bb0:	01252423          	sw	s2,8(a0)
    80003bb4:	00fab023          	sd	a5,0(s5)
    80003bb8:	01050513          	addi	a0,a0,16
    80003bbc:	03813083          	ld	ra,56(sp)
    80003bc0:	03013403          	ld	s0,48(sp)
    80003bc4:	02813483          	ld	s1,40(sp)
    80003bc8:	02013903          	ld	s2,32(sp)
    80003bcc:	01813983          	ld	s3,24(sp)
    80003bd0:	01013a03          	ld	s4,16(sp)
    80003bd4:	00813a83          	ld	s5,8(sp)
    80003bd8:	00013b03          	ld	s6,0(sp)
    80003bdc:	04010113          	addi	sp,sp,64
    80003be0:	00008067          	ret
    80003be4:	000019b7          	lui	s3,0x1
    80003be8:	f51ff06f          	j	80003b38 <__mem_alloc+0x60>
    80003bec:	00000513          	li	a0,0
    80003bf0:	fcdff06f          	j	80003bbc <__mem_alloc+0xe4>
    80003bf4:	00002797          	auipc	a5,0x2
    80003bf8:	d3c78793          	addi	a5,a5,-708 # 80005930 <base>
    80003bfc:	00078513          	mv	a0,a5
    80003c00:	00fab023          	sd	a5,0(s5)
    80003c04:	00f7b023          	sd	a5,0(a5)
    80003c08:	00000713          	li	a4,0
    80003c0c:	00002797          	auipc	a5,0x2
    80003c10:	d207a623          	sw	zero,-724(a5) # 80005938 <base+0x8>
    80003c14:	00050693          	mv	a3,a0
    80003c18:	f11ff06f          	j	80003b28 <__mem_alloc+0x50>
    80003c1c:	00053703          	ld	a4,0(a0)
    80003c20:	00e7b023          	sd	a4,0(a5)
    80003c24:	f91ff06f          	j	80003bb4 <__mem_alloc+0xdc>
    80003c28:	00068793          	mv	a5,a3
    80003c2c:	f6dff06f          	j	80003b98 <__mem_alloc+0xc0>

0000000080003c30 <__putc>:
    80003c30:	fe010113          	addi	sp,sp,-32
    80003c34:	00813823          	sd	s0,16(sp)
    80003c38:	00113c23          	sd	ra,24(sp)
    80003c3c:	02010413          	addi	s0,sp,32
    80003c40:	00050793          	mv	a5,a0
    80003c44:	fef40593          	addi	a1,s0,-17
    80003c48:	00100613          	li	a2,1
    80003c4c:	00000513          	li	a0,0
    80003c50:	fef407a3          	sb	a5,-17(s0)
    80003c54:	fffff097          	auipc	ra,0xfffff
    80003c58:	918080e7          	jalr	-1768(ra) # 8000256c <console_write>
    80003c5c:	01813083          	ld	ra,24(sp)
    80003c60:	01013403          	ld	s0,16(sp)
    80003c64:	02010113          	addi	sp,sp,32
    80003c68:	00008067          	ret

0000000080003c6c <__getc>:
    80003c6c:	fe010113          	addi	sp,sp,-32
    80003c70:	00813823          	sd	s0,16(sp)
    80003c74:	00113c23          	sd	ra,24(sp)
    80003c78:	02010413          	addi	s0,sp,32
    80003c7c:	fe840593          	addi	a1,s0,-24
    80003c80:	00100613          	li	a2,1
    80003c84:	00000513          	li	a0,0
    80003c88:	fffff097          	auipc	ra,0xfffff
    80003c8c:	8c4080e7          	jalr	-1852(ra) # 8000254c <console_read>
    80003c90:	fe844503          	lbu	a0,-24(s0)
    80003c94:	01813083          	ld	ra,24(sp)
    80003c98:	01013403          	ld	s0,16(sp)
    80003c9c:	02010113          	addi	sp,sp,32
    80003ca0:	00008067          	ret

0000000080003ca4 <console_handler>:
    80003ca4:	fe010113          	addi	sp,sp,-32
    80003ca8:	00813823          	sd	s0,16(sp)
    80003cac:	00113c23          	sd	ra,24(sp)
    80003cb0:	00913423          	sd	s1,8(sp)
    80003cb4:	02010413          	addi	s0,sp,32
    80003cb8:	14202773          	csrr	a4,scause
    80003cbc:	100027f3          	csrr	a5,sstatus
    80003cc0:	0027f793          	andi	a5,a5,2
    80003cc4:	06079e63          	bnez	a5,80003d40 <console_handler+0x9c>
    80003cc8:	00074c63          	bltz	a4,80003ce0 <console_handler+0x3c>
    80003ccc:	01813083          	ld	ra,24(sp)
    80003cd0:	01013403          	ld	s0,16(sp)
    80003cd4:	00813483          	ld	s1,8(sp)
    80003cd8:	02010113          	addi	sp,sp,32
    80003cdc:	00008067          	ret
    80003ce0:	0ff77713          	andi	a4,a4,255
    80003ce4:	00900793          	li	a5,9
    80003ce8:	fef712e3          	bne	a4,a5,80003ccc <console_handler+0x28>
    80003cec:	ffffe097          	auipc	ra,0xffffe
    80003cf0:	4b8080e7          	jalr	1208(ra) # 800021a4 <plic_claim>
    80003cf4:	00a00793          	li	a5,10
    80003cf8:	00050493          	mv	s1,a0
    80003cfc:	02f50c63          	beq	a0,a5,80003d34 <console_handler+0x90>
    80003d00:	fc0506e3          	beqz	a0,80003ccc <console_handler+0x28>
    80003d04:	00050593          	mv	a1,a0
    80003d08:	00000517          	auipc	a0,0x0
    80003d0c:	46050513          	addi	a0,a0,1120 # 80004168 <_ZZ12printIntegermE6digits+0xe0>
    80003d10:	fffff097          	auipc	ra,0xfffff
    80003d14:	8d8080e7          	jalr	-1832(ra) # 800025e8 <__printf>
    80003d18:	01013403          	ld	s0,16(sp)
    80003d1c:	01813083          	ld	ra,24(sp)
    80003d20:	00048513          	mv	a0,s1
    80003d24:	00813483          	ld	s1,8(sp)
    80003d28:	02010113          	addi	sp,sp,32
    80003d2c:	ffffe317          	auipc	t1,0xffffe
    80003d30:	4b030067          	jr	1200(t1) # 800021dc <plic_complete>
    80003d34:	fffff097          	auipc	ra,0xfffff
    80003d38:	1bc080e7          	jalr	444(ra) # 80002ef0 <uartintr>
    80003d3c:	fddff06f          	j	80003d18 <console_handler+0x74>
    80003d40:	00000517          	auipc	a0,0x0
    80003d44:	52850513          	addi	a0,a0,1320 # 80004268 <digits+0x78>
    80003d48:	fffff097          	auipc	ra,0xfffff
    80003d4c:	844080e7          	jalr	-1980(ra) # 8000258c <panic>

0000000080003d50 <kvmincrease>:
    80003d50:	fe010113          	addi	sp,sp,-32
    80003d54:	01213023          	sd	s2,0(sp)
    80003d58:	00001937          	lui	s2,0x1
    80003d5c:	fff90913          	addi	s2,s2,-1 # fff <_entry-0x7ffff001>
    80003d60:	00813823          	sd	s0,16(sp)
    80003d64:	00113c23          	sd	ra,24(sp)
    80003d68:	00913423          	sd	s1,8(sp)
    80003d6c:	02010413          	addi	s0,sp,32
    80003d70:	01250933          	add	s2,a0,s2
    80003d74:	00c95913          	srli	s2,s2,0xc
    80003d78:	02090863          	beqz	s2,80003da8 <kvmincrease+0x58>
    80003d7c:	00000493          	li	s1,0
    80003d80:	00148493          	addi	s1,s1,1
    80003d84:	fffff097          	auipc	ra,0xfffff
    80003d88:	4bc080e7          	jalr	1212(ra) # 80003240 <kalloc>
    80003d8c:	fe991ae3          	bne	s2,s1,80003d80 <kvmincrease+0x30>
    80003d90:	01813083          	ld	ra,24(sp)
    80003d94:	01013403          	ld	s0,16(sp)
    80003d98:	00813483          	ld	s1,8(sp)
    80003d9c:	00013903          	ld	s2,0(sp)
    80003da0:	02010113          	addi	sp,sp,32
    80003da4:	00008067          	ret
    80003da8:	01813083          	ld	ra,24(sp)
    80003dac:	01013403          	ld	s0,16(sp)
    80003db0:	00813483          	ld	s1,8(sp)
    80003db4:	00013903          	ld	s2,0(sp)
    80003db8:	00000513          	li	a0,0
    80003dbc:	02010113          	addi	sp,sp,32
    80003dc0:	00008067          	ret
	...
